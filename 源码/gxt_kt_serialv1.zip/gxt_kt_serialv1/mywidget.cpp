#include "mywidget.h"
#include <QDebug>
#include <QFile>
#include <QStringList>
#include <QtMath>
#include <QOpenGLShaderProgram>
#include <QMouseEvent>
#include <QWheelEvent>
#include "widget.h"
#include "ui_widget.h"

void renderScene(void);

#include<GL/glut.h>

// 绘制立方体


MyWidget::MyWidget(QWidget *parent)
    : QOpenGLWidget(parent)
    ,VBO(QOpenGLBuffer::VertexBuffer)
    //,xtrans(0),ytrans(0),ztrans(-12.0)//设置初始位置
    ,xtrans(0),ytrans(0),ztrans(0.0)
{
    QSurfaceFormat format;
    format.setAlphaBufferSize(24);  //设置alpha缓冲大小
    format.setVersion(3,3);         //设置版本号
    format.setSamples(10);          //设置重采样次数，用于反走样

    this->setFormat(format);

    //vertices = loadAscllStl("C:/Users/gxt/Desktop/plane.STL",1);
    vertices = loadAscllStl(":/stlfile/plane1.STL",1);
//    vertices = loadAscllStl("C:/Users/gxt/Desktop/123.STL",1);
}

MyWidget::~MyWidget()
{
    makeCurrent();
}

QVector<float> MyWidget::loadAscllStl(QString filename,int ratio)
{
    QVector<float> vertices_temp;
   qDebug() << "load text file:" << filename;

  QFile file(filename);
  if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
  {
      qDebug() << "Open stl_file failed." << endl;
  }
    while (!file.atEnd())
    {
      QString line = file.readLine().trimmed(); // trimmed去除了开头和结尾的空白字符串
      QStringList  words = line.split(' ', QString::SkipEmptyParts);

      if (words[0] == "facet") {
      Normal = {ratio*words[2].toFloat(), ratio*words[3].toFloat(),ratio*words[4].toFloat()};
      }
      else if (words[0] == "vertex") {
        Position = {ratio*words[1].toFloat(), ratio*words[2].toFloat(),ratio*words[3].toFloat()};
        vertices_temp.append(Position);
        vertices_temp.append(Normal);
      }
      else
      {
          continue;
      }

      }

    qDebug() << "write vertice_temp success!" << filename;
    return vertices_temp;
 //   file.close();
}

void MyWidget::initializeGL()
{
    this->initializeOpenGLFunctions();//初始化opengl函数
    shaderprogram.create();//生成着色器程序
    if(!shaderprogram.addShaderFromSourceFile(QOpenGLShader::Vertex,":/stl.vert")){
        qDebug()<<"ERROR:"<<shaderprogram.log();    //如果编译出错,打印报错信息
    }
    if(!shaderprogram.addShaderFromSourceFile(QOpenGLShader::Fragment,":/stl.frag")){
        qDebug()<<"ERROR:"<<shaderprogram.log();    //如果编译出错,打印报错信息
    }
    //将添加到此程序的着色器与addshader链接在一起
     if(!shaderprogram.link()){
         qDebug()<<"ERROR:"<<shaderprogram.log();    //如果链接出错,打印报错信息
     }
//    QOpenGLVertexArrayObject::Binder{&VAO};

    VAO.create();// 创建一个VAO对象，OpenGL会给它（顶点数组缓存对象）分配一个id
    VAO.bind();//将RC中的当前顶点数组缓存对象Id设置为VAO的id
    VBO.create();
    VBO.bind();
    VBO.allocate(vertices.data(),sizeof(float)*vertices.size());//将顶点数据分配到VBO中，第一个参数为数据指针，第二个参数为数据的字节长度

    shaderprogram.setAttributeBuffer("aPos", GL_FLOAT, 0, 3, sizeof(GLfloat) * 6);
    shaderprogram.enableAttributeArray("aPos");
    shaderprogram.setAttributeBuffer("aNormal", GL_FLOAT,sizeof(GLfloat) * 3, 3, sizeof(GLfloat) * 6);
    shaderprogram.enableAttributeArray("aNormal");
     this->glEnable(GL_DEPTH_TEST);
//    VAO.release();//释放
//    VBO.release();

    view.setToIdentity();

    camerapos=QVector3D(0.0f,10.0f,-10.0f);
    cameraTarget=QVector3D(0.0f,0.0f,0.0f);
    cameraDirection=QVector3D(camerapos-cameraTarget);
    cameraDirection.normalize();

    up=QVector3D(0.0f,1.0f,0.0f);
    cameraRight=QVector3D::crossProduct(up,cameraDirection);
    cameraRight.normalize();
    cameraUp=QVector3D::crossProduct(cameraDirection,cameraRight);
    view.lookAt(camerapos, cameraTarget,up);
    //view.lookAt(QVector3D(0.0f, 0.0f, -12.0f), QVector3D(0.0f,0.0f,0.0f), QVector3D(0.0f,1.0f,0.0f));
    //shaderprogram.setUniformValue("view", view);

    //gxt 旋转x轴，旋转y轴，让图像变正
    QVector3D rotationAxis = QVector3D(1.0f, 0.0f, 0.0).normalized();
    rotation = QQuaternion::fromAxisAndAngle(rotationAxis, 180) * rotation;
    rotationAxis = QVector3D(0.0f, 1.0f, 0.0).normalized();
    rotation = QQuaternion::fromAxisAndAngle(rotationAxis, -90) * rotation;
    rotationAxis = QVector3D(1.0f, 0.0f, 0.0).normalized();
    rotation = QQuaternion::fromAxisAndAngle(rotationAxis, 90) * rotation;

    rotationAxis = QVector3D(1.0f, 0.0f, 0.0).normalized();
    rotation = QQuaternion::fromAxisAndAngle(rotationAxis, -90) * rotation;
    rotationAxis = QVector3D(0.0f, 0.0f, 1.0).normalized();
    rotation = QQuaternion::fromAxisAndAngle(rotationAxis, -90) * rotation;
//    rotationAxis = QVector3D(1.0f, 0.0f, 0.0).normalized();
//    rotation = QQuaternion::fromAxisAndAngle(rotationAxis, 90) * rotation;
//    rotationAxis = QVector3D(0.0f, 1.0f, 0.0).normalized();
//    rotation = QQuaternion::fromAxisAndAngle(rotationAxis, -90) * rotation;
    //rotationAxis = QVector3D(1.0f, 0.0f, 0.0f).normalized();
    //rotation = QQuaternion::fromAxisAndAngle(rotationAxis, 90) * rotation;
}
void MyWidget::resizeGL(int w,int h)
{
    this->glViewport(0,0,w,h);
    projection.setToIdentity();
    projection.perspective(60.0f, (GLfloat)w/(GLfloat)h, 0.001f, 100.0f);
    //shaderprogram.setUniformValue("projection", projection);
}

void MyWidget::paintGL()
{

    this->glClearColor(0.0f,0.4f,0.0f,1.0f);//设置清屏颜色
    this->glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//清空颜色缓冲区

    //更改相机位置--gxt
//    camerapos=QVector3D(0.0f,10.0f,-10.0f);// camX,camY,camZ
//    cameraTarget=QVector3D(0.0f,0.0f,0.0f);
//    cameraDirection=QVector3D(camerapos-cameraTarget);
//    cameraDirection.normalize();

//    up=QVector3D(0.0f,1.0f,0.0f);
//    cameraRight=QVector3D::crossProduct(up,cameraDirection);
//    cameraRight.normalize();
//    cameraUp=QVector3D::crossProduct(cameraDirection,cameraRight);
//    view.lookAt(camerapos, cameraTarget,up);


#if 1
    shaderprogram.bind();
    //将此着色器程序绑定到活动的qopenglcontext，并使其成为当前着色器程序。任何先前绑定的着色器程序都将被释放
    //成功绑定返回ture,反之，返回false.
  {
    QVector3D lightColor(1.0f,1.0f,1.5f);
    QVector3D objectColor(1.0f,0.6f,0.4f);
    QVector3D lightPos(0.0f,30.0f,-30.0f);

    shaderprogram.setUniformValue("objectColor",objectColor);
    shaderprogram.setUniformValue("lightColor",lightColor);
    shaderprogram.setUniformValue("lightPos", lightPos);

    model.setToIdentity();
    model.translate(xtrans, ytrans, ztrans);
    //model.translate(xtrans, ztrans, ytrans);//更改坐标系

    //gxt 旋转x轴，旋转y轴，让图像变正
//    if(my_ui->Btn_open->getChecked()==1)
//    {

    if(flush_i!=0)
    {
        flush_i=0;
        QVector3D rotationAxis = QVector3D(1.0f, 0.0f, 0.0).normalized();
        rotation = QQuaternion::fromAxisAndAngle(rotationAxis, 90) * rotation;
        rotationAxis = QVector3D(0.0f, 1.0f, 0.0).normalized();
        rotation = QQuaternion::fromAxisAndAngle(rotationAxis, -90) * rotation;
    }


 //   }



    model.rotate(rotation);
    shaderprogram.setUniformValue("view", view);
    shaderprogram.setUniformValue("projection", projection);
    shaderprogram.setUniformValue("model", model);

    int n = vertices.capacity()/sizeof(float);
    qDebug() << n;
    QOpenGLVertexArrayObject::Binder bind(&VAO);//绑定VAO
    glDrawArrays(GL_TRIANGLES,0,n);
    }
#endif

}

#if 0
void MyWidget::mousePressEvent(QMouseEvent *event)
{
    mousePos = QVector2D(event->pos());
    event->accept();
}

void MyWidget::mouseMoveEvent(QMouseEvent *event)
{
    /*
    if(event->buttons() == Qt::LeftButton)
    {
        QVector2D newPos = (QVector2D)event->pos();
        QVector2D diff = newPos - mousePos;
        qreal angle = (diff.length())/3.6;
        //qreal angle=30;

        QVector3D rotationAxis = QVector3D(diff.y(), diff.x(), 0.0).normalized();
        rotation = QQuaternion::fromAxisAndAngle(rotationAxis, angle) * rotation;

        mousePos = newPos;
        this->update();
    }*/
    if(event->buttons() == Qt::LeftButton)
    {
        QVector2D newPos = (QVector2D)event->pos();
        QVector2D diff = newPos - mousePos;
        qreal angle = (diff.length())/3.6;
        //qreal angle=30;

        //camX+=diff.x();
        //camY+=diff.y();
        //camZ+=;

        mousePos = newPos;
//        this->update();
    }
    event->accept();

}

void MyWidget::wheelEvent(QWheelEvent *event)
{

//    QPoint numDegrees = event->angleDelta() / 8;

//    if (numDegrees.y() > 0) {
//         ztrans+= 1.0f;
//    } else if (numDegrees.y() < 0) {
//        ztrans -= 1.0f;
//    }
//    //this->update();
//    event->accept();
}

#endif

void MyWidget::SetVal(float roll,float pitch,float yaw)
{
    flush_i=1;
     rotation=QQuaternion::fromEulerAngles(roll,pitch,yaw);//欧拉角版本
    //rotation=QQuaternion::fromEulerAngles(0,0,-180);//欧拉角版本
     this->update();
}

#include "qmath.h"

void MyWidget::SetVal(float x, float y, float z, float w,float *roll,float *pitch,float *yaw)
{
    //四元数反算欧拉角
    flush_i=1;
    *roll = atan2(2 * (y*z + w*x), w*w - x*x - y*y + z*z)*180/M_PI;
    *pitch = asin(-2 * (x*z - w*y))*180/M_PI;
    *yaw = atan2(2 * (x*y + w*z), w*w + x*x - y*y - z*z)*180/M_PI;

    //
        QQuaternion quater;
        quater.setScalar(w);
        quater.setVector(x,y,z);
        quater.normalize();
        rotation=QQuaternion::fromRotationMatrix(quater.toRotationMatrix());//设置3d
        //rotation=QQuaternion::fromEulerAngles();//设置3d


       // quater.getEulerAngles(roll,pitch,yaw);
        this->update();
}

void MyWidget::SetVal2(float x, float y, float z, float w,float *roll,float *pitch,float *yaw) // Z-Y-X Euler angles
{
    flush_i=1;
    const double Epsilon = 0.0009765625f;
    const double Threshold = 0.5f - Epsilon;

    double TEST = w*y - x*z;

    if (TEST < -Threshold || TEST > Threshold) // 奇异姿态,俯仰角为±90°
    {
        int sign;
        if(TEST>0) sign=1;
        else if(TEST<0) sign=-1;
        else sign=0;

        *roll = -2 * sign * (double)atan2(x, w); // yaw

        *pitch= sign * (M_PI_2); // pitch

        *roll = 0; // roll
    }
    else
    {
        *roll = atan2(2 * (y*z + w*x), w*w - x*x - y*y + z*z)*180/M_PI;
        *pitch = asin(-2 * (x*z - w*y))*180/M_PI;
        *yaw = atan2(2 * (x*y + w*z), w*w + x*x - y*y - z*z)*180/M_PI;
    }

    //使用四元数设置3d
#if 0
    QQuaternion quater;
    quater.setScalar(w);
    quater.setVector(x,y,z);
    quater.normalize();
    rotation=QQuaternion::fromRotationMatrix(quater.toRotationMatrix());//设置3d


#else //使用欧拉角设置3d
    rotation=QQuaternion::fromEulerAngles(*roll,*pitch,*yaw);//设置3d
#endif


    this->update();//更新3d
}
