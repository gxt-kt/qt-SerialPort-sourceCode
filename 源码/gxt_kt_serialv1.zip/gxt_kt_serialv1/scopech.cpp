﻿#include "scopech.h"
#include "ui_scopech.h"
#include "qcolordialog.h"
#include "config.h"
#include "QDebug"
#include "qmenu.h"
#include <QGraphicsDropShadowEffect>
#include "scoperightbtn.h"
#include "ui_scoperightbtn.h"
#include "datastorage.h"
ScopeCh::ScopeCh(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ScopeCh)
{
    ui->setupUi(this);

    connect(ui->ScopeCh_n,&QCheckBox::toggled,[=](){
        Config().Set("ScopeCol",QString("ch_check%1").arg(objectName().replace(QRegExp("^Scope_Ch"),"").toInt()),\
                     ui->ScopeCh_n->isChecked());
    });
}

ScopeCh::~ScopeCh()
{
    delete ui;
}

void ScopeCh::show_menu(void)
{
    qDebug("show_meau");
}

void ScopeCh::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::RightButton)
    {
        MenuChoose=new scopeRightBtn;//设置菜单
        MenuChoose->setWindowFlags(MenuChoose->windowFlags() | Qt::FramelessWindowHint | Qt::NoDropShadowWindowHint);
        MenuChoose->setAttribute(Qt::WA_TranslucentBackground,true);
        QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect(this);
        shadow->setOffset(0, 0);
        shadow->setColor(QColor("#444444"));
        shadow->setBlurRadius(10);
        MenuChoose->setGraphicsEffect(shadow);

        //MenuChoose->ui->colorChoose->setColorName("black");
        QStringList collist= getChCol().colorNames();
        for (int colt=0;colt<collist.size();colt++) {
            if(QColor(collist[colt])==getChCol())
            {MenuChoose->ui->colorChoose->setColorName(collist[colt]);break;}
        }
        //MenuChoose->ui->colorChoose->initItems();


        MenuChoose->ui->Numintfloat->setCurrentIndex(chtype[objectName().replace(QRegExp("^Scope_Ch"),"").toInt()]);


        connect(MenuChoose->ui->Ensure,&QPushButton::clicked,[=](){//按下确定
            qDebug()<<"successful";
            QColor test_col;
            test_col.setNamedColor(MenuChoose->ui->colorChoose->getColorName());
            test_col.setAlpha(255);
            setChCol(test_col);
            QVariant qva;//写入对应通道颜色
            qva.setValue<QColor>(test_col);
            Config().Set("ScopeCol",QString("ch%1").arg(objectName().replace(QRegExp("^Scope_Ch"),"").toInt()),qva);

            //写入对应通道int/float数据类型
            int intStr=MenuChoose->ui->Numintfloat->currentIndex();
            qDebug()<<"intStr="<<intStr;
            Config().Set("ScopeInt",QString("ch%1").arg(objectName().replace(QRegExp("^Scope_Ch"),"").toInt()),intStr);
            chtype[objectName().replace(QRegExp("^Scope_Ch"),"").toInt()]=intStr;//对应通道值写入index

            MenuChoose->close();//关闭
        });

        MenuChoose->exec(QCursor::pos());
    }
}

bool ScopeCh::getIfChecked(void)
{
    if(ui->ScopeCh_n->isChecked()!=0) return true;
    else return 0;
}

void ScopeCh::setChecked(bool i)
{
    ui->ScopeCh_n->setChecked(i);
}

QColor ScopeCh::getChCol()
{
//    //这里需要注意，输入性质的控件(如这里的lineEdit)用base(),如果是按钮用button()，不然获取不到
    return ui->ScopeCh_n->palette().base().color();
}

void ScopeCh::setChCol(QColor col)
{
    QString str;
    str.sprintf("QCheckBox{background-color:rgb(%d,%d,%d)}"
                "QCheckBox{color:rgb(%d,%d,%d)}",col.red(),col.green(),col.blue(),255-col.red(),255-col.green(),255-col.blue());
    ui->ScopeCh_n->setStyleSheet(str);
}

void ScopeCh::setChNText(QString str)
{
    ui->ScopeCh_n->setText(str);
}

void ScopeCh::setLabelText(QString str)
{
    ui->ScopeCh_num->setText(str);
}

void ScopeCh::setLabelText(int num)
{
    ui->ScopeCh_num->setText( QString::number(num));
}

void ScopeCh::setFpsVal(int fps)
{
    ui->FpsVal->setText(QString("%1").arg(fps));
}

int ScopeCh::getFpsVal()
{
    return ui->FpsVal->text().toUInt();
}

void ScopeCh::setLabelText(float num)
{
    ui->ScopeCh_num->setText( QString::number(num));
}

void flush_test(void)
{
    //qDebug("flush_test");

}
