#include "scopeset.h"
#include "ui_scopeset.h"

ScopeSet::ScopeSet(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ScopeSet)
{
    ui->setupUi(this);
}

ScopeSet::~ScopeSet()
{
    delete ui;
}
