/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <mywidget.h>
#include <sendcmd.h>
#include <slider.h>
#include "battery.h"
#include "gaugecompass.h"
#include "gaugeplane.h"
#include "lightpoint.h"
#include "navbuttongroup.h"
#include "panelitem.h"
#include "switchbutton.h"
#include "xprogressbar.h"

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QTextEdit *textEdit;
    QLabel *label_23;
    SwitchButton *Btn_open;
    QStackedWidget *stackedWidget;
    QWidget *page_1;
    PanelItem *panelItem_5;
    QRadioButton *SendAscii;
    QRadioButton *SendHex;
    NavButtonGroup *nav_sendifOne;
    QStackedWidget *SendIfOne;
    QWidget *page;
    QPushButton *BtnSend;
    QPlainTextEdit *send_buf;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_99;
    QLineEdit *SendTime;
    QLabel *label_98;
    QWidget *layoutWidget1;
    QGridLayout *gridLayout_17;
    QRadioButton *SendAuto;
    QRadioButton *SendNewL;
    QWidget *page_2;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_3;
    SendCmd *widget_14;
    SendCmd *widget_15;
    SendCmd *widget_12;
    SendCmd *widget_13;
    SendCmd *widget_6;
    SendCmd *widget_7;
    SendCmd *widget_8;
    SendCmd *widget_9;
    SendCmd *widget_10;
    SendCmd *widget_11;
    PanelItem *panelItem_6;
    QRadioButton *ShowOpen;
    QPushButton *BtnRecClr;
    QRadioButton *ShowAscii;
    QRadioButton *ShowHex;
    QRadioButton *ShowTime;
    QRadioButton *RemoveAgree;
    QTextEdit *rec_buf;
    QWidget *page_5;
    PanelItem *panelItem_4;
    QFrame *line_4;
    QFrame *line_5;
    QWidget *layoutWidget_13;
    QGridLayout *gridLayout_11;
    QLabel *label_70;
    QLabel *Roll;
    QLabel *Pitch;
    QLabel *Yaw;
    QLabel *label_74;
    QLabel *label_75;
    QLabel *label_76;
    QLabel *label_77;
    QWidget *layoutWidget_14;
    QGridLayout *gridLayout_12;
    QLabel *label_78;
    QLabel *label_79;
    QLabel *label_80;
    QLabel *label_81;
    LightPoint *lightPoint_4;
    QLabel *label_82;
    LightPoint *lightPoint_2;
    LightPoint *lightPoint_5;
    LightPoint *lightPoint_3;
    LightPoint *lightPoint_6;
    QWidget *layoutWidget_15;
    QGridLayout *gridLayout_13;
    QLabel *label_83;
    LightPoint *lightPoint_1;
    QWidget *layoutWidget_16;
    QGridLayout *gridLayout_14;
    QLabel *label_84;
    QLabel *label_85;
    QLabel *label_86;
    QLabel *label_87;
    QLabel *label_88;
    QLabel *label_89;
    QLabel *label_90;
    QLabel *label_91;
    PanelItem *panelItem_3;
    XProgressBar *rcCh2;
    XProgressBar *rcCh1;
    XProgressBar *rcCh3;
    XProgressBar *rcCh4;
    XProgressBar *rcCh5;
    XProgressBar *rcCh6;
    XProgressBar *rcCh7;
    XProgressBar *rcCh11;
    XProgressBar *rcCh10;
    XProgressBar *rcCh9;
    XProgressBar *rcCh8;
    XProgressBar *rcCh12;
    QLabel *label_62;
    QLabel *label_63;
    QLabel *label_64;
    QLabel *label_65;
    QLabel *label_66;
    QLabel *label_67;
    QLabel *label_68;
    QLabel *label_33;
    QLabel *label_58;
    QLabel *label_59;
    QLabel *label_60;
    QLabel *label_61;
    GaugeCompass *gaugeyaw;
    GaugePlane *gaugerollpitch;
    MyWidget *stl3d;
    QWidget *widget_3;
    QGridLayout *gridLayout_5;
    QRadioButton *oulajiao;
    QRadioButton *siyuanshu;
    QWidget *widget_4;
    QRadioButton *radioButton_6;
    QRadioButton *radioButton_10;
    QRadioButton *radioButton_7;
    QRadioButton *radioButton_11;
    QWidget *page_6;
    QPushButton *Scope;
    QLabel *label_36;
    QLabel *label_37;
    QPushButton *ShowDetailInfo;
    QLabel *label_38;
    QWidget *page_7;
    QWidget *layoutWidget_2;
    QGridLayout *gridLayout_8;
    Slider *slider_8;
    Slider *slider_9;
    Slider *slider_10;
    Slider *slider_6;
    Slider *slider_7;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_15;
    QLabel *label_17;
    QLabel *label_21;
    QWidget *layoutWidget_3;
    QGridLayout *gridLayout_9;
    Slider *slider_13;
    Slider *slider_14;
    Slider *slider_15;
    Slider *slider_11;
    Slider *slider_12;
    QLabel *label_22;
    QLabel *label_24;
    QLabel *label_25;
    QLabel *label_26;
    QLabel *label_27;
    QWidget *layoutWidget_4;
    QGridLayout *gridLayout_10;
    Slider *slider_18;
    Slider *slider_19;
    Slider *slider_20;
    Slider *slider_16;
    Slider *slider_17;
    QLabel *label_28;
    QLabel *label_29;
    QLabel *label_30;
    QLabel *label_31;
    QLabel *label_32;
    QPushButton *btnSliderSend_1;
    QWidget *layoutWidget2;
    QGridLayout *gridLayout_7;
    Slider *slider_3;
    Slider *slider_4;
    Slider *slider_5;
    Slider *slider_1;
    Slider *slider_2;
    QLabel *label_1;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label;
    QLabel *label_4;
    QPushButton *btnSliderSend_11;
    QPushButton *btnSliderSend_31;
    QPushButton *btnSliderSend_2;
    QPushButton *btnSliderSend_3;
    QPushButton *btnSliderSend_4;
    QFrame *line;
    QWidget *page_8;
    QLabel *label_35;
    QComboBox *SystemMagnify;
    QLabel *label_39;
    QLabel *label_40;
    NavButtonGroup *navButtonGroup;
    QWidget *layoutWidget_17;
    QGridLayout *gridLayout_15;
    QLabel *label_92;
    QLabel *Voltage;
    Battery *battery;
    QComboBox *voltage_sel;
    QWidget *layoutWidget3;
    QGridLayout *gridLayout;
    QLabel *RecNum_2;
    QLabel *label_10;
    QLabel *label_18;
    QLabel *RecNum_3;
    QLabel *label_16;
    QLabel *RecNum_4;
    QWidget *layoutWidget4;
    QGridLayout *gridLayout_2;
    QLabel *label_100;
    QLabel *label_20;
    QLabel *label_101;
    QLabel *errPer;
    NavButtonGroup *ConnectBtn;
    QStackedWidget *ConnectWidget;
    QWidget *page_3;
    QLabel *label_9;
    QComboBox *SerialNum;
    QLabel *label_11;
    QComboBox *SerialBaud;
    QLabel *label_12;
    QComboBox *SerialData;
    QWidget *layoutWidget5;
    QHBoxLayout *horizontalLayout;
    QLabel *label_13;
    QComboBox *comboBox_13;
    QLabel *label_14;
    QComboBox *comboBox_14;
    QWidget *page_4;
    QLabel *label_19;
    QWidget *layoutWidget6;
    QGridLayout *gridLayout_4;
    QLabel *label_7;
    QLabel *RecNum;
    QLabel *label_8;
    QLabel *SendNum;
    QPushButton *NumClear;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(1100, 760);
        Widget->setMinimumSize(QSize(1100, 760));
        Widget->setMaximumSize(QSize(1100, 760));
        Widget->setStyleSheet(QStringLiteral(""));
        textEdit = new QTextEdit(Widget);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(0, 600, 411, 161));
        textEdit->setReadOnly(true);
        label_23 = new QLabel(Widget);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(904, 734, 75, 23));
        label_23->setStyleSheet(QLatin1String("font: 75 10pt \"Consolas\";\n"
"color: rgb(24, 143, 255);"));
        Btn_open = new SwitchButton(Widget);
        Btn_open->setObjectName(QStringLiteral("Btn_open"));
        Btn_open->setGeometry(QRect(1002, 730, 95, 30));
        Btn_open->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        Btn_open->setAnimation(true);
        stackedWidget = new QStackedWidget(Widget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(2, -2, 1096, 605));
        stackedWidget->setMinimumSize(QSize(1096, 605));
        stackedWidget->setMaximumSize(QSize(1096, 605));
        stackedWidget->setFocusPolicy(Qt::TabFocus);
        stackedWidget->setAutoFillBackground(false);
        page_1 = new QWidget();
        page_1->setObjectName(QStringLiteral("page_1"));
        panelItem_5 = new PanelItem(page_1);
        panelItem_5->setObjectName(QStringLiteral("panelItem_5"));
        panelItem_5->setGeometry(QRect(2, 438, 779, 165));
        panelItem_5->setStyleSheet(QStringLiteral(""));
        panelItem_5->setTitleHeight(20);
        QFont font;
        font.setFamily(QString::fromUtf8("\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200"));
        font.setPointSize(12);
        panelItem_5->setTitleFont(font);
        panelItem_5->setBorderRadius(10);
        SendAscii = new QRadioButton(panelItem_5);
        SendAscii->setObjectName(QStringLiteral("SendAscii"));
        SendAscii->setGeometry(QRect(8, 96, 85, 27));
        SendAscii->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        SendAscii->setChecked(true);
        SendHex = new QRadioButton(panelItem_5);
        SendHex->setObjectName(QStringLiteral("SendHex"));
        SendHex->setGeometry(QRect(8, 126, 64, 27));
        SendHex->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        nav_sendifOne = new NavButtonGroup(panelItem_5);
        nav_sendifOne->setObjectName(QStringLiteral("nav_sendifOne"));
        nav_sendifOne->setGeometry(QRect(3, 22, 97, 67));
        nav_sendifOne->setMinimumSize(QSize(97, 67));
        nav_sendifOne->setMaximumSize(QSize(97, 67));
        nav_sendifOne->setAutoFillBackground(false);
        nav_sendifOne->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        nav_sendifOne->setInterval(300);
        nav_sendifOne->setLinePosition(NavButtonGroup::LinePosition_Right);
        nav_sendifOne->setLineColor(QColor(169, 0, 0));
        nav_sendifOne->setBtnHoverColor(QColor(169, 130, 52, 100));
        nav_sendifOne->setBtnDarkColor(QColor(169, 119, 48, 180));
        SendIfOne = new QStackedWidget(panelItem_5);
        SendIfOne->setObjectName(QStringLiteral("SendIfOne"));
        SendIfOne->setGeometry(QRect(102, 24, 673, 135));
        SendIfOne->setMinimumSize(QSize(673, 135));
        SendIfOne->setMaximumSize(QSize(673, 135));
        SendIfOne->setAutoFillBackground(false);
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        BtnSend = new QPushButton(page);
        BtnSend->setObjectName(QStringLiteral("BtnSend"));
        BtnSend->setEnabled(true);
        BtnSend->setGeometry(QRect(562, 32, 105, 100));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(BtnSend->sizePolicy().hasHeightForWidth());
        BtnSend->setSizePolicy(sizePolicy);
        BtnSend->setMinimumSize(QSize(105, 100));
        BtnSend->setMaximumSize(QSize(105, 100));
        BtnSend->setStyleSheet(QString::fromUtf8("font: 20pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";\n"
"color: rgb(118, 61, 0);\n"
"background-color: rgb(137, 194, 255);"));
        BtnSend->setCheckable(false);
        BtnSend->setChecked(false);
        BtnSend->setAutoExclusive(false);
        BtnSend->setAutoDefault(false);
        BtnSend->setFlat(false);
        send_buf = new QPlainTextEdit(page);
        send_buf->setObjectName(QStringLiteral("send_buf"));
        send_buf->setGeometry(QRect(4, 0, 453, 135));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W"));
        font1.setPointSize(12);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        send_buf->setFont(font1);
        send_buf->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        send_buf->setFrameShape(QFrame::StyledPanel);
        send_buf->setLineWrapMode(QPlainTextEdit::WidgetWidth);
        send_buf->setOverwriteMode(true);
        layoutWidget = new QWidget(page);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(470, 0, 171, 30));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_99 = new QLabel(layoutWidget);
        label_99->setObjectName(QStringLiteral("label_99"));
        label_99->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));

        horizontalLayout_3->addWidget(label_99);

        SendTime = new QLineEdit(layoutWidget);
        SendTime->setObjectName(QStringLiteral("SendTime"));
        SendTime->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));

        horizontalLayout_3->addWidget(SendTime);

        label_98 = new QLabel(layoutWidget);
        label_98->setObjectName(QStringLiteral("label_98"));
        label_98->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));

        horizontalLayout_3->addWidget(label_98);

        layoutWidget1 = new QWidget(page);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(460, 50, 103, 62));
        gridLayout_17 = new QGridLayout(layoutWidget1);
        gridLayout_17->setObjectName(QStringLiteral("gridLayout_17"));
        gridLayout_17->setContentsMargins(0, 0, 0, 0);
        SendAuto = new QRadioButton(layoutWidget1);
        SendAuto->setObjectName(QStringLiteral("SendAuto"));
        SendAuto->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        SendAuto->setAutoExclusive(false);

        gridLayout_17->addWidget(SendAuto, 0, 0, 1, 1);

        SendNewL = new QRadioButton(layoutWidget1);
        SendNewL->setObjectName(QStringLiteral("SendNewL"));
        SendNewL->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        SendNewL->setAutoExclusive(false);

        gridLayout_17->addWidget(SendNewL, 1, 0, 1, 1);

        SendIfOne->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        scrollArea = new QScrollArea(page_2);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setGeometry(QRect(0, 0, 670, 132));
        scrollArea->setMinimumSize(QSize(670, 132));
        scrollArea->setMaximumSize(QSize(670, 132));
        scrollArea->setAutoFillBackground(false);
        scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        scrollArea->setWidgetResizable(true);
        scrollArea->setAlignment(Qt::AlignCenter);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 653, 414));
        verticalLayout_3 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        widget_14 = new SendCmd(scrollAreaWidgetContents);
        widget_14->setObjectName(QStringLiteral("widget_14"));
        widget_14->setMinimumSize(QSize(630, 34));
        widget_14->setMaximumSize(QSize(630, 34));
        widget_14->setAutoFillBackground(true);

        verticalLayout_3->addWidget(widget_14);

        widget_15 = new SendCmd(scrollAreaWidgetContents);
        widget_15->setObjectName(QStringLiteral("widget_15"));
        widget_15->setMinimumSize(QSize(630, 34));
        widget_15->setMaximumSize(QSize(630, 34));
        widget_15->setAutoFillBackground(true);

        verticalLayout_3->addWidget(widget_15);

        widget_12 = new SendCmd(scrollAreaWidgetContents);
        widget_12->setObjectName(QStringLiteral("widget_12"));
        widget_12->setMinimumSize(QSize(630, 34));
        widget_12->setMaximumSize(QSize(630, 34));
        widget_12->setAutoFillBackground(true);

        verticalLayout_3->addWidget(widget_12);

        widget_13 = new SendCmd(scrollAreaWidgetContents);
        widget_13->setObjectName(QStringLiteral("widget_13"));
        widget_13->setMinimumSize(QSize(630, 34));
        widget_13->setMaximumSize(QSize(630, 34));
        widget_13->setAutoFillBackground(true);

        verticalLayout_3->addWidget(widget_13);

        widget_6 = new SendCmd(scrollAreaWidgetContents);
        widget_6->setObjectName(QStringLiteral("widget_6"));
        widget_6->setMinimumSize(QSize(630, 34));
        widget_6->setMaximumSize(QSize(630, 34));
        widget_6->setAutoFillBackground(true);

        verticalLayout_3->addWidget(widget_6);

        widget_7 = new SendCmd(scrollAreaWidgetContents);
        widget_7->setObjectName(QStringLiteral("widget_7"));
        widget_7->setMinimumSize(QSize(630, 34));
        widget_7->setMaximumSize(QSize(630, 34));
        widget_7->setAutoFillBackground(true);

        verticalLayout_3->addWidget(widget_7);

        widget_8 = new SendCmd(scrollAreaWidgetContents);
        widget_8->setObjectName(QStringLiteral("widget_8"));
        widget_8->setMinimumSize(QSize(630, 34));
        widget_8->setMaximumSize(QSize(630, 34));
        widget_8->setAutoFillBackground(true);

        verticalLayout_3->addWidget(widget_8);

        widget_9 = new SendCmd(scrollAreaWidgetContents);
        widget_9->setObjectName(QStringLiteral("widget_9"));
        widget_9->setMinimumSize(QSize(630, 34));
        widget_9->setMaximumSize(QSize(630, 34));
        widget_9->setAutoFillBackground(true);

        verticalLayout_3->addWidget(widget_9);

        widget_10 = new SendCmd(scrollAreaWidgetContents);
        widget_10->setObjectName(QStringLiteral("widget_10"));
        widget_10->setMinimumSize(QSize(630, 34));
        widget_10->setMaximumSize(QSize(630, 34));
        widget_10->setAutoFillBackground(true);

        verticalLayout_3->addWidget(widget_10);

        widget_11 = new SendCmd(scrollAreaWidgetContents);
        widget_11->setObjectName(QStringLiteral("widget_11"));
        widget_11->setMinimumSize(QSize(630, 34));
        widget_11->setMaximumSize(QSize(630, 34));
        widget_11->setAutoFillBackground(true);

        verticalLayout_3->addWidget(widget_11);

        scrollArea->setWidget(scrollAreaWidgetContents);
        SendIfOne->addWidget(page_2);
        panelItem_6 = new PanelItem(page_1);
        panelItem_6->setObjectName(QStringLiteral("panelItem_6"));
        panelItem_6->setGeometry(QRect(784, 438, 311, 165));
        panelItem_6->setStyleSheet(QStringLiteral(""));
        panelItem_6->setTitleHeight(20);
        panelItem_6->setTitleFont(font);
        panelItem_6->setBorderRadius(10);
        ShowOpen = new QRadioButton(panelItem_6);
        ShowOpen->setObjectName(QStringLiteral("ShowOpen"));
        ShowOpen->setGeometry(QRect(132, 38, 147, 45));
        sizePolicy.setHeightForWidth(ShowOpen->sizePolicy().hasHeightForWidth());
        ShowOpen->setSizePolicy(sizePolicy);
        ShowOpen->setMinimumSize(QSize(147, 45));
        ShowOpen->setMaximumSize(QSize(147, 45));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200"));
        font2.setPointSize(20);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setWeight(50);
        ShowOpen->setFont(font2);
        ShowOpen->setStyleSheet(QString::fromUtf8("font: 20pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        ShowOpen->setCheckable(true);
        ShowOpen->setAutoExclusive(false);
        BtnRecClr = new QPushButton(panelItem_6);
        BtnRecClr->setObjectName(QStringLiteral("BtnRecClr"));
        BtnRecClr->setEnabled(true);
        BtnRecClr->setGeometry(QRect(124, 90, 173, 59));
        sizePolicy.setHeightForWidth(BtnRecClr->sizePolicy().hasHeightForWidth());
        BtnRecClr->setSizePolicy(sizePolicy);
        BtnRecClr->setMinimumSize(QSize(173, 59));
        BtnRecClr->setMaximumSize(QSize(173, 59));
        BtnRecClr->setStyleSheet(QString::fromUtf8("font: 20pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        ShowAscii = new QRadioButton(panelItem_6);
        ShowAscii->setObjectName(QStringLiteral("ShowAscii"));
        ShowAscii->setGeometry(QRect(11, 31, 85, 27));
        ShowAscii->setAutoFillBackground(false);
        ShowAscii->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        ShowAscii->setChecked(false);
        ShowHex = new QRadioButton(panelItem_6);
        ShowHex->setObjectName(QStringLiteral("ShowHex"));
        ShowHex->setGeometry(QRect(11, 64, 110, 26));
        ShowHex->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        ShowTime = new QRadioButton(panelItem_6);
        ShowTime->setObjectName(QStringLiteral("ShowTime"));
        ShowTime->setGeometry(QRect(11, 96, 110, 26));
        ShowTime->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        ShowTime->setAutoExclusive(false);
        RemoveAgree = new QRadioButton(panelItem_6);
        RemoveAgree->setObjectName(QStringLiteral("RemoveAgree"));
        RemoveAgree->setGeometry(QRect(11, 128, 110, 26));
        RemoveAgree->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        RemoveAgree->setChecked(true);
        RemoveAgree->setAutoExclusive(false);
        rec_buf = new QTextEdit(page_1);
        rec_buf->setObjectName(QStringLiteral("rec_buf"));
        rec_buf->setGeometry(QRect(0, 4, 1097, 431));
        rec_buf->setStyleSheet(QString::fromUtf8("font: 12pt \" \346\261\211\344\273\252\350\211\257\345\223\201\347\272\277\347\256\200\";"));
        stackedWidget->addWidget(page_1);
        page_5 = new QWidget();
        page_5->setObjectName(QStringLiteral("page_5"));
        panelItem_4 = new PanelItem(page_5);
        panelItem_4->setObjectName(QStringLiteral("panelItem_4"));
        panelItem_4->setGeometry(QRect(2, 332, 429, 267));
        panelItem_4->setStyleSheet(QStringLiteral(""));
        panelItem_4->setTitleHeight(20);
        QFont font3;
        font3.setFamily(QString::fromUtf8("\346\261\211\344\273\252\350\267\263\350\267\263\344\275\223\347\256\200"));
        font3.setPointSize(14);
        panelItem_4->setTitleFont(font3);
        panelItem_4->setBorderRadius(10);
        panelItem_4->setBorderColor(QColor(2, 61, 255));
        panelItem_4->setProperty("isAlarm", QVariant(false));
        line_4 = new QFrame(panelItem_4);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setGeometry(QRect(2, 98, 423, 16));
        line_4->setAutoFillBackground(false);
        line_4->setStyleSheet(QStringLiteral("color: rgb(158, 200, 255);"));
        line_4->setFrameShadow(QFrame::Plain);
        line_4->setLineWidth(3);
        line_4->setMidLineWidth(0);
        line_4->setFrameShape(QFrame::HLine);
        line_5 = new QFrame(panelItem_4);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setGeometry(QRect(2, 176, 423, 16));
        line_5->setAutoFillBackground(false);
        line_5->setStyleSheet(QStringLiteral("color: rgb(158, 200, 255);"));
        line_5->setFrameShadow(QFrame::Plain);
        line_5->setLineWidth(3);
        line_5->setMidLineWidth(0);
        line_5->setFrameShape(QFrame::HLine);
        layoutWidget_13 = new QWidget(panelItem_4);
        layoutWidget_13->setObjectName(QStringLiteral("layoutWidget_13"));
        layoutWidget_13->setGeometry(QRect(8, 110, 411, 71));
        gridLayout_11 = new QGridLayout(layoutWidget_13);
        gridLayout_11->setObjectName(QStringLiteral("gridLayout_11"));
        label_70 = new QLabel(layoutWidget_13);
        label_70->setObjectName(QStringLiteral("label_70"));
        label_70->setLayoutDirection(Qt::LeftToRight);
        label_70->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_70->setTextFormat(Qt::AutoText);
        label_70->setScaledContents(false);
        label_70->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(label_70, 0, 0, 1, 1);

        Roll = new QLabel(layoutWidget_13);
        Roll->setObjectName(QStringLiteral("Roll"));
        Roll->setStyleSheet(QString::fromUtf8("font: 19pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(255, 65, 132);"));
        Roll->setAlignment(Qt::AlignCenter);
        Roll->setTextInteractionFlags(Qt::LinksAccessibleByMouse);

        gridLayout_11->addWidget(Roll, 1, 0, 1, 1);

        Pitch = new QLabel(layoutWidget_13);
        Pitch->setObjectName(QStringLiteral("Pitch"));
        Pitch->setStyleSheet(QString::fromUtf8("font: 19pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(29, 131, 255);"));
        Pitch->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(Pitch, 1, 1, 1, 1);

        Yaw = new QLabel(layoutWidget_13);
        Yaw->setObjectName(QStringLiteral("Yaw"));
        Yaw->setStyleSheet(QString::fromUtf8("font: 19pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(255, 170, 255);"));
        Yaw->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(Yaw, 1, 2, 1, 1);

        label_74 = new QLabel(layoutWidget_13);
        label_74->setObjectName(QStringLiteral("label_74"));
        label_74->setStyleSheet(QString::fromUtf8("font: 19pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(255, 56, 6);"));
        label_74->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(label_74, 1, 3, 1, 1);

        label_75 = new QLabel(layoutWidget_13);
        label_75->setObjectName(QStringLiteral("label_75"));
        label_75->setLayoutDirection(Qt::LeftToRight);
        label_75->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_75->setTextFormat(Qt::AutoText);
        label_75->setScaledContents(false);
        label_75->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(label_75, 0, 1, 1, 1);

        label_76 = new QLabel(layoutWidget_13);
        label_76->setObjectName(QStringLiteral("label_76"));
        label_76->setLayoutDirection(Qt::LeftToRight);
        label_76->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_76->setTextFormat(Qt::AutoText);
        label_76->setScaledContents(false);
        label_76->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(label_76, 0, 2, 1, 1);

        label_77 = new QLabel(layoutWidget_13);
        label_77->setObjectName(QStringLiteral("label_77"));
        label_77->setLayoutDirection(Qt::LeftToRight);
        label_77->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_77->setTextFormat(Qt::AutoText);
        label_77->setScaledContents(false);
        label_77->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(label_77, 0, 3, 1, 1);

        layoutWidget_14 = new QWidget(panelItem_4);
        layoutWidget_14->setObjectName(QStringLiteral("layoutWidget_14"));
        layoutWidget_14->setGeometry(QRect(114, 30, 303, 65));
        gridLayout_12 = new QGridLayout(layoutWidget_14);
        gridLayout_12->setObjectName(QStringLiteral("gridLayout_12"));
        label_78 = new QLabel(layoutWidget_14);
        label_78->setObjectName(QStringLiteral("label_78"));
        label_78->setLayoutDirection(Qt::LeftToRight);
        label_78->setTextFormat(Qt::AutoText);
        label_78->setScaledContents(false);
        label_78->setAlignment(Qt::AlignCenter);

        gridLayout_12->addWidget(label_78, 0, 0, 1, 1);

        label_79 = new QLabel(layoutWidget_14);
        label_79->setObjectName(QStringLiteral("label_79"));
        label_79->setLayoutDirection(Qt::LeftToRight);
        label_79->setTextFormat(Qt::AutoText);
        label_79->setScaledContents(false);
        label_79->setAlignment(Qt::AlignCenter);

        gridLayout_12->addWidget(label_79, 0, 1, 1, 1);

        label_80 = new QLabel(layoutWidget_14);
        label_80->setObjectName(QStringLiteral("label_80"));
        label_80->setLayoutDirection(Qt::LeftToRight);
        label_80->setTextFormat(Qt::AutoText);
        label_80->setScaledContents(false);
        label_80->setAlignment(Qt::AlignCenter);

        gridLayout_12->addWidget(label_80, 0, 2, 1, 1);

        label_81 = new QLabel(layoutWidget_14);
        label_81->setObjectName(QStringLiteral("label_81"));
        label_81->setLayoutDirection(Qt::LeftToRight);
        label_81->setTextFormat(Qt::AutoText);
        label_81->setScaledContents(false);
        label_81->setAlignment(Qt::AlignCenter);

        gridLayout_12->addWidget(label_81, 0, 3, 1, 1);

        lightPoint_4 = new LightPoint(layoutWidget_14);
        lightPoint_4->setObjectName(QStringLiteral("lightPoint_4"));
        lightPoint_4->setAutoFillBackground(false);
        lightPoint_4->setBgColor(QColor(255, 0, 0, 0));

        gridLayout_12->addWidget(lightPoint_4, 1, 2, 1, 1);

        label_82 = new QLabel(layoutWidget_14);
        label_82->setObjectName(QStringLiteral("label_82"));
        label_82->setLayoutDirection(Qt::LeftToRight);
        label_82->setTextFormat(Qt::AutoText);
        label_82->setScaledContents(false);
        label_82->setAlignment(Qt::AlignCenter);

        gridLayout_12->addWidget(label_82, 0, 4, 1, 1);

        lightPoint_2 = new LightPoint(layoutWidget_14);
        lightPoint_2->setObjectName(QStringLiteral("lightPoint_2"));
        lightPoint_2->setAutoFillBackground(false);
        lightPoint_2->setBgColor(QColor(255, 0, 0, 0));

        gridLayout_12->addWidget(lightPoint_2, 1, 0, 1, 1);

        lightPoint_5 = new LightPoint(layoutWidget_14);
        lightPoint_5->setObjectName(QStringLiteral("lightPoint_5"));
        lightPoint_5->setAutoFillBackground(false);
        lightPoint_5->setBgColor(QColor(255, 0, 0, 0));

        gridLayout_12->addWidget(lightPoint_5, 1, 3, 1, 1);

        lightPoint_3 = new LightPoint(layoutWidget_14);
        lightPoint_3->setObjectName(QStringLiteral("lightPoint_3"));
        lightPoint_3->setAutoFillBackground(false);
        lightPoint_3->setBgColor(QColor(255, 0, 0, 0));

        gridLayout_12->addWidget(lightPoint_3, 1, 1, 1, 1);

        lightPoint_6 = new LightPoint(layoutWidget_14);
        lightPoint_6->setObjectName(QStringLiteral("lightPoint_6"));
        lightPoint_6->setAutoFillBackground(false);
        lightPoint_6->setBgColor(QColor(255, 0, 0, 0));

        gridLayout_12->addWidget(lightPoint_6, 1, 4, 1, 1);

        layoutWidget_15 = new QWidget(panelItem_4);
        layoutWidget_15->setObjectName(QStringLiteral("layoutWidget_15"));
        layoutWidget_15->setGeometry(QRect(14, 26, 87, 81));
        gridLayout_13 = new QGridLayout(layoutWidget_15);
        gridLayout_13->setObjectName(QStringLiteral("gridLayout_13"));
        label_83 = new QLabel(layoutWidget_15);
        label_83->setObjectName(QStringLiteral("label_83"));
        label_83->setLayoutDirection(Qt::LeftToRight);
        label_83->setTextFormat(Qt::AutoText);
        label_83->setScaledContents(false);
        label_83->setAlignment(Qt::AlignCenter);

        gridLayout_13->addWidget(label_83, 0, 0, 1, 1);

        lightPoint_1 = new LightPoint(layoutWidget_15);
        lightPoint_1->setObjectName(QStringLiteral("lightPoint_1"));
        lightPoint_1->setEnabled(true);
        lightPoint_1->setAutoFillBackground(false);
        lightPoint_1->setBgColor(QColor(101, 255, 101, 0));

        gridLayout_13->addWidget(lightPoint_1, 1, 0, 1, 1);

        layoutWidget_16 = new QWidget(panelItem_4);
        layoutWidget_16->setObjectName(QStringLiteral("layoutWidget_16"));
        layoutWidget_16->setGeometry(QRect(8, 188, 411, 71));
        gridLayout_14 = new QGridLayout(layoutWidget_16);
        gridLayout_14->setObjectName(QStringLiteral("gridLayout_14"));
        label_84 = new QLabel(layoutWidget_16);
        label_84->setObjectName(QStringLiteral("label_84"));
        label_84->setLayoutDirection(Qt::LeftToRight);
        label_84->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_84->setTextFormat(Qt::AutoText);
        label_84->setScaledContents(false);
        label_84->setAlignment(Qt::AlignCenter);

        gridLayout_14->addWidget(label_84, 0, 0, 1, 1);

        label_85 = new QLabel(layoutWidget_16);
        label_85->setObjectName(QStringLiteral("label_85"));
        label_85->setStyleSheet(QString::fromUtf8("font: 19pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(255, 170, 127);"));
        label_85->setAlignment(Qt::AlignCenter);

        gridLayout_14->addWidget(label_85, 1, 0, 1, 1);

        label_86 = new QLabel(layoutWidget_16);
        label_86->setObjectName(QStringLiteral("label_86"));
        label_86->setStyleSheet(QString::fromUtf8("font: 19pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(125, 255, 145);"));
        label_86->setAlignment(Qt::AlignCenter);

        gridLayout_14->addWidget(label_86, 1, 1, 1, 1);

        label_87 = new QLabel(layoutWidget_16);
        label_87->setObjectName(QStringLiteral("label_87"));
        label_87->setStyleSheet(QString::fromUtf8("font: 19pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(108, 211, 255);"));
        label_87->setAlignment(Qt::AlignCenter);

        gridLayout_14->addWidget(label_87, 1, 2, 1, 1);

        label_88 = new QLabel(layoutWidget_16);
        label_88->setObjectName(QStringLiteral("label_88"));
        label_88->setStyleSheet(QString::fromUtf8("font: 19pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(175, 128, 255);"));
        label_88->setAlignment(Qt::AlignCenter);

        gridLayout_14->addWidget(label_88, 1, 3, 1, 1);

        label_89 = new QLabel(layoutWidget_16);
        label_89->setObjectName(QStringLiteral("label_89"));
        label_89->setLayoutDirection(Qt::LeftToRight);
        label_89->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_89->setTextFormat(Qt::AutoText);
        label_89->setScaledContents(false);
        label_89->setAlignment(Qt::AlignCenter);

        gridLayout_14->addWidget(label_89, 0, 1, 1, 1);

        label_90 = new QLabel(layoutWidget_16);
        label_90->setObjectName(QStringLiteral("label_90"));
        label_90->setLayoutDirection(Qt::LeftToRight);
        label_90->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_90->setTextFormat(Qt::AutoText);
        label_90->setScaledContents(false);
        label_90->setAlignment(Qt::AlignCenter);

        gridLayout_14->addWidget(label_90, 0, 2, 1, 1);

        label_91 = new QLabel(layoutWidget_16);
        label_91->setObjectName(QStringLiteral("label_91"));
        label_91->setLayoutDirection(Qt::LeftToRight);
        label_91->setStyleSheet(QString::fromUtf8("font: 9pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_91->setTextFormat(Qt::AutoText);
        label_91->setScaledContents(false);
        label_91->setAlignment(Qt::AlignCenter);

        gridLayout_14->addWidget(label_91, 0, 3, 1, 1);

        panelItem_3 = new PanelItem(page_5);
        panelItem_3->setObjectName(QStringLiteral("panelItem_3"));
        panelItem_3->setGeometry(QRect(434, 332, 219, 267));
        panelItem_3->setStyleSheet(QStringLiteral(""));
        panelItem_3->setTitleHeight(20);
        panelItem_3->setTitleFont(font3);
        panelItem_3->setBorderRadius(10);
        rcCh2 = new XProgressBar(panelItem_3);
        rcCh2->setObjectName(QStringLiteral("rcCh2"));
        rcCh2->setGeometry(QRect(43, 44, 169, 16));
        rcCh2->setMinimum(1000);
        rcCh2->setMaximum(2000);
        rcCh2->setValue(1500);
        rcCh2->setTextVisible(true);
        rcCh2->setOrientation(Qt::Horizontal);
        rcCh2->setValueColor(QColor(161, 29, 255));
        rcCh2->setBgColor(QColor(243, 245, 244));
        rcCh2->setTextColor(QColor(0, 0, 0));
        rcCh2->setAutoRadius(true);
        rcCh2->setShowProgressRadius(true);
        rcCh2->setBorderWidth(0);
        rcCh1 = new XProgressBar(panelItem_3);
        rcCh1->setObjectName(QStringLiteral("rcCh1"));
        rcCh1->setGeometry(QRect(43, 23, 169, 16));
        rcCh1->setMinimum(1000);
        rcCh1->setMaximum(2000);
        rcCh1->setValue(1500);
        rcCh1->setTextVisible(true);
        rcCh1->setOrientation(Qt::Horizontal);
        rcCh1->setValueColor(QColor(255, 43, 64));
        rcCh1->setBgColor(QColor(243, 245, 244));
        rcCh1->setTextColor(QColor(0, 0, 0));
        rcCh1->setAutoRadius(true);
        rcCh1->setShowProgressRadius(true);
        rcCh1->setBorderWidth(0);
        rcCh3 = new XProgressBar(panelItem_3);
        rcCh3->setObjectName(QStringLiteral("rcCh3"));
        rcCh3->setGeometry(QRect(43, 64, 169, 16));
        rcCh3->setMinimum(1000);
        rcCh3->setMaximum(2000);
        rcCh3->setValue(1500);
        rcCh3->setTextVisible(true);
        rcCh3->setOrientation(Qt::Horizontal);
        rcCh3->setValueColor(QColor(28, 58, 255));
        rcCh3->setBgColor(QColor(243, 245, 244));
        rcCh3->setTextColor(QColor(0, 0, 0));
        rcCh3->setAutoRadius(true);
        rcCh3->setShowProgressRadius(true);
        rcCh3->setBorderWidth(0);
        rcCh4 = new XProgressBar(panelItem_3);
        rcCh4->setObjectName(QStringLiteral("rcCh4"));
        rcCh4->setGeometry(QRect(43, 85, 169, 16));
        rcCh4->setMinimum(1000);
        rcCh4->setMaximum(2000);
        rcCh4->setValue(1500);
        rcCh4->setTextVisible(true);
        rcCh4->setOrientation(Qt::Horizontal);
        rcCh4->setValueColor(QColor(42, 255, 238));
        rcCh4->setBgColor(QColor(243, 245, 244));
        rcCh4->setTextColor(QColor(0, 0, 0));
        rcCh4->setAutoRadius(true);
        rcCh4->setShowProgressRadius(true);
        rcCh4->setBorderWidth(0);
        rcCh5 = new XProgressBar(panelItem_3);
        rcCh5->setObjectName(QStringLiteral("rcCh5"));
        rcCh5->setGeometry(QRect(43, 105, 169, 16));
        rcCh5->setMinimum(1000);
        rcCh5->setMaximum(2000);
        rcCh5->setValue(1500);
        rcCh5->setTextVisible(true);
        rcCh5->setOrientation(Qt::Horizontal);
        rcCh5->setValueColor(QColor(49, 166, 0));
        rcCh5->setBgColor(QColor(243, 245, 244));
        rcCh5->setTextColor(QColor(0, 0, 0));
        rcCh5->setAutoRadius(true);
        rcCh5->setShowProgressRadius(true);
        rcCh5->setBorderWidth(0);
        rcCh6 = new XProgressBar(panelItem_3);
        rcCh6->setObjectName(QStringLiteral("rcCh6"));
        rcCh6->setGeometry(QRect(43, 126, 169, 16));
        rcCh6->setMinimum(1000);
        rcCh6->setMaximum(2000);
        rcCh6->setValue(1500);
        rcCh6->setTextVisible(true);
        rcCh6->setOrientation(Qt::Horizontal);
        rcCh6->setValueColor(QColor(255, 201, 162));
        rcCh6->setBgColor(QColor(243, 245, 244));
        rcCh6->setTextColor(QColor(0, 0, 0));
        rcCh6->setAutoRadius(true);
        rcCh6->setShowProgressRadius(true);
        rcCh6->setBorderWidth(0);
        rcCh7 = new XProgressBar(panelItem_3);
        rcCh7->setObjectName(QStringLiteral("rcCh7"));
        rcCh7->setGeometry(QRect(43, 146, 169, 16));
        rcCh7->setMinimum(1000);
        rcCh7->setMaximum(2000);
        rcCh7->setValue(1500);
        rcCh7->setTextVisible(true);
        rcCh7->setOrientation(Qt::Horizontal);
        rcCh7->setValueColor(QColor(255, 85, 150));
        rcCh7->setBgColor(QColor(243, 245, 244));
        rcCh7->setTextColor(QColor(0, 0, 0));
        rcCh7->setAutoRadius(true);
        rcCh7->setShowProgressRadius(true);
        rcCh7->setBorderWidth(0);
        rcCh11 = new XProgressBar(panelItem_3);
        rcCh11->setObjectName(QStringLiteral("rcCh11"));
        rcCh11->setGeometry(QRect(43, 228, 169, 16));
        rcCh11->setMinimum(1000);
        rcCh11->setMaximum(2000);
        rcCh11->setValue(1500);
        rcCh11->setTextVisible(true);
        rcCh11->setOrientation(Qt::Horizontal);
        rcCh11->setValueColor(QColor(125, 255, 26));
        rcCh11->setBgColor(QColor(243, 245, 244));
        rcCh11->setTextColor(QColor(0, 0, 0));
        rcCh11->setAutoRadius(true);
        rcCh11->setShowProgressRadius(true);
        rcCh11->setBorderWidth(0);
        rcCh10 = new XProgressBar(panelItem_3);
        rcCh10->setObjectName(QStringLiteral("rcCh10"));
        rcCh10->setGeometry(QRect(43, 207, 169, 16));
        rcCh10->setMinimum(1000);
        rcCh10->setMaximum(2000);
        rcCh10->setValue(1500);
        rcCh10->setTextVisible(true);
        rcCh10->setOrientation(Qt::Horizontal);
        rcCh10->setValueColor(QColor(255, 255, 127));
        rcCh10->setBgColor(QColor(243, 245, 244));
        rcCh10->setTextColor(QColor(0, 0, 0));
        rcCh10->setAutoRadius(true);
        rcCh10->setShowProgressRadius(true);
        rcCh10->setBorderWidth(0);
        rcCh9 = new XProgressBar(panelItem_3);
        rcCh9->setObjectName(QStringLiteral("rcCh9"));
        rcCh9->setGeometry(QRect(43, 187, 169, 16));
        rcCh9->setMinimum(1000);
        rcCh9->setMaximum(2000);
        rcCh9->setValue(1500);
        rcCh9->setTextVisible(true);
        rcCh9->setOrientation(Qt::Horizontal);
        rcCh9->setValueColor(QColor(255, 94, 94));
        rcCh9->setBgColor(QColor(243, 245, 244));
        rcCh9->setTextColor(QColor(0, 0, 0));
        rcCh9->setAutoRadius(true);
        rcCh9->setShowProgressRadius(true);
        rcCh9->setBorderWidth(0);
        rcCh8 = new XProgressBar(panelItem_3);
        rcCh8->setObjectName(QStringLiteral("rcCh8"));
        rcCh8->setGeometry(QRect(43, 166, 169, 16));
        rcCh8->setMinimum(1000);
        rcCh8->setMaximum(2000);
        rcCh8->setValue(1500);
        rcCh8->setTextVisible(true);
        rcCh8->setOrientation(Qt::Horizontal);
        rcCh8->setValueColor(QColor(17, 255, 116));
        rcCh8->setBgColor(QColor(243, 245, 244));
        rcCh8->setTextColor(QColor(0, 0, 0));
        rcCh8->setAutoRadius(true);
        rcCh8->setShowProgressRadius(true);
        rcCh8->setBorderWidth(0);
        rcCh12 = new XProgressBar(panelItem_3);
        rcCh12->setObjectName(QStringLiteral("rcCh12"));
        rcCh12->setGeometry(QRect(43, 248, 169, 16));
        rcCh12->setMinimum(1000);
        rcCh12->setMaximum(2000);
        rcCh12->setValue(1500);
        rcCh12->setTextVisible(true);
        rcCh12->setOrientation(Qt::Horizontal);
        rcCh12->setValueColor(QColor(255, 170, 255));
        rcCh12->setBgColor(QColor(243, 245, 244));
        rcCh12->setTextColor(QColor(0, 0, 0));
        rcCh12->setAutoRadius(true);
        rcCh12->setShowProgressRadius(true);
        rcCh12->setBorderWidth(0);
        label_62 = new QLabel(panelItem_3);
        label_62->setObjectName(QStringLiteral("label_62"));
        label_62->setGeometry(QRect(5, 126, 32, 16));
        label_62->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_63 = new QLabel(panelItem_3);
        label_63->setObjectName(QStringLiteral("label_63"));
        label_63->setGeometry(QRect(5, 146, 32, 16));
        label_63->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_64 = new QLabel(panelItem_3);
        label_64->setObjectName(QStringLiteral("label_64"));
        label_64->setGeometry(QRect(5, 166, 32, 16));
        label_64->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_65 = new QLabel(panelItem_3);
        label_65->setObjectName(QStringLiteral("label_65"));
        label_65->setGeometry(QRect(5, 187, 32, 16));
        label_65->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_66 = new QLabel(panelItem_3);
        label_66->setObjectName(QStringLiteral("label_66"));
        label_66->setGeometry(QRect(5, 207, 32, 16));
        label_66->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_67 = new QLabel(panelItem_3);
        label_67->setObjectName(QStringLiteral("label_67"));
        label_67->setGeometry(QRect(5, 228, 32, 16));
        label_67->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_68 = new QLabel(panelItem_3);
        label_68->setObjectName(QStringLiteral("label_68"));
        label_68->setGeometry(QRect(5, 248, 32, 16));
        label_68->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_33 = new QLabel(panelItem_3);
        label_33->setObjectName(QStringLiteral("label_33"));
        label_33->setGeometry(QRect(5, 23, 32, 15));
        label_33->setMinimumSize(QSize(32, 15));
        label_33->setMaximumSize(QSize(32, 15));
        label_33->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_58 = new QLabel(panelItem_3);
        label_58->setObjectName(QStringLiteral("label_58"));
        label_58->setGeometry(QRect(5, 44, 32, 16));
        label_58->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_59 = new QLabel(panelItem_3);
        label_59->setObjectName(QStringLiteral("label_59"));
        label_59->setGeometry(QRect(5, 64, 32, 16));
        label_59->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_60 = new QLabel(panelItem_3);
        label_60->setObjectName(QStringLiteral("label_60"));
        label_60->setGeometry(QRect(5, 85, 32, 16));
        label_60->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_61 = new QLabel(panelItem_3);
        label_61->setObjectName(QStringLiteral("label_61"));
        label_61->setGeometry(QRect(5, 105, 32, 16));
        label_61->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        gaugeyaw = new GaugeCompass(page_5);
        gaugeyaw->setObjectName(QStringLiteral("gaugeyaw"));
        gaugeyaw->setGeometry(QRect(268, 168, 157, 159));
        gaugeyaw->setValue(360);
        gaugeyaw->setPrecision(0);
        gaugeyaw->setAnimation(true);
        gaugeyaw->setAnimationStep(30);
        gaugerollpitch = new GaugePlane(page_5);
        gaugerollpitch->setObjectName(QStringLiteral("gaugerollpitch"));
        gaugerollpitch->setGeometry(QRect(260, 6, 171, 155));
        stl3d = new MyWidget(page_5);
        stl3d->setObjectName(QStringLiteral("stl3d"));
        stl3d->setGeometry(QRect(2, 6, 255, 245));
        stl3d->setAutoFillBackground(true);
        widget_3 = new QWidget(page_5);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setGeometry(QRect(162, 260, 101, 61));
        widget_3->setAutoFillBackground(true);
        gridLayout_5 = new QGridLayout(widget_3);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        oulajiao = new QRadioButton(widget_3);
        oulajiao->setObjectName(QStringLiteral("oulajiao"));
        oulajiao->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        oulajiao->setChecked(false);

        gridLayout_5->addWidget(oulajiao, 1, 0, 1, 1);

        siyuanshu = new QRadioButton(widget_3);
        siyuanshu->setObjectName(QStringLiteral("siyuanshu"));
        siyuanshu->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        siyuanshu->setChecked(true);

        gridLayout_5->addWidget(siyuanshu, 0, 0, 1, 1);

        widget_4 = new QWidget(page_5);
        widget_4->setObjectName(QStringLiteral("widget_4"));
        widget_4->setGeometry(QRect(0, 258, 161, 65));
        widget_4->setAutoFillBackground(true);
        radioButton_6 = new QRadioButton(widget_4);
        radioButton_6->setObjectName(QStringLiteral("radioButton_6"));
        radioButton_6->setGeometry(QRect(4, 10, 73, 20));
        radioButton_6->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        radioButton_6->setChecked(true);
        radioButton_10 = new QRadioButton(widget_4);
        radioButton_10->setObjectName(QStringLiteral("radioButton_10"));
        radioButton_10->setGeometry(QRect(84, 10, 75, 20));
        radioButton_10->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        radioButton_10->setChecked(false);
        radioButton_7 = new QRadioButton(widget_4);
        radioButton_7->setObjectName(QStringLiteral("radioButton_7"));
        radioButton_7->setGeometry(QRect(4, 36, 75, 19));
        radioButton_7->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        radioButton_7->setChecked(false);
        radioButton_11 = new QRadioButton(widget_4);
        radioButton_11->setObjectName(QStringLiteral("radioButton_11"));
        radioButton_11->setGeometry(QRect(84, 36, 73, 19));
        radioButton_11->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        radioButton_11->setChecked(false);
        stackedWidget->addWidget(page_5);
        page_6 = new QWidget();
        page_6->setObjectName(QStringLiteral("page_6"));
        Scope = new QPushButton(page_6);
        Scope->setObjectName(QStringLiteral("Scope"));
        Scope->setGeometry(QRect(184, 110, 113, 121));
        label_36 = new QLabel(page_6);
        label_36->setObjectName(QStringLiteral("label_36"));
        label_36->setGeometry(QRect(196, 232, 117, 69));
        label_36->setStyleSheet(QString::fromUtf8("font: 13pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_37 = new QLabel(page_6);
        label_37->setObjectName(QStringLiteral("label_37"));
        label_37->setGeometry(QRect(624, 274, 237, 111));
        label_37->setStyleSheet(QString::fromUtf8("font: 13pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        ShowDetailInfo = new QPushButton(page_6);
        ShowDetailInfo->setObjectName(QStringLiteral("ShowDetailInfo"));
        ShowDetailInfo->setGeometry(QRect(382, 110, 123, 117));
        label_38 = new QLabel(page_6);
        label_38->setObjectName(QStringLiteral("label_38"));
        label_38->setGeometry(QRect(388, 232, 117, 69));
        label_38->setStyleSheet(QString::fromUtf8("font: 13pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        stackedWidget->addWidget(page_6);
        page_7 = new QWidget();
        page_7->setObjectName(QStringLiteral("page_7"));
        layoutWidget_2 = new QWidget(page_7);
        layoutWidget_2->setObjectName(QStringLiteral("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(290, 6, 238, 415));
        gridLayout_8 = new QGridLayout(layoutWidget_2);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        gridLayout_8->setContentsMargins(0, 0, 0, 0);
        slider_8 = new Slider(layoutWidget_2);
        slider_8->setObjectName(QStringLiteral("slider_8"));
        slider_8->setMinimumSize(QSize(210, 76));
        slider_8->setMaximumSize(QSize(210, 76));
        slider_8->setAutoFillBackground(true);

        gridLayout_8->addWidget(slider_8, 2, 1, 1, 1);

        slider_9 = new Slider(layoutWidget_2);
        slider_9->setObjectName(QStringLiteral("slider_9"));
        slider_9->setMinimumSize(QSize(210, 76));
        slider_9->setMaximumSize(QSize(210, 76));
        slider_9->setAutoFillBackground(true);

        gridLayout_8->addWidget(slider_9, 3, 1, 1, 1);

        slider_10 = new Slider(layoutWidget_2);
        slider_10->setObjectName(QStringLiteral("slider_10"));
        slider_10->setMinimumSize(QSize(210, 76));
        slider_10->setMaximumSize(QSize(210, 76));
        slider_10->setAutoFillBackground(true);

        gridLayout_8->addWidget(slider_10, 4, 1, 1, 1);

        slider_6 = new Slider(layoutWidget_2);
        slider_6->setObjectName(QStringLiteral("slider_6"));
        slider_6->setMinimumSize(QSize(210, 76));
        slider_6->setMaximumSize(QSize(210, 76));
        slider_6->setAutoFillBackground(true);

        gridLayout_8->addWidget(slider_6, 0, 1, 1, 1);

        slider_7 = new Slider(layoutWidget_2);
        slider_7->setObjectName(QStringLiteral("slider_7"));
        slider_7->setMinimumSize(QSize(210, 76));
        slider_7->setMaximumSize(QSize(210, 76));
        slider_7->setAutoFillBackground(true);

        gridLayout_8->addWidget(slider_7, 1, 1, 1, 1);

        label_5 = new QLabel(layoutWidget_2);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_5->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(label_5, 0, 0, 1, 1);

        label_6 = new QLabel(layoutWidget_2);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_6->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(label_6, 1, 0, 1, 1);

        label_15 = new QLabel(layoutWidget_2);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_15->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(label_15, 2, 0, 1, 1);

        label_17 = new QLabel(layoutWidget_2);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_17->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(label_17, 4, 0, 1, 1);

        label_21 = new QLabel(layoutWidget_2);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_21->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(label_21, 3, 0, 1, 1);

        layoutWidget_3 = new QWidget(page_7);
        layoutWidget_3->setObjectName(QStringLiteral("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(574, 8, 238, 415));
        gridLayout_9 = new QGridLayout(layoutWidget_3);
        gridLayout_9->setObjectName(QStringLiteral("gridLayout_9"));
        gridLayout_9->setContentsMargins(0, 0, 0, 0);
        slider_13 = new Slider(layoutWidget_3);
        slider_13->setObjectName(QStringLiteral("slider_13"));
        slider_13->setMinimumSize(QSize(210, 76));
        slider_13->setMaximumSize(QSize(210, 76));
        slider_13->setAutoFillBackground(true);

        gridLayout_9->addWidget(slider_13, 2, 1, 1, 1);

        slider_14 = new Slider(layoutWidget_3);
        slider_14->setObjectName(QStringLiteral("slider_14"));
        slider_14->setMinimumSize(QSize(210, 76));
        slider_14->setMaximumSize(QSize(210, 76));
        slider_14->setAutoFillBackground(true);

        gridLayout_9->addWidget(slider_14, 3, 1, 1, 1);

        slider_15 = new Slider(layoutWidget_3);
        slider_15->setObjectName(QStringLiteral("slider_15"));
        slider_15->setMinimumSize(QSize(210, 76));
        slider_15->setMaximumSize(QSize(210, 76));
        slider_15->setAutoFillBackground(true);

        gridLayout_9->addWidget(slider_15, 4, 1, 1, 1);

        slider_11 = new Slider(layoutWidget_3);
        slider_11->setObjectName(QStringLiteral("slider_11"));
        slider_11->setMinimumSize(QSize(210, 76));
        slider_11->setMaximumSize(QSize(210, 76));
        slider_11->setAutoFillBackground(true);

        gridLayout_9->addWidget(slider_11, 0, 1, 1, 1);

        slider_12 = new Slider(layoutWidget_3);
        slider_12->setObjectName(QStringLiteral("slider_12"));
        slider_12->setMinimumSize(QSize(210, 76));
        slider_12->setMaximumSize(QSize(210, 76));
        slider_12->setAutoFillBackground(true);

        gridLayout_9->addWidget(slider_12, 1, 1, 1, 1);

        label_22 = new QLabel(layoutWidget_3);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_22->setAlignment(Qt::AlignCenter);

        gridLayout_9->addWidget(label_22, 0, 0, 1, 1);

        label_24 = new QLabel(layoutWidget_3);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_24->setAlignment(Qt::AlignCenter);

        gridLayout_9->addWidget(label_24, 1, 0, 1, 1);

        label_25 = new QLabel(layoutWidget_3);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_25->setAlignment(Qt::AlignCenter);

        gridLayout_9->addWidget(label_25, 2, 0, 1, 1);

        label_26 = new QLabel(layoutWidget_3);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_26->setAlignment(Qt::AlignCenter);

        gridLayout_9->addWidget(label_26, 4, 0, 1, 1);

        label_27 = new QLabel(layoutWidget_3);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_27->setAlignment(Qt::AlignCenter);

        gridLayout_9->addWidget(label_27, 3, 0, 1, 1);

        layoutWidget_4 = new QWidget(page_7);
        layoutWidget_4->setObjectName(QStringLiteral("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(852, 10, 238, 415));
        gridLayout_10 = new QGridLayout(layoutWidget_4);
        gridLayout_10->setObjectName(QStringLiteral("gridLayout_10"));
        gridLayout_10->setContentsMargins(0, 0, 0, 0);
        slider_18 = new Slider(layoutWidget_4);
        slider_18->setObjectName(QStringLiteral("slider_18"));
        slider_18->setMinimumSize(QSize(210, 76));
        slider_18->setMaximumSize(QSize(210, 76));
        slider_18->setAutoFillBackground(true);

        gridLayout_10->addWidget(slider_18, 2, 1, 1, 1);

        slider_19 = new Slider(layoutWidget_4);
        slider_19->setObjectName(QStringLiteral("slider_19"));
        slider_19->setMinimumSize(QSize(210, 76));
        slider_19->setMaximumSize(QSize(210, 76));
        slider_19->setAutoFillBackground(true);

        gridLayout_10->addWidget(slider_19, 3, 1, 1, 1);

        slider_20 = new Slider(layoutWidget_4);
        slider_20->setObjectName(QStringLiteral("slider_20"));
        slider_20->setMinimumSize(QSize(210, 76));
        slider_20->setMaximumSize(QSize(210, 76));
        slider_20->setAutoFillBackground(true);

        gridLayout_10->addWidget(slider_20, 4, 1, 1, 1);

        slider_16 = new Slider(layoutWidget_4);
        slider_16->setObjectName(QStringLiteral("slider_16"));
        slider_16->setMinimumSize(QSize(210, 76));
        slider_16->setMaximumSize(QSize(210, 76));
        slider_16->setAutoFillBackground(true);

        gridLayout_10->addWidget(slider_16, 0, 1, 1, 1);

        slider_17 = new Slider(layoutWidget_4);
        slider_17->setObjectName(QStringLiteral("slider_17"));
        slider_17->setMinimumSize(QSize(210, 76));
        slider_17->setMaximumSize(QSize(210, 76));
        slider_17->setAutoFillBackground(true);

        gridLayout_10->addWidget(slider_17, 1, 1, 1, 1);

        label_28 = new QLabel(layoutWidget_4);
        label_28->setObjectName(QStringLiteral("label_28"));
        label_28->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_28->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(label_28, 0, 0, 1, 1);

        label_29 = new QLabel(layoutWidget_4);
        label_29->setObjectName(QStringLiteral("label_29"));
        label_29->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_29->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(label_29, 1, 0, 1, 1);

        label_30 = new QLabel(layoutWidget_4);
        label_30->setObjectName(QStringLiteral("label_30"));
        label_30->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_30->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(label_30, 2, 0, 1, 1);

        label_31 = new QLabel(layoutWidget_4);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_31->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(label_31, 4, 0, 1, 1);

        label_32 = new QLabel(layoutWidget_4);
        label_32->setObjectName(QStringLiteral("label_32"));
        label_32->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_32->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(label_32, 3, 0, 1, 1);

        btnSliderSend_1 = new QPushButton(page_7);
        btnSliderSend_1->setObjectName(QStringLiteral("btnSliderSend_1"));
        btnSliderSend_1->setGeometry(QRect(52, 426, 147, 55));
        btnSliderSend_1->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(225, 225, 225);border:2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}\n"
"QPushButton:hover{background-color:rgb(255, 241, 240); color: black;}\n"
"QPushButton:pressed{background-color:rgb(204, 228, 247);border-style: inset;}\n"
"QPushButton{font: 14pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";}\n"
"\n"
"\n"
""));
        layoutWidget2 = new QWidget(page_7);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(6, 8, 237, 415));
        gridLayout_7 = new QGridLayout(layoutWidget2);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        gridLayout_7->setContentsMargins(0, 0, 0, 0);
        slider_3 = new Slider(layoutWidget2);
        slider_3->setObjectName(QStringLiteral("slider_3"));
        slider_3->setMinimumSize(QSize(210, 76));
        slider_3->setMaximumSize(QSize(210, 76));
        slider_3->setAutoFillBackground(true);

        gridLayout_7->addWidget(slider_3, 2, 1, 1, 1);

        slider_4 = new Slider(layoutWidget2);
        slider_4->setObjectName(QStringLiteral("slider_4"));
        slider_4->setMinimumSize(QSize(210, 76));
        slider_4->setMaximumSize(QSize(210, 76));
        slider_4->setAutoFillBackground(true);

        gridLayout_7->addWidget(slider_4, 3, 1, 1, 1);

        slider_5 = new Slider(layoutWidget2);
        slider_5->setObjectName(QStringLiteral("slider_5"));
        slider_5->setMinimumSize(QSize(210, 76));
        slider_5->setMaximumSize(QSize(210, 76));
        slider_5->setAutoFillBackground(true);

        gridLayout_7->addWidget(slider_5, 4, 1, 1, 1);

        slider_1 = new Slider(layoutWidget2);
        slider_1->setObjectName(QStringLiteral("slider_1"));
        slider_1->setMinimumSize(QSize(210, 76));
        slider_1->setMaximumSize(QSize(210, 76));
        slider_1->setAutoFillBackground(true);

        gridLayout_7->addWidget(slider_1, 0, 1, 1, 1);

        slider_2 = new Slider(layoutWidget2);
        slider_2->setObjectName(QStringLiteral("slider_2"));
        slider_2->setMinimumSize(QSize(210, 76));
        slider_2->setMaximumSize(QSize(210, 76));
        slider_2->setAutoFillBackground(true);

        gridLayout_7->addWidget(slider_2, 1, 1, 1, 1);

        label_1 = new QLabel(layoutWidget2);
        label_1->setObjectName(QStringLiteral("label_1"));
        label_1->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_1->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(label_1, 0, 0, 1, 1);

        label_2 = new QLabel(layoutWidget2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_2->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(label_2, 1, 0, 1, 1);

        label_3 = new QLabel(layoutWidget2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_3->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(label_3, 2, 0, 1, 1);

        label = new QLabel(layoutWidget2);
        label->setObjectName(QStringLiteral("label"));
        label->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(label, 4, 0, 1, 1);

        label_4 = new QLabel(layoutWidget2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(label_4, 3, 0, 1, 1);

        btnSliderSend_11 = new QPushButton(page_7);
        btnSliderSend_11->setObjectName(QStringLiteral("btnSliderSend_11"));
        btnSliderSend_11->setGeometry(QRect(28, 500, 129, 41));
        btnSliderSend_31 = new QPushButton(page_7);
        btnSliderSend_31->setObjectName(QStringLiteral("btnSliderSend_31"));
        btnSliderSend_31->setGeometry(QRect(28, 550, 129, 43));
        btnSliderSend_2 = new QPushButton(page_7);
        btnSliderSend_2->setObjectName(QStringLiteral("btnSliderSend_2"));
        btnSliderSend_2->setGeometry(QRect(344, 424, 147, 55));
        btnSliderSend_2->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(225, 225, 225);border:2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}\n"
"QPushButton:hover{background-color:rgb(255, 241, 240); color: black;}\n"
"QPushButton:pressed{background-color:rgb(204, 228, 247);border-style: inset;}\n"
"QPushButton{font: 14pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";}\n"
"\n"
"\n"
""));
        btnSliderSend_3 = new QPushButton(page_7);
        btnSliderSend_3->setObjectName(QStringLiteral("btnSliderSend_3"));
        btnSliderSend_3->setGeometry(QRect(636, 426, 147, 55));
        btnSliderSend_3->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(225, 225, 225);border:2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}\n"
"QPushButton:hover{background-color:rgb(255, 241, 240); color: black;}\n"
"QPushButton:pressed{background-color:rgb(204, 228, 247);border-style: inset;}\n"
"QPushButton{font: 14pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";}\n"
"\n"
"\n"
""));
        btnSliderSend_4 = new QPushButton(page_7);
        btnSliderSend_4->setObjectName(QStringLiteral("btnSliderSend_4"));
        btnSliderSend_4->setGeometry(QRect(912, 428, 147, 55));
        btnSliderSend_4->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(225, 225, 225);border:2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}\n"
"QPushButton:hover{background-color:rgb(255, 241, 240); color: black;}\n"
"QPushButton:pressed{background-color:rgb(204, 228, 247);border-style: inset;}\n"
"QPushButton{font: 14pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";}\n"
"\n"
"\n"
""));
        line = new QFrame(page_7);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(0, 480, 1097, 16));
        line->setStyleSheet(QStringLiteral("color: rgb(42, 134, 255);"));
        line->setFrameShadow(QFrame::Plain);
        line->setLineWidth(3);
        line->setFrameShape(QFrame::HLine);
        stackedWidget->addWidget(page_7);
        page_8 = new QWidget();
        page_8->setObjectName(QStringLiteral("page_8"));
        label_35 = new QLabel(page_8);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setGeometry(QRect(892, 352, 145, 63));
        label_35->setStyleSheet(QString::fromUtf8("font: 13pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        SystemMagnify = new QComboBox(page_8);
        SystemMagnify->setObjectName(QStringLiteral("SystemMagnify"));
        SystemMagnify->setGeometry(QRect(318, 462, 119, 33));
        SystemMagnify->setFont(font1);
        SystemMagnify->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        label_39 = new QLabel(page_8);
        label_39->setObjectName(QStringLiteral("label_39"));
        label_39->setGeometry(QRect(142, 462, 163, 31));
        label_39->setStyleSheet(QString::fromUtf8("font: 13pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_40 = new QLabel(page_8);
        label_40->setObjectName(QStringLiteral("label_40"));
        label_40->setGeometry(QRect(174, 424, 447, 41));
        label_40->setStyleSheet(QString::fromUtf8("font: 13pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        stackedWidget->addWidget(page_8);
        navButtonGroup = new NavButtonGroup(Widget);
        navButtonGroup->setObjectName(QStringLiteral("navButtonGroup"));
        navButtonGroup->setGeometry(QRect(410, 602, 411, 30));
        navButtonGroup->setAutoFillBackground(false);
        navButtonGroup->setLineColor(QColor(255, 142, 61));
        layoutWidget_17 = new QWidget(Widget);
        layoutWidget_17->setObjectName(QStringLiteral("layoutWidget_17"));
        layoutWidget_17->setGeometry(QRect(412, 694, 135, 66));
        gridLayout_15 = new QGridLayout(layoutWidget_17);
        gridLayout_15->setObjectName(QStringLiteral("gridLayout_15"));
        gridLayout_15->setContentsMargins(0, 0, 0, 0);
        label_92 = new QLabel(layoutWidget_17);
        label_92->setObjectName(QStringLiteral("label_92"));
        label_92->setMinimumSize(QSize(72, 26));
        label_92->setLayoutDirection(Qt::LeftToRight);
        label_92->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_92->setTextFormat(Qt::AutoText);
        label_92->setScaledContents(false);
        label_92->setAlignment(Qt::AlignCenter);

        gridLayout_15->addWidget(label_92, 0, 0, 1, 1);

        Voltage = new QLabel(layoutWidget_17);
        Voltage->setObjectName(QStringLiteral("Voltage"));
        Voltage->setStyleSheet(QString::fromUtf8("font: 15pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(255, 33, 33);"));
        Voltage->setAlignment(Qt::AlignCenter);

        gridLayout_15->addWidget(Voltage, 1, 0, 1, 1);

        battery = new Battery(layoutWidget_17);
        battery->setObjectName(QStringLiteral("battery"));
        battery->setMinimumSize(QSize(55, 27));
        battery->setMaximumSize(QSize(55, 27));
        battery->setValue(80);
        battery->setAlarmValue(30);
        battery->setStep(1);
        battery->setBorderWidth(4);
        battery->setBorderRadius(5);

        gridLayout_15->addWidget(battery, 1, 1, 1, 1);

        voltage_sel = new QComboBox(layoutWidget_17);
        voltage_sel->setObjectName(QStringLiteral("voltage_sel"));
        voltage_sel->setStyleSheet(QString::fromUtf8("font: 13pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));

        gridLayout_15->addWidget(voltage_sel, 0, 1, 1, 1);

        layoutWidget3 = new QWidget(Widget);
        layoutWidget3->setObjectName(QStringLiteral("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(416, 638, 353, 22));
        gridLayout = new QGridLayout(layoutWidget3);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        RecNum_2 = new QLabel(layoutWidget3);
        RecNum_2->setObjectName(QStringLiteral("RecNum_2"));
        RecNum_2->setStyleSheet(QStringLiteral("font: 75 11pt \"Consolas\";"));

        gridLayout->addWidget(RecNum_2, 0, 1, 1, 1);

        label_10 = new QLabel(layoutWidget3);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));

        gridLayout->addWidget(label_10, 0, 2, 1, 1);

        label_18 = new QLabel(layoutWidget3);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));

        gridLayout->addWidget(label_18, 0, 0, 1, 1);

        RecNum_3 = new QLabel(layoutWidget3);
        RecNum_3->setObjectName(QStringLiteral("RecNum_3"));
        RecNum_3->setStyleSheet(QStringLiteral("font: 75 11pt \"Consolas\";"));

        gridLayout->addWidget(RecNum_3, 0, 3, 1, 1);

        label_16 = new QLabel(layoutWidget3);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));

        gridLayout->addWidget(label_16, 0, 4, 1, 1);

        RecNum_4 = new QLabel(layoutWidget3);
        RecNum_4->setObjectName(QStringLiteral("RecNum_4"));
        RecNum_4->setStyleSheet(QStringLiteral("font: 75 11pt \"Consolas\";"));

        gridLayout->addWidget(RecNum_4, 0, 5, 1, 1);

        layoutWidget4 = new QWidget(Widget);
        layoutWidget4->setObjectName(QStringLiteral("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(550, 696, 173, 61));
        gridLayout_2 = new QGridLayout(layoutWidget4);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        label_100 = new QLabel(layoutWidget4);
        label_100->setObjectName(QStringLiteral("label_100"));
        label_100->setMinimumSize(QSize(72, 26));
        label_100->setLayoutDirection(Qt::LeftToRight);
        label_100->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_100->setTextFormat(Qt::AutoText);
        label_100->setScaledContents(false);
        label_100->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_100, 0, 0, 1, 1);

        label_20 = new QLabel(layoutWidget4);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setMinimumSize(QSize(72, 26));
        label_20->setLayoutDirection(Qt::LeftToRight);
        label_20->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_20->setTextFormat(Qt::AutoText);
        label_20->setScaledContents(false);
        label_20->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_20, 0, 1, 1, 1);

        label_101 = new QLabel(layoutWidget4);
        label_101->setObjectName(QStringLiteral("label_101"));
        label_101->setStyleSheet(QString::fromUtf8("font: 15pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(255, 33, 33);"));
        label_101->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_101, 1, 0, 1, 1);

        errPer = new QLabel(layoutWidget4);
        errPer->setObjectName(QStringLiteral("errPer"));
        errPer->setStyleSheet(QString::fromUtf8("font: 15pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
""));
        errPer->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(errPer, 1, 1, 1, 1);

        ConnectBtn = new NavButtonGroup(Widget);
        ConnectBtn->setObjectName(QStringLiteral("ConnectBtn"));
        ConnectBtn->setGeometry(QRect(886, 608, 55, 53));
        QFont font4;
        font4.setFamily(QString::fromUtf8("\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200"));
        font4.setPointSize(10);
        font4.setBold(false);
        font4.setItalic(false);
        font4.setWeight(50);
        ConnectBtn->setFont(font4);
        ConnectBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        ConnectBtn->setAutoFillBackground(false);
        ConnectBtn->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        ConnectBtn->setInterval(300);
        ConnectBtn->setLinePosition(NavButtonGroup::LinePosition_Right);
        ConnectBtn->setLineColor(QColor(37, 106, 195));
        ConnectBtn->setBtnHoverColor(QColor(160, 122, 169, 100));
        ConnectBtn->setBtnDarkColor(QColor(169, 128, 165, 180));
        ConnectWidget = new QStackedWidget(Widget);
        ConnectWidget->setObjectName(QStringLiteral("ConnectWidget"));
        ConnectWidget->setGeometry(QRect(938, 602, 161, 125));
        page_3 = new QWidget();
        page_3->setObjectName(QStringLiteral("page_3"));
        label_9 = new QLabel(page_3);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(3, 8, 59, 19));
        QFont font5;
        font5.setFamily(QString::fromUtf8("\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200"));
        font5.setPointSize(12);
        font5.setBold(false);
        font5.setItalic(false);
        font5.setWeight(50);
        label_9->setFont(font5);
        label_9->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_9->setFrameShape(QFrame::NoFrame);
        label_9->setFrameShadow(QFrame::Plain);
        SerialNum = new QComboBox(page_3);
        SerialNum->setObjectName(QStringLiteral("SerialNum"));
        SerialNum->setGeometry(QRect(64, 6, 85, 22));
        QFont font6;
        font6.setPointSize(12);
        SerialNum->setFont(font6);
        label_11 = new QLabel(page_3);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(4, 38, 59, 19));
        label_11->setFont(font5);
        label_11->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_11->setFrameShape(QFrame::NoFrame);
        label_11->setFrameShadow(QFrame::Plain);
        SerialBaud = new QComboBox(page_3);
        SerialBaud->setObjectName(QStringLiteral("SerialBaud"));
        SerialBaud->setGeometry(QRect(65, 36, 89, 22));
        SerialBaud->setFont(font6);
        SerialBaud->setEditable(true);
        SerialBaud->setFrame(true);
        label_12 = new QLabel(page_3);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(4, 68, 63, 18));
        label_12->setFont(font5);
        label_12->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_12->setFrameShape(QFrame::NoFrame);
        label_12->setFrameShadow(QFrame::Plain);
        SerialData = new QComboBox(page_3);
        SerialData->setObjectName(QStringLiteral("SerialData"));
        SerialData->setGeometry(QRect(74, 66, 67, 21));
        SerialData->setFont(font6);
        layoutWidget5 = new QWidget(page_3);
        layoutWidget5->setObjectName(QStringLiteral("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(6, 94, 155, 31));
        horizontalLayout = new QHBoxLayout(layoutWidget5);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_13 = new QLabel(layoutWidget5);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setFont(font5);
        label_13->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_13->setFrameShape(QFrame::NoFrame);
        label_13->setFrameShadow(QFrame::Plain);

        horizontalLayout->addWidget(label_13);

        comboBox_13 = new QComboBox(layoutWidget5);
        comboBox_13->setObjectName(QStringLiteral("comboBox_13"));
        comboBox_13->setFont(font1);
        comboBox_13->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));

        horizontalLayout->addWidget(comboBox_13);

        label_14 = new QLabel(layoutWidget5);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setFont(font5);
        label_14->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        label_14->setFrameShape(QFrame::NoFrame);
        label_14->setFrameShadow(QFrame::Plain);

        horizontalLayout->addWidget(label_14);

        comboBox_14 = new QComboBox(layoutWidget5);
        comboBox_14->setObjectName(QStringLiteral("comboBox_14"));
        comboBox_14->setFont(font1);
        comboBox_14->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));

        horizontalLayout->addWidget(comboBox_14);

        ConnectWidget->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName(QStringLiteral("page_4"));
        label_19 = new QLabel(page_4);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(26, 44, 107, 27));
        label_19->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        ConnectWidget->addWidget(page_4);
        layoutWidget6 = new QWidget(Widget);
        layoutWidget6->setObjectName(QStringLiteral("layoutWidget6"));
        layoutWidget6->setGeometry(QRect(730, 676, 171, 48));
        gridLayout_4 = new QGridLayout(layoutWidget6);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(layoutWidget6);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));

        gridLayout_4->addWidget(label_7, 0, 0, 1, 1);

        RecNum = new QLabel(layoutWidget6);
        RecNum->setObjectName(QStringLiteral("RecNum"));
        RecNum->setStyleSheet(QStringLiteral("font: 75 11pt \"Consolas\";"));

        gridLayout_4->addWidget(RecNum, 0, 1, 1, 1);

        label_8 = new QLabel(layoutWidget6);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setStyleSheet(QString::fromUtf8("font: 11pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));

        gridLayout_4->addWidget(label_8, 1, 0, 1, 1);

        SendNum = new QLabel(layoutWidget6);
        SendNum->setObjectName(QStringLiteral("SendNum"));
        SendNum->setStyleSheet(QStringLiteral("font: 75 11pt \"Consolas\";"));

        gridLayout_4->addWidget(SendNum, 1, 1, 1, 1);

        NumClear = new QPushButton(Widget);
        NumClear->setObjectName(QStringLiteral("NumClear"));
        NumClear->setEnabled(true);
        NumClear->setGeometry(QRect(748, 728, 80, 29));
        sizePolicy.setHeightForWidth(NumClear->sizePolicy().hasHeightForWidth());
        NumClear->setSizePolicy(sizePolicy);
        NumClear->setMinimumSize(QSize(0, 0));
        NumClear->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        NumClear->raise();
        layoutWidget->raise();
        layoutWidget->raise();
        layoutWidget->raise();
        textEdit->raise();
        label_23->raise();
        Btn_open->raise();
        stackedWidget->raise();
        navButtonGroup->raise();
        layoutWidget_17->raise();
        ConnectBtn->raise();
        ConnectWidget->raise();

        retranslateUi(Widget);

        stackedWidget->setCurrentIndex(0);
        SendIfOne->setCurrentIndex(0);
        BtnSend->setDefault(false);
        SystemMagnify->setCurrentIndex(4);
        voltage_sel->setCurrentIndex(3);
        ConnectWidget->setCurrentIndex(0);
        SerialNum->setCurrentIndex(-1);
        SerialBaud->setCurrentIndex(4);
        SerialData->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "UpCom_GXT", Q_NULLPTR));
        textEdit->setHtml(QApplication::translate("Widget", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#ffa22f;\">&gt;&gt;\346\254\242\350\277\216\344\275\277\347\224\250\346\255\244\344\270\212\344\275\215\346\234\272&lt;&lt; \345\275\223\345\211\215\347\211\210\346\234\254\357\274\232V1.2</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#ffa22f;\">\345\217\202\350\200\203\357\274\232VOFA+,\345\214\277\345\220\215\344\270\212\344\275\215\346\234\272V7\357\274\214V4.5\357\274\214\351\207\216\347\201\253\344\270\262\345\217\243\350\260\203\350"
                        "\257\225\345\212\251\346\211\213</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#6bffee;\">\345\217\213\346\203\205\350\277\236\346\216\245\357\274\232</span>	VOFA+:  	https://www.vofa.plus/</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">	ANO_V7:	http://anotc.com/</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">	\351\207\216\347\201\253:	https://embedfire.com/</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", Q_NULLPTR));
        label_23->setText(QApplication::translate("Widget", "Dev V1.21", Q_NULLPTR));
        panelItem_5->setTitleText(QApplication::translate("Widget", "\346\225\260\346\215\256\345\217\221\351\200\201", Q_NULLPTR));
        SendAscii->setText(QApplication::translate("Widget", "ASCII", Q_NULLPTR));
        SendHex->setText(QApplication::translate("Widget", "HEX", Q_NULLPTR));
        nav_sendifOne->setTexts(QApplication::translate("Widget", "\345\215\225\346\235\241\345\217\221\351\200\201;\345\244\232\346\235\241\345\217\221\351\200\201", Q_NULLPTR));
        BtnSend->setText(QApplication::translate("Widget", "\345\217\221\351\200\201", Q_NULLPTR));
        send_buf->setPlainText(QString());
        label_99->setText(QApplication::translate("Widget", "\345\217\221\351\200\201\345\221\250\346\234\237", Q_NULLPTR));
        label_98->setText(QApplication::translate("Widget", "ms", Q_NULLPTR));
        SendAuto->setText(QApplication::translate("Widget", "\350\207\252\345\212\250\345\217\221\351\200\201", Q_NULLPTR));
        SendNewL->setText(QApplication::translate("Widget", "\345\217\221\351\200\201\346\226\260\350\241\214", Q_NULLPTR));
        panelItem_6->setTitleText(QApplication::translate("Widget", "\346\225\260\346\215\256\346\216\245\346\224\266", Q_NULLPTR));
        ShowOpen->setText(QApplication::translate("Widget", "\345\274\200\345\220\257\346\230\276\347\244\272", Q_NULLPTR));
        BtnRecClr->setText(QApplication::translate("Widget", "\346\270\205\347\251\272\346\230\276\347\244\272", Q_NULLPTR));
        ShowAscii->setText(QApplication::translate("Widget", "ASCII", Q_NULLPTR));
        ShowHex->setText(QApplication::translate("Widget", "HEX", Q_NULLPTR));
        ShowTime->setText(QApplication::translate("Widget", "\346\230\276\347\244\272\346\227\266\351\227\264", Q_NULLPTR));
        RemoveAgree->setText(QApplication::translate("Widget", "\350\277\207\346\273\244\345\215\217\350\256\256", Q_NULLPTR));
        panelItem_4->setTitleText(QApplication::translate("Widget", "\350\257\246\347\273\206\347\212\266\346\200\201", Q_NULLPTR));
        label_70->setText(QApplication::translate("Widget", "ROL", Q_NULLPTR));
        Roll->setText(QApplication::translate("Widget", "0.00", Q_NULLPTR));
        Pitch->setText(QApplication::translate("Widget", "0.00", Q_NULLPTR));
        Yaw->setText(QApplication::translate("Widget", "0.00", Q_NULLPTR));
        label_74->setText(QApplication::translate("Widget", "0.00", Q_NULLPTR));
        label_75->setText(QApplication::translate("Widget", "PIT", Q_NULLPTR));
        label_76->setText(QApplication::translate("Widget", "YAW", Q_NULLPTR));
        label_77->setText(QApplication::translate("Widget", "HIGH", Q_NULLPTR));
        label_78->setText(QApplication::translate("Widget", "\347\212\266\346\200\2011", Q_NULLPTR));
        label_79->setText(QApplication::translate("Widget", "\347\212\266\346\200\2012", Q_NULLPTR));
        label_80->setText(QApplication::translate("Widget", "\347\212\266\346\200\2013", Q_NULLPTR));
        label_81->setText(QApplication::translate("Widget", "\347\212\266\346\200\2014", Q_NULLPTR));
        label_82->setText(QApplication::translate("Widget", "\347\212\266\346\200\2015", Q_NULLPTR));
        label_83->setText(QApplication::translate("Widget", "\346\200\273\347\212\266\346\200\201", Q_NULLPTR));
        label_84->setText(QApplication::translate("Widget", "ROL", Q_NULLPTR));
        label_85->setText(QApplication::translate("Widget", "0.00", Q_NULLPTR));
        label_86->setText(QApplication::translate("Widget", "0.00", Q_NULLPTR));
        label_87->setText(QApplication::translate("Widget", "0.00", Q_NULLPTR));
        label_88->setText(QApplication::translate("Widget", "0.00", Q_NULLPTR));
        label_89->setText(QApplication::translate("Widget", "PIT", Q_NULLPTR));
        label_90->setText(QApplication::translate("Widget", "YAW", Q_NULLPTR));
        label_91->setText(QApplication::translate("Widget", "HIGH", Q_NULLPTR));
        panelItem_3->setTitleText(QApplication::translate("Widget", "\351\201\245\346\216\247\345\231\250\346\225\260\345\200\274", Q_NULLPTR));
        label_62->setText(QApplication::translate("Widget", "Ch6", Q_NULLPTR));
        label_63->setText(QApplication::translate("Widget", "Ch7", Q_NULLPTR));
        label_64->setText(QApplication::translate("Widget", "Ch8", Q_NULLPTR));
        label_65->setText(QApplication::translate("Widget", "Ch9", Q_NULLPTR));
        label_66->setText(QApplication::translate("Widget", "Ch10", Q_NULLPTR));
        label_67->setText(QApplication::translate("Widget", "Ch11", Q_NULLPTR));
        label_68->setText(QApplication::translate("Widget", "Ch12", Q_NULLPTR));
        label_33->setText(QApplication::translate("Widget", "Ch1", Q_NULLPTR));
        label_58->setText(QApplication::translate("Widget", "Ch2", Q_NULLPTR));
        label_59->setText(QApplication::translate("Widget", "Ch3", Q_NULLPTR));
        label_60->setText(QApplication::translate("Widget", "Ch4", Q_NULLPTR));
        label_61->setText(QApplication::translate("Widget", "Ch5", Q_NULLPTR));
        oulajiao->setText(QApplication::translate("Widget", "\346\254\247\346\213\211\350\247\222", Q_NULLPTR));
        siyuanshu->setText(QApplication::translate("Widget", "\345\233\233\345\205\203\346\225\260", Q_NULLPTR));
        radioButton_6->setText(QApplication::translate("Widget", "\346\250\241\345\236\2131", Q_NULLPTR));
        radioButton_10->setText(QApplication::translate("Widget", "\346\250\241\345\236\2133", Q_NULLPTR));
        radioButton_7->setText(QApplication::translate("Widget", "\346\250\241\345\236\2132", Q_NULLPTR));
        radioButton_11->setText(QApplication::translate("Widget", "\346\250\241\345\236\2134", Q_NULLPTR));
        Scope->setText(QApplication::translate("Widget", "Scope", Q_NULLPTR));
        label_36->setText(QApplication::translate("Widget", "\347\244\272\346\263\242\345\231\250", Q_NULLPTR));
        label_37->setText(QApplication::translate("Widget", "\346\233\264\345\244\232\346\217\222\344\273\266\347\255\211\345\276\205\346\233\264\346\226\260", Q_NULLPTR));
        ShowDetailInfo->setText(QApplication::translate("Widget", "DetailInfo", Q_NULLPTR));
        label_38->setText(QApplication::translate("Widget", "\350\257\246\347\273\206\344\277\241\346\201\257", Q_NULLPTR));
        label_5->setText(QApplication::translate("Widget", "6", Q_NULLPTR));
        label_6->setText(QApplication::translate("Widget", "7", Q_NULLPTR));
        label_15->setText(QApplication::translate("Widget", "8", Q_NULLPTR));
        label_17->setText(QApplication::translate("Widget", "10", Q_NULLPTR));
        label_21->setText(QApplication::translate("Widget", "9", Q_NULLPTR));
        label_22->setText(QApplication::translate("Widget", "11", Q_NULLPTR));
        label_24->setText(QApplication::translate("Widget", "12", Q_NULLPTR));
        label_25->setText(QApplication::translate("Widget", "13", Q_NULLPTR));
        label_26->setText(QApplication::translate("Widget", "15", Q_NULLPTR));
        label_27->setText(QApplication::translate("Widget", "14", Q_NULLPTR));
        label_28->setText(QApplication::translate("Widget", "16", Q_NULLPTR));
        label_29->setText(QApplication::translate("Widget", "17", Q_NULLPTR));
        label_30->setText(QApplication::translate("Widget", "18", Q_NULLPTR));
        label_31->setText(QApplication::translate("Widget", "20", Q_NULLPTR));
        label_32->setText(QApplication::translate("Widget", "19", Q_NULLPTR));
        btnSliderSend_1->setText(QApplication::translate("Widget", "\345\217\221\351\200\201\347\273\2041", Q_NULLPTR));
        label_1->setText(QApplication::translate("Widget", "1", Q_NULLPTR));
        label_2->setText(QApplication::translate("Widget", "2", Q_NULLPTR));
        label_3->setText(QApplication::translate("Widget", "3", Q_NULLPTR));
        label->setText(QApplication::translate("Widget", "5", Q_NULLPTR));
        label_4->setText(QApplication::translate("Widget", "4", Q_NULLPTR));
        btnSliderSend_11->setText(QApplication::translate("Widget", "\345\220\257\345\212\250", Q_NULLPTR));
        btnSliderSend_31->setText(QApplication::translate("Widget", "\345\201\234\346\255\242", Q_NULLPTR));
        btnSliderSend_2->setText(QApplication::translate("Widget", "\345\217\221\351\200\201\347\273\2042", Q_NULLPTR));
        btnSliderSend_3->setText(QApplication::translate("Widget", "\345\217\221\351\200\201\347\273\2043", Q_NULLPTR));
        btnSliderSend_4->setText(QApplication::translate("Widget", "\345\217\221\351\200\201\347\273\2044", Q_NULLPTR));
        label_35->setText(QApplication::translate("Widget", "\347\255\211\345\276\205\346\233\264\346\226\260\357\274\232", Q_NULLPTR));
        SystemMagnify->clear();
        SystemMagnify->insertItems(0, QStringList()
         << QApplication::translate("Widget", "50%", Q_NULLPTR)
         << QApplication::translate("Widget", "60%", Q_NULLPTR)
         << QApplication::translate("Widget", "75%", Q_NULLPTR)
         << QApplication::translate("Widget", "85%", Q_NULLPTR)
         << QApplication::translate("Widget", "100%(\346\216\250\350\215\220)", Q_NULLPTR)
         << QApplication::translate("Widget", "125%", Q_NULLPTR)
         << QApplication::translate("Widget", "150%", Q_NULLPTR)
         << QApplication::translate("Widget", "175%", Q_NULLPTR)
         << QApplication::translate("Widget", "200%", Q_NULLPTR)
         << QApplication::translate("Widget", "225%", Q_NULLPTR)
        );
        label_39->setText(QApplication::translate("Widget", "\351\207\215\350\246\201\357\274\210\347\225\214\351\235\242\347\274\251\346\224\276\357\274\211\357\274\232", Q_NULLPTR));
        label_40->setText(QApplication::translate("Widget", "\345\275\223\344\275\240\345\217\221\347\216\260\347\225\214\351\235\242\346\230\276\347\244\272\344\270\215\346\255\243\345\270\270\346\227\266\350\257\267\346\233\264\346\224\271\346\255\244\351\200\211\351\241\271\345\271\266\351\207\215\345\220\257", Q_NULLPTR));
        navButtonGroup->setTexts(QApplication::translate("Widget", "\345\237\272\346\234\254\346\224\266\345\217\221;\346\216\247\345\210\266\350\257\246\346\203\205;\346\217\222\344\273\266\347\256\241\347\220\206;PID\350\260\203\350\212\202;\347\263\273\347\273\237\350\256\276\347\275\256", Q_NULLPTR));
        label_92->setText(QApplication::translate("Widget", "\347\224\265\346\261\240\347\224\265\345\216\213", Q_NULLPTR));
        Voltage->setText(QApplication::translate("Widget", "None", Q_NULLPTR));
        voltage_sel->clear();
        voltage_sel->insertItems(0, QStringList()
         << QApplication::translate("Widget", "0s", Q_NULLPTR)
         << QApplication::translate("Widget", "1s", Q_NULLPTR)
         << QApplication::translate("Widget", "2s", Q_NULLPTR)
         << QApplication::translate("Widget", "3s", Q_NULLPTR)
         << QApplication::translate("Widget", "4s", Q_NULLPTR)
         << QApplication::translate("Widget", "5s", Q_NULLPTR)
         << QApplication::translate("Widget", "6s", Q_NULLPTR)
         << QApplication::translate("Widget", "7s", Q_NULLPTR)
         << QApplication::translate("Widget", "8s", Q_NULLPTR)
        );
        RecNum_2->setText(QApplication::translate("Widget", "COM", Q_NULLPTR));
        label_10->setText(QApplication::translate("Widget", "\347\241\254\344\273\266\347\211\210\346\234\254:", Q_NULLPTR));
        label_18->setText(QApplication::translate("Widget", "\350\277\236\346\216\245\346\226\271\345\274\217:", Q_NULLPTR));
        RecNum_3->setText(QApplication::translate("Widget", "None", Q_NULLPTR));
        label_16->setText(QApplication::translate("Widget", "\350\275\257\344\273\266\347\211\210\346\234\254:", Q_NULLPTR));
        RecNum_4->setText(QApplication::translate("Widget", "None", Q_NULLPTR));
        label_100->setText(QApplication::translate("Widget", "\344\277\241\345\217\267", Q_NULLPTR));
        label_20->setText(QApplication::translate("Widget", "\351\224\231\350\257\257\347\240\201\347\216\207", Q_NULLPTR));
        label_101->setText(QApplication::translate("Widget", "None", Q_NULLPTR));
        errPer->setText(QApplication::translate("Widget", "None", Q_NULLPTR));
        ConnectBtn->setTexts(QApplication::translate("Widget", "COM;USB", Q_NULLPTR));
        label_9->setText(QApplication::translate("Widget", "\344\270\262\345\217\243\345\217\267", Q_NULLPTR));
        label_11->setText(QApplication::translate("Widget", "\346\263\242\347\211\271\347\216\207", Q_NULLPTR));
        SerialBaud->clear();
        SerialBaud->insertItems(0, QStringList()
         << QApplication::translate("Widget", "4800", Q_NULLPTR)
         << QApplication::translate("Widget", "9600", Q_NULLPTR)
         << QApplication::translate("Widget", "38400", Q_NULLPTR)
         << QApplication::translate("Widget", "57600", Q_NULLPTR)
         << QApplication::translate("Widget", "115200", Q_NULLPTR)
         << QApplication::translate("Widget", "230400", Q_NULLPTR)
         << QApplication::translate("Widget", "256000", Q_NULLPTR)
         << QApplication::translate("Widget", "460800", Q_NULLPTR)
         << QApplication::translate("Widget", "500000", Q_NULLPTR)
         << QApplication::translate("Widget", "921600", Q_NULLPTR)
        );
        SerialBaud->setCurrentText(QApplication::translate("Widget", "115200", Q_NULLPTR));
        label_12->setText(QApplication::translate("Widget", "\346\225\260\346\215\256\344\275\215", Q_NULLPTR));
        SerialData->clear();
        SerialData->insertItems(0, QStringList()
         << QApplication::translate("Widget", "5", Q_NULLPTR)
         << QApplication::translate("Widget", "6", Q_NULLPTR)
         << QApplication::translate("Widget", "7", Q_NULLPTR)
         << QApplication::translate("Widget", "8", Q_NULLPTR)
        );
        label_13->setText(QApplication::translate("Widget", "\346\240\241", Q_NULLPTR));
        comboBox_13->clear();
        comboBox_13->insertItems(0, QStringList()
         << QApplication::translate("Widget", "\346\227\240", Q_NULLPTR)
         << QApplication::translate("Widget", "\345\245\207", Q_NULLPTR)
         << QApplication::translate("Widget", "\345\201\266", Q_NULLPTR)
        );
        label_14->setText(QApplication::translate("Widget", "\345\201\234", Q_NULLPTR));
        comboBox_14->clear();
        comboBox_14->insertItems(0, QStringList()
         << QApplication::translate("Widget", "1", Q_NULLPTR)
         << QApplication::translate("Widget", "1.5", Q_NULLPTR)
         << QApplication::translate("Widget", "2", Q_NULLPTR)
        );
        label_19->setText(QApplication::translate("Widget", "\346\232\202\346\227\240\347\255\211\345\276\205\346\233\264\346\226\260", Q_NULLPTR));
        label_7->setText(QApplication::translate("Widget", "\346\216\245\346\224\266\350\256\241\346\225\260:", Q_NULLPTR));
        RecNum->setText(QApplication::translate("Widget", "0", Q_NULLPTR));
        label_8->setText(QApplication::translate("Widget", "\345\217\221\351\200\201\350\256\241\346\225\260:", Q_NULLPTR));
        SendNum->setText(QApplication::translate("Widget", "0", Q_NULLPTR));
        NumClear->setText(QApplication::translate("Widget", "\346\270\205\347\251\272\350\256\241\346\225\260", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
