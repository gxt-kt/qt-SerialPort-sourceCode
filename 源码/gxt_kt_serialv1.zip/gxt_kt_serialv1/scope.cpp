﻿#include "scope.h"
#include "ui_scope.h"
#include "mythread.h"
#include <QtWidgets/QApplication>
#include "GuiThreadRun.hpp"
#include <GL/glut.h>
#include "config.h"
#include "datastorage.h"
QString getRandomColor(void);
//#include "xcustomplot.h"
QTime *time_ms;

int sbx,sby;
bool scopeifopen=0;
int xMaxPoint=1000;//X轴点数

long long int last_cnt=0;//记录上次暂停时的计数
long long int startPoint=0;
long long reaCnt=0;

Ui::scope *ScopeUi=nullptr;
QCPGraph *gcurve[21];//gcurve[0-20];
int gi=0;
int fpsVal[21]={0};
void Delay_MSec_Suspend(unsigned int msec)
{
    QTime _Timer = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < _Timer );
}
int ReceiveMode=1;//为1为匿名模式，0为时间模式
long long int xxx=0;

scope* scop;
scope::scope(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::scope)
{
    scop=this;
    ui->setupUi(this);
    setAttribute(Qt::WA_QuitOnClose,false);
    ScopeUi=ui;//scope ui初始化的地方
    SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);//设置优先级
    scopeifopen=1;
    this->setWindowTitle("Scope");

    //this->setAttribute(Qt::WA_DeleteOnClose);//设置关闭时销毁

    QSettings settings("MySoft", "Star Runner");

    //ui->ScopePlot->setOpenGl(true);//不开启opengl//gpu加速还不靠谱
    qDebug()<<"opengl:"<<ui->ScopePlot->openGl();

    QString qstrname = Config().Get("user","name").toString();
    qDebug() <<"qstrname="<< qstrname;
    Config().Set("user","name","config_ini_test");

    thread = new MyThread(this);

    pPlot1 = ui->ScopePlot;

#if 0
     pPlot1->setBackground(QBrush(Qt::black));
    //设置坐标文本颜色
    pPlot1->xAxis->setTickLabelColor(Qt::white);
    pPlot1->yAxis->setTickLabelColor(Qt::white);
    //设置坐标名称文本颜色
    pPlot1->xAxis->setLabelColor(Qt::white);
    pPlot1->yAxis->setLabelColor(Qt::white);
    //设置坐标轴颜色
    pPlot1->xAxis->setBasePen(QPen(Qt::white));
    pPlot1->xAxis->setTickPen(QPen(Qt::white));
    pPlot1->xAxis->setSubTickPen(QPen(Qt::white));


    //2222
//    pPlot1->axisRect()->setBackground(QBrush(Qt::black));//背景黑色
//    pPlot1->xAxis->grid()->setPen(QPen(QColor(180, 180, 180), 1, Qt::PenStyle::DashLine));//网格白色虚线
//    pPlot1->yAxis->grid()->setPen(QPen(QColor(180, 180, 180), 1, Qt::PenStyle::DashLine));//网格白色虚线
//    pPlot1->xAxis->grid()->setSubGridPen(QPen(QColor(50, 50, 50), 1, Qt::DotLine));//网格浅色点线
//    pPlot1->yAxis->grid()->setSubGridPen(QPen(QColor(50, 50, 50), 1, Qt::DotLine));//网格浅色点线
//    pPlot1->xAxis->grid()->setSubGridVisible(true);//显示x轴子网格线
//    pPlot1->yAxis->grid()->setSubGridVisible(true);//显示要轴子网格线
//    pPlot1->xAxis->grid()->setZeroLinePen(QPen(Qt::white));//x轴0线颜色白色
//    pPlot1->yAxis->grid()->setZeroLinePen(QPen(Qt::white));//y轴0线颜色白色

#endif

    pPlot1->xAxis->ticker()->setTickCount(10);
    pPlot1->yAxis->ticker()->setTickCount(20);
    pPlot1->xAxis->ticker()->setTickStepStrategy(QCPAxisTicker::tssReadability);
    pPlot1->yAxis->ticker()->setTickStepStrategy(QCPAxisTicker::tssReadability);
    QPlot_init(pPlot1);// 初始化图表1
    pPlot1->setNoAntialiasingOnDrag(1);

//   Tim30Hz =new QTimer();
//   Tim30Hz->setInterval(5);//200hz添加数据
//   connect(Tim30Hz,SIGNAL(timeout()),this,SLOT(Tim30HzTimOut()));
//   Tim30Hz->start();

//    Tim1000Hz =new QTimer();//1000hz+1
//    Tim1000Hz->setInterval(1);
//    connect(Tim1000Hz,SIGNAL(timeout()),this,SLOT(Tim1000HzTimOut()));
//    Tim1000Hz->start();

        QVariant chcol;//遍历scope_ch
        for(int i=1;i<=20;i++){//遍历
        ScopeCh* allScopeCh=findChild<ScopeCh*>("Scope_Ch"+QString::number(i));
        if(allScopeCh!=NULL)//
        {
            chcol=Config().Get("ScopeCol",QString("ch%1").arg(i));//先看看有没有
            if(chcol.Color!=NULL){allScopeCh->setChCol(chcol.value<QColor>());/*qDebug("!=Null")*/;}
            else qDebug("Can't find ScopeCol--chn");

            bool ifcheck=Config().Get("ScopeCol",QString("ch_check%1").arg(i)).value<bool>();
            allScopeCh->setChecked(ifcheck);

            allScopeCh->setChNText(QString("Ch%1").arg(i));
        }
        }
       connect(ui->ShowAll,&QPushButton::clicked,[=](){
           //恢复曲线
           ui->ScopePlot->xAxis->rescale(true);//调整X轴的范围，使之能显示出所有的曲线的X值
           ui->ScopePlot->yAxis->rescale(true);//调整Y轴的范围，使之能显示出所有的曲线的Y值
           //ui->ScopePlot->replot();  // 刷新
       });
       connect(ui->ShowClear,&QPushButton::clicked,[=](){
           //清空曲线
           for(gi=1;gi<=20;gi++){gcurve[gi]->data().data()->clear();}
            startPoint=0;
            last_cnt=QString::number(QDateTime::currentMSecsSinceEpoch()).toLongLong();
            reaCnt=0;
            xxx=0;
           //ui->ScopePlot->replot();  // 刷新
       });

       connect(ui->ScopeShow,&SwitchButton::checkedChanged,[=](){
            if(ui->ScopeShow->getChecked()==1){//打开状态
                last_cnt=QString::number(QDateTime::currentMSecsSinceEpoch()).toLongLong();
            }else{//关闭状态
                startPoint=reaCnt;//记录上次的实际值
            }
       });
        connect(ui->AutoDetect,&QPushButton::clicked,[=](){
            for(int i=1;i<=20;i++){//遍历
            ScopeCh* allScopeCh=findChild<ScopeCh*>("Scope_Ch"+QString::number(i));
            if(allScopeCh!=NULL)//
            {
                if(allScopeCh->getFpsVal()!=0) allScopeCh->setChecked(1);
                else allScopeCh->setChecked(0);
            }
            }
            ui->AutoRun->setChecked(1);
       });


        QRegExp rx("^[0-9]*[1-9][0-9]*$");//只允许输入数字 //正则表达式
        //QRegExp rx("^[0-9]{1,1000000}$");//
        QValidator *valid = new QRegExpValidator(rx,0);
        ui->Xpoint->lineEdit()->setValidator(valid);
        xMaxPoint=Config().Get("Scope",QString("Xpoint")).value<int>();
        ui->Xpoint->lineEdit()->setText(QString("%1").arg(xMaxPoint));
        connect(ui->Xpoint,&QComboBox::editTextChanged,[=](){
            xMaxPoint=ui->Xpoint->lineEdit()->text().toInt();
            Config().Set("Scope",QString("Xpoint"),xMaxPoint);
       });


}

// 绘图图表初始化
void scope::QPlot_init(QCustomPlot *customPlot)
{
    QTimer *timer = new QTimer(this);//创建定时器，刷新数据
    timer->start(16);//设置0可以尽可能快地刷新
    connect(timer,SIGNAL(timeout()),this,SLOT(TimeData_Update()));

    // 图表添加曲线
    for(gi=1;gi<=20;gi++){gcurve[gi]=customPlot->addGraph();}

    // 设置坐标轴名称
//    customPlot->xAxis->setLabel("X");
//    customPlot->yAxis->setLabel("Y");
    // 设置y坐标轴显示范围
    //customPlot->yAxis->setRange(-120,120);
    // 显示图表的图例
    //customPlot->legend->setVisible(true);
    // 添加曲线名称
    //pGraph1_1->setName("one");
    //pGraph1_2->setName("two");

//    QPen spen=pGraph1_1->pen();
//    spen.setWidth(10);
//    pGraph1_1->setPen(spen);
//    pGraph1_2->setPen(spen);
//    pGraph1_3->setPen(spen);

    // 设置波形曲线的复选框字体颜色
    ui->ScopePlot->selectionRect()->setPen(QPen(Qt::black,1,Qt::DashLine));//设置选框的样式：虚线
    //ui->ScopePlot->selectionRect()->setBrush(QBrush(QColor(0,0,100,50)));//设置选框的样式： 浅蓝-半透
    ui->ScopePlot->selectionRect()->setBrush(QBrush(QColor(200,200,100,60)));//设置选框的样式： 黄色-半透
    ui->ScopePlot->setSelectionRectMode(QCP::SelectionRectMode::srmZoom);
    // 支持鼠标拖拽轴的范围、滚动缩放轴的范围，左键点选图层（每条曲线独占一个图层）
    ui->ScopePlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);

    // 允许用户用鼠标拖动轴范围，用鼠标滚轮缩放，点击选择图形:
    //customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);

    //thread->start();
}

// 定时器溢出处理槽函数。用来生成曲线的坐标数据。
void scope::TimeData_Update(void)
{
    // 将坐标数据，传递给曲线
    if(ui->ScopeShow->getChecked()==1)//开启显示，才显示图像
    {
        Show_Plot(pPlot1);//
    }
    else
    {
        Show_Plot(pPlot1);
    }
}
QList<XxwTracer *> m_dataTracers;//
XxwTraceLine  *m_lineTracer;//直线
XxwTracer *m_xTracer;//x轴
XxwTracer *m_yTracer;//y轴
// 曲线更新绘图
void Show_Plot(QCustomPlot *customPlot)
{
    if(ScopeUi->ShowPoint->isChecked()==1){ScopeUi->ScopePlot->showTracer(true);}else {ScopeUi->ScopePlot->showTracer(false);}

    //if(ScopeUi->Scope_Ch2->getIfChecked()==1) {pGraph1_2->setVisible(true);pGraph1_2->setPen(QPen(ScopeUi->Scope_Ch2->getChCol()));}else pGraph1_2->setVisible(false);
    //if(ScopeUi->Scope_Ch3->getIfChecked()==1) {pGraph1_3->setVisible(true);pGraph1_3->setPen(QPen(ScopeUi->Scope_Ch3->getChCol()));}else pGraph1_3->setVisible(false);
    if(ScopeUi->Scope_Ch1->getIfChecked()==1) {
        gcurve[1]->setVisible(true);
        QColor colc;
        colc.setRgb(255,0,0);
        //colc=ScopeUi->Scope_Ch1->getChCol();
        colc.setAlpha(255);
        gcurve[1]->setPen(QPen(colc));
        //pGraph1_1->setLineStyle(QCPGraph::lsStepCenter);
        //pGraph1_1->setScatterStyle(QCPScatterStyle::ssDiamond);
    }else gcurve[1]->setVisible(false);

//    for(gi=1;gi<=20;gi++)
//    {
//        ScopeCh* scopechi=scop->findChild<ScopeCh*>("Scope_Ch"+QString::number(gi));
//        if(scopechi!=NULL)//找到相应scopeCh
//        {
//            if(scopechi->getIfChecked()==1)
//            {gcurve[gi]->setVisible(true);gcurve[gi]->setPen(QPen(scopechi->getChCol()));}
//            else gcurve[gi]->setVisible(false);
//        }
//    }

    if(ScopeUi->ScopeShow->getChecked()==1)
    {
        if(ScopeUi->AutoRun->isChecked()==1)//使用自动滚动
        {
            ScopeUi->ScopePlot->xAxis->rescale(true);//调整X轴的范围，使之能显示出所有的曲线的X值
            ScopeUi->ScopePlot->yAxis->rescale(true);//调整Y轴的范围，使之能显示出所有的曲线的Y值//这两句话是根据全图来的，所以需要放在开头
            QCPRange XAxis_Range=ScopeUi->ScopePlot->xAxis->range();//获取调整前坐标轴数值

            if(XAxis_Range.upper-XAxis_Range.lower>xMaxPoint)
            {
                XAxis_Range.lower=XAxis_Range.upper-xMaxPoint;
                ScopeUi->ScopePlot->xAxis->setRange(XAxis_Range);
            }
            else{XAxis_Range.upper=XAxis_Range.lower+xMaxPoint;ScopeUi->ScopePlot->xAxis->setRange(XAxis_Range);}
        }else{}
    }


    // 更新绘图，这种方式在高填充下太浪费资源。有另一种方式rpQueuedReplot，可避免重复绘图。
    // 最好的方法还是将数据填充、和更新绘图分隔开。将更新绘图单独用定时器更新。例程数据量较少没用单独定时器更新，实际工程中建议大家加上。
    //customPlot->replot();
    customPlot->replot(QCustomPlot::rpQueuedReplot);

    //计算帧数
    static QTime time(QTime::currentTime());
    double key = time.elapsed()/1000.0; // 开始到现在的时间，单位秒
    static double lastFpsKey;
    static int frameCount;
    ++frameCount;
    if (key-lastFpsKey > 1) // 每1秒求一次平均值
    {
        //状态栏显示帧数和数据总数
      //ScopeUi->label->setText(QString("FPS: %1 CurPoints: %2").arg(frameCount/(key-lastFpsKey), 0, 'f', 0).arg(customPlot->graph(0)->data()->size()));
      ScopeUi->label->setText(QString("FPS:%1").arg(frameCount/(key-lastFpsKey), 0, 'f', 0));//只显示Fps
      lastFpsKey = key;
      frameCount = 0;

      for(gi=1;gi<=20;gi++)//遍历刷新fps
      {
          ScopeCh* scopechi=scop->findChild<ScopeCh*>("Scope_Ch"+QString::number(gi));
          if(scopechi!=NULL)//找到相应scopeCh
          {
              int fpsCnt=(gcurve[gi]->data()->size()-fpsVal[gi]);
              if(fpsCnt<0) fpsCnt=0;//fps不应该会小于0，去除隐性bug
              scopechi->setFpsVal(fpsCnt);
              fpsVal[gi]=gcurve[gi]->data()->size();//存储当前值，为下次相差做准备
          }
      }
    }
    #if 0
    if(ScopeUi->ShowPoint->isChecked()==1)//是否显示坐标线
    {
        //当前鼠标位置（像素坐标）---修改源码将坐标点重映射到当前widget
        int x_pos = customPlot->mapFromGlobal(QCursor().pos()).x();
        int y_pos = customPlot->mapFromGlobal(QCursor().pos()).y();

        //像素坐标转成实际的x,y轴的坐标
        float x_val = customPlot->xAxis->pixelToCoord(x_pos);
        float y_val = customPlot->yAxis->pixelToCoord(y_pos);

        if(Q_NULLPTR == m_xTracer)
            m_xTracer = new XxwTracer(customPlot, XxwTracer::XAxisTracer);//x轴
        m_xTracer->updatePosition(x_val, y_val);

        if(Q_NULLPTR == m_yTracer)
            m_yTracer = new XxwTracer(customPlot, XxwTracer::YAxisTracer);//y轴
        m_yTracer->updatePosition(x_val, y_val);

        int nTracerCount = m_dataTracers.count();
        int nGraphCount = customPlot->graphCount();
        if(nTracerCount < nGraphCount)
        {
            for(int i = nTracerCount; i < nGraphCount; ++i)
            {
                XxwTracer *tracer = new XxwTracer(customPlot, XxwTracer::DataTracer);
                m_dataTracers.append(tracer);
            }
        }
        else if(nTracerCount > nGraphCount)
        {
            for(int i = nGraphCount; i < nTracerCount; ++i)
            {
                XxwTracer *tracer = m_dataTracers[i];
                if(tracer)
                {
                    tracer->setVisible(false);
                }
            }
        }
        for(gi=1;gi<=20;gi++)//修改源码-改成检测ifchecked//遍历刷新
        {
            ScopeCh* scopechi=scop->findChild<ScopeCh*>("Scope_Ch"+QString::number(gi));
            if(scopechi!=NULL)//找到相应scopeCh
            {
                if(scopechi->getIfChecked()==1)
                {
                    //设置是否开启显示，本来应该单独放的，但是为了防止二次遍历，加大时间损耗，加入检测
                    gcurve[gi]->setVisible(true);gcurve[gi]->setPen(QPen(scopechi->getChCol()));

                    int i=gi-1;
                    XxwTracer *tracer = m_dataTracers[i];
                    if(!tracer)
                        tracer = new XxwTracer(customPlot, XxwTracer::DataTracer);
                    tracer->setVisible(true);
                    tracer->setPen(customPlot->graph(i)->pen());
                    tracer->setBrush(Qt::NoBrush);
                    tracer->setLabelPen(customPlot->graph(i)->pen());
                    auto iter = customPlot->graph(i)->data()->findBegin(x_val);
                    double value = iter->mainValue();
                    tracer->updatePosition(x_val, value);
                }
                else gcurve[gi]->setVisible(false);//设置是否开启显示，本来应该单独放的，但是为了防止二次遍历，加大时间损耗，加入检测
            }
        }
        if(Q_NULLPTR == m_lineTracer)
            m_lineTracer = new XxwTraceLine(customPlot,XxwTraceLine::Both);//直线
        m_lineTracer->updatePosition(x_val, y_val);
    }else
    {
        for(gi=1;gi<=20;gi++)
        {
            ScopeCh* scopechi=scop->findChild<ScopeCh*>("Scope_Ch"+QString::number(gi));
            if(scopechi!=NULL)//找到相应scopeCh
            {
                if(scopechi->getIfChecked()==1)
                {gcurve[gi]->setVisible(true);gcurve[gi]->setPen(QPen(scopechi->getChCol()));}
                else gcurve[gi]->setVisible(false);
            }
        }
    }
    #endif

#if 1
//if(ScopeUi->ShowPoint->isChecked()==1)//是否显示坐标线
//{
    //当前鼠标位置（像素坐标）---修改源码将坐标点重映射到当前widget 源代码
    int y_pos=customPlot->mapFromGlobal(QCursor().pos()).y();
    int x_pos=customPlot->mapFromGlobal(QCursor().pos()).x();
    //像素坐标转成实际的x,y轴的坐标
    float x_val = customPlot->xAxis->pixelToCoord(x_pos);
    float y_val = customPlot->yAxis->pixelToCoord(y_pos);

    QString xyvalStr;
    xyvalStr.sprintf("(%.2f,%.2f)",x_val,y_val);
    ScopeUi->XYval->setText(xyvalStr);
    if(Q_NULLPTR == m_xTracer)
        m_xTracer = new XxwTracer(customPlot, XxwTracer::XAxisTracer);//x轴
     m_xTracer->updatePosition(x_val, y_val);
    if(ScopeUi->ShowPoint->isChecked()==1) m_xTracer->setVisible(1);
    else m_xTracer->setVisible(0);


    if(Q_NULLPTR == m_yTracer)
        m_yTracer = new XxwTracer(customPlot, XxwTracer::YAxisTracer);//y轴
    m_yTracer->updatePosition(x_val, y_val);
    if(ScopeUi->ShowPoint->isChecked()==1) m_yTracer->setVisible(1);
    else m_yTracer->setVisible(0);


    int nTracerCount = m_dataTracers.count();
    int nGraphCount = customPlot->graphCount();
    if(nTracerCount < nGraphCount)
    {
        for(int i = nTracerCount; i < nGraphCount; ++i)
        {

            XxwTracer *tracer = new XxwTracer(customPlot, XxwTracer::DataTracer);
            /*if(ScopeUi->ShowPoint->isChecked()==1)*/m_dataTracers.append(tracer);
            //else m_dataTracers.clear();
        }
    }
    else if(nTracerCount > nGraphCount)
    {
        for(int i = nGraphCount; i < nTracerCount; ++i)
        {
            XxwTracer *tracer = m_dataTracers[i];
            if(tracer)
            {
                tracer->setVisible(false);
            }
            if(ScopeUi->ShowPoint->isChecked()==1)tracer->setVisible(true);
            else tracer->setVisible(false);
        }
    }
    for(gi=1;gi<=20;gi++)//修改源码-改成检测ifchecked//遍历刷新
    {
        ScopeCh* scopechi=scop->findChild<ScopeCh*>("Scope_Ch"+QString::number(gi));
        if(scopechi!=NULL)//找到相应scopeCh
        {
            int i;
            if(scopechi->getIfChecked()==1)
            {
                //设置是否开启显示，本来应该单独放的，但是为了防止二次遍历，加大时间损耗，加入检测
                gcurve[gi]->setVisible(true);gcurve[gi]->setPen(QPen(scopechi->getChCol()));

                i=gi-1;
                XxwTracer *tracer = m_dataTracers[i];
                if(!tracer)
                    tracer = new XxwTracer(customPlot, XxwTracer::DataTracer);

                tracer->setPen(customPlot->graph(i)->pen());
                tracer->setBrush(Qt::NoBrush);
                tracer->setLabelPen(customPlot->graph(i)->pen());
                auto iter = customPlot->graph(i)->data()->findBegin(x_val);
                double value = iter->mainValue();

                tracer->updatePosition(x_val, value);
                if(ScopeUi->ShowPoint->isChecked()==1) tracer->setVisible(true);
                else tracer->setVisible(false);
            }
            else
            {
                gcurve[gi]->setVisible(false);//设置是否开启显示，本来应该单独放的，但是为了防止二次遍历，加大时间损耗，加入检测

                i=gi-1;
                XxwTracer *tracer = m_dataTracers[i];
                if(!tracer)
                    tracer = new XxwTracer(customPlot, XxwTracer::DataTracer);

                tracer->setPen(customPlot->graph(i)->pen());
                tracer->setBrush(Qt::NoBrush);
                tracer->setLabelPen(customPlot->graph(i)->pen());
                auto iter = customPlot->graph(i)->data()->findBegin(x_val);
                double value = iter->mainValue();

                tracer->updatePosition(x_val, value);
                tracer->setVisible(false);
            }
        }
    }
    if(Q_NULLPTR == m_lineTracer)
        m_lineTracer = new XxwTraceLine(customPlot,XxwTraceLine::Both);//直线
    if(ScopeUi->ShowPoint->isChecked()==1) m_lineTracer->setVisible(1);
    else m_lineTracer->setVisible(0);

     m_lineTracer->updatePosition(x_val, y_val);
    #endif
}
long long int scope::ScopeTimCnt=0;


bool scope::OpenSta=0;
void scope::closeEvent(QCloseEvent *event)//关闭Scope时
{
    //在这里添加你希望执行关闭事件需要处理的事情
    //弹出消息框，关闭其他窗口
    //OpenSta=0;
    ScopeTimCnt=0;//清空计数
}

scope::~scope()
{
    delete ui;
}

void scope::Tim30HzTimOut() //填充数据
{

}
void scope::Tim1000HzTimOut()//1000hz定时器，用于Scope
{
//    if(ui->ScopeShow->isChecked()==1)//开启显示，才开始计数
//    ScopeTimCnt++;
//    if(ScopeTimCnt%100==0 && ScopeTimCnt!=0)
//            qDebug()<<ScopeTimCnt;
}

MyThread::MyThread(QObject *parent) : QThread(parent)
{
    qDebug("子线程创建");
}

void MyThread::run()
{
    qDebug() << "当前子线程ID:" << QThread::currentThreadId();
    QThread::exec();
}


void AddDataFromSerial(int ch,float i)//添加数据，第一个是通道，第二个是float数据
{

    if(ReceiveMode==0)//默认时间形式
    {
        QString times =QString::number(QDateTime::currentMSecsSinceEpoch());
        reaCnt=times.toLongLong()-last_cnt+startPoint;
        if(reaCnt>1643729643954)return;//防止scope没打开卡bug
        gcurve[ch]->addData(reaCnt,i);
        scop->findChild<ScopeCh*>("Scope_Ch"+QString::number(ch))->setLabelText(i);
    }
    else {//匿名形式
        if(scopeifopen==0) return;//防止scope没打开卡bug
        if(ScopeUi->ScopeShow->getChecked()==0) return;//没打开就不添加数据
        xxx++;
        gcurve[ch]->addData(xxx,i);
        scop->findChild<ScopeCh*>("Scope_Ch"+QString::number(ch))->setLabelText(i);
    }
}

void AddDataFromSerial(int ch,int i)//添加数据，第一个是通道，第二个是int数据
{

    if(ReceiveMode==0)//默认时间形式
    {
        QString times =QString::number(QDateTime::currentMSecsSinceEpoch());
        reaCnt=times.toLongLong()-last_cnt+startPoint;
        if(reaCnt>1643729643954)return;//防止scope没打开卡bug
        if(ScopeUi->ScopeShow->getChecked()==0) return;
        gcurve[ch]->addData(reaCnt,i);
        scop->findChild<ScopeCh*>("Scope_Ch"+QString::number(ch))->setLabelText(i);
    }
    else {//匿名形式
        if(scopeifopen==0) return;//防止scope没打开卡bug
        if(ScopeUi->ScopeShow->getChecked()==0) return;//没打开就不添加数据
        xxx++;
        gcurve[ch]->addData(xxx,i);
        scop->findChild<ScopeCh*>("Scope_Ch"+QString::number(ch))->setLabelText(i);
    }
}

QString getRandomColor(void)
{
    int r = 0;
    int g = 0;
    int b = 0;

    QString color = "";
    QString strR = "";
    QString strG = "";
    QString strB = "";

    qsrand(QTime(0,0,0).msecsTo(QTime::currentTime()));

    r = rand() % 256;
    g = rand() % 256;
    b = rand() % 256;

    bool ok = true;
    strR.setNum(r,16);
    if(strR.toInt(&ok,16)<16)
    {
        strR.prepend("0");
    }
    strG.setNum(g,16);
    if(strG.toInt(&ok,16)<16)
    {
        strG.prepend("0");
    }
    strB.setNum(b,16);
    if(strB.toInt(&ok,16)<16)
    {
        strB.prepend("0");
    }
    color.append("#"+strR+strG+strB);
    return color;
}


#if 0
void scope::mousePressEvent(QMouseEvent *event)
{
    m_lastPos = event->globalPos();
    isPressedWidget = true; // 当前鼠标按下的即是QWidget而非界面上布局的其它控件
}
void scope::mouseMoveEvent(QMouseEvent *event)
{
    if (isPressedWidget) {
        this->move(this->x() + (event->globalX() - m_lastPos.x()),
                   this->y() + (event->globalY() - m_lastPos.y()));
        m_lastPos = event->globalPos();
    }
}
void scope::mouseReleaseEvent(QMouseEvent *event)
{
    //qDebug()<<"鼠标松开";
    m_lastPos = event->globalPos();
    isPressedWidget = false; // 鼠标松开时，置为false
}
#endif
