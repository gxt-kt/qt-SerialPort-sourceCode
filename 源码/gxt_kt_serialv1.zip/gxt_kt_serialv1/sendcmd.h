#ifndef SENDCMD_H
#define SENDCMD_H

#include <QWidget>
//#include "widget.h"
#include "QSerialPort"

namespace Ui {
class SendCmd;
}

class SendCmd : public QWidget
{
    Q_OBJECT

public:
    explicit SendCmd(QWidget *parent = nullptr);
    ~SendCmd();

private:
    Ui::SendCmd *ui;
};

#endif // SENDCMD_H
