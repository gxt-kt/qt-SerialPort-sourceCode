﻿#ifndef SERIALGETBYTE_H
#define SERIALGETBYTE_H

#include <QObject>
#include <QWidget>
#include "QDebug"
#include "datastorage.h"

#include "navbuttongroup.h"
#include "gaugecompass.h"
#include "gaugeplane.h"

#define startByte 0xAA
#define EulerPoint 0x03
#define Quaternion 0x04
#define RemoteControl  0x40
#define VoltageCurrent 0x0D //电压电流
#define ColorString 0xC0 //字符串

class FlyBaseInfo;
class Degree;
class ScopeData;
extern ScopeData scoData;
extern FlyBaseInfo gxtfly;
extern int ChFps[0xff+1];

class Gyroscope//欧拉角
{
public:
    float Roll,Pitch,Yaw;//发送的欧拉角
    float q0,q1,q2,q3;//发送的四元数
    float RollFromQua,PitchFromQua,YawFromQua;//由q0~3计算出来的欧拉角
};
class REmoteControl//遥控器数据
{
public:
    int16_t ch[13];
};

class VOltageCUrrent//遥控器数据
{
public:
    float voltage;
    float current;
};

class FlyBaseInfo
{
public:
    Gyroscope degData1;//第一套imu
    Gyroscope degData2;//第二套imu
    REmoteControl RC;
    VOltageCUrrent volAndCur;
};

class ScopeData
{
public:
    int scoIntData[21];//设置21个，第0个不用
    float scofloData[21];//设置21个，第0个不用
};

int SerialGetOneByte(uchar byte);
void SerialFunction(uchar *buf,uchar len);


typedef enum
{
    gxtBLACK = 0U,
    gxtWHITE,
    gxtRED,
    gxtGREEN,
    gxtBLUE,
    gxtORANGE,
    gxtYELLOW,
    gxtCYAN,
    gxtMagenta,
} gxtCOLOR;

#endif // SERIALGETBYTE_H
