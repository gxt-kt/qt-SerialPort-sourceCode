#ifndef SLIDER_H
#define SLIDER_H

#include <QWidget>
#include "xslider.h"
#include <QDoubleValidator>
namespace Ui {
class Slider;
}

void gxtSendSliderPid(int sendCh,float gxt_a);
void gxtSendSliderPid(int sendCh,float gxt_a,float gxt_b,float gxt_c,float gxt_d,float gxt_e);
class Slider : public QWidget
{
    Q_OBJECT

public:
    explicit Slider(QWidget *parent = nullptr);
    ~Slider();
    int bug_resolve1=0;
    int lastVal;
    void flush(void);
    float GetVal(void);
    Ui::Slider *ui;
private:

};



#endif // SLIDER_H
