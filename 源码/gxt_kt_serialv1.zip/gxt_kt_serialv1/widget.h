﻿#ifndef WIDGET_H
#define WIDGET_H

#include "QObject"
#include <QWidget>
#include "QSerialPort"
#include "scope.h"
#include <scopech.h>
#include "basicinfo.h"
#include "./systemfun.h"
#include <QThread>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE
class Widget;

extern Widget *my_this;
extern QSerialPort *Serialport;



class MySlotObject;
class Widget : public QWidget
{
    Q_OBJECT
public:
    scope *ScopePtr;

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

    QTimer *tim;
    void SerialPort_Init(int * sta);
    void SerialPort_Close(void);
    void Widget::waitMs(int msec);

    MySlotObject*   slotObj;
    void refreshDPI();
    void changeObjectSize(const QObject &o, double objectRate);
signals:
    void sendsign(void);
public Q_SLOTS:
    void SlotTest();

    void Widget::handleSerialError(QSerialPort::SerialPortError error);
//private slots:
//    void on_SerialNum_activated(int index);

private:
    Ui::Widget *ui;

#if 0
protected:
    //截取鼠标事件绘制窗口位置. 因为标题栏隐藏后.窗口是无法拖动的。
    void mouseReleaseEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
private:
    //.........
    bool isPressedWidget;
    QPoint m_lastPos;
#endif
};



class MySlotObject : public QObject
{
    Q_OBJECT
public:
    MySlotObject(QObject* parent = 0);
    ~MySlotObject();

public slots:
void slotOperat();
};
#endif // WIDGET_H
