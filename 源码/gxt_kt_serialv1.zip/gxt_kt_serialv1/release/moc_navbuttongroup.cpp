/****************************************************************************
** Meta object code from reading C++ file 'navbuttongroup.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../sdk/HeadFile/navbuttongroup.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'navbuttongroup.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_NavButtonGroup_t {
    QByteArrayData data[46];
    char stringdata0[570];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_NavButtonGroup_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_NavButtonGroup_t qt_meta_stringdata_NavButtonGroup = {
    {
QT_MOC_LITERAL(0, 0, 14), // "NavButtonGroup"
QT_MOC_LITERAL(1, 15, 13), // "buttonClicked"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 5), // "index"
QT_MOC_LITERAL(4, 36, 16), // "QAbstractButton*"
QT_MOC_LITERAL(5, 53, 3), // "btn"
QT_MOC_LITERAL(6, 57, 15), // "onButtonClicked"
QT_MOC_LITERAL(7, 73, 14), // "onValueChanged"
QT_MOC_LITERAL(8, 88, 5), // "value"
QT_MOC_LITERAL(9, 94, 11), // "setInterval"
QT_MOC_LITERAL(10, 106, 8), // "interval"
QT_MOC_LITERAL(11, 115, 10), // "setLineLen"
QT_MOC_LITERAL(12, 126, 7), // "lineLen"
QT_MOC_LITERAL(13, 134, 8), // "setIndex"
QT_MOC_LITERAL(14, 143, 8), // "setTexts"
QT_MOC_LITERAL(15, 152, 5), // "texts"
QT_MOC_LITERAL(16, 158, 15), // "setLinePosition"
QT_MOC_LITERAL(17, 174, 12), // "LinePosition"
QT_MOC_LITERAL(18, 187, 12), // "linePosition"
QT_MOC_LITERAL(19, 200, 12), // "setLineColor"
QT_MOC_LITERAL(20, 213, 9), // "lineColor"
QT_MOC_LITERAL(21, 223, 17), // "setBtnNormalColor"
QT_MOC_LITERAL(22, 241, 14), // "btnNormalColor"
QT_MOC_LITERAL(23, 256, 16), // "setBtnHoverColor"
QT_MOC_LITERAL(24, 273, 13), // "btnHoverColor"
QT_MOC_LITERAL(25, 287, 15), // "setBtnDarkColor"
QT_MOC_LITERAL(26, 303, 12), // "btnDarkColor"
QT_MOC_LITERAL(27, 316, 18), // "setTextNormalColor"
QT_MOC_LITERAL(28, 335, 15), // "textNormalColor"
QT_MOC_LITERAL(29, 351, 17), // "setTextHoverColor"
QT_MOC_LITERAL(30, 369, 14), // "textHoverColor"
QT_MOC_LITERAL(31, 384, 16), // "setTextDarkColor"
QT_MOC_LITERAL(32, 401, 13), // "textDarkColor"
QT_MOC_LITERAL(33, 415, 12), // "setBaseColor"
QT_MOC_LITERAL(34, 428, 9), // "baseColor"
QT_MOC_LITERAL(35, 438, 6), // "normal"
QT_MOC_LITERAL(36, 445, 4), // "init"
QT_MOC_LITERAL(37, 450, 9), // "addButton"
QT_MOC_LITERAL(38, 460, 2), // "id"
QT_MOC_LITERAL(39, 463, 11), // "clearButton"
QT_MOC_LITERAL(40, 475, 8), // "addFinsh"
QT_MOC_LITERAL(41, 484, 11), // "setBtnStyle"
QT_MOC_LITERAL(42, 496, 17), // "LinePosition_Left"
QT_MOC_LITERAL(43, 514, 18), // "LinePosition_Right"
QT_MOC_LITERAL(44, 533, 16), // "LinePosition_Top"
QT_MOC_LITERAL(45, 550, 19) // "LinePosition_Bottom"

    },
    "NavButtonGroup\0buttonClicked\0\0index\0"
    "QAbstractButton*\0btn\0onButtonClicked\0"
    "onValueChanged\0value\0setInterval\0"
    "interval\0setLineLen\0lineLen\0setIndex\0"
    "setTexts\0texts\0setLinePosition\0"
    "LinePosition\0linePosition\0setLineColor\0"
    "lineColor\0setBtnNormalColor\0btnNormalColor\0"
    "setBtnHoverColor\0btnHoverColor\0"
    "setBtnDarkColor\0btnDarkColor\0"
    "setTextNormalColor\0textNormalColor\0"
    "setTextHoverColor\0textHoverColor\0"
    "setTextDarkColor\0textDarkColor\0"
    "setBaseColor\0baseColor\0normal\0init\0"
    "addButton\0id\0clearButton\0addFinsh\0"
    "setBtnStyle\0LinePosition_Left\0"
    "LinePosition_Right\0LinePosition_Top\0"
    "LinePosition_Bottom"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_NavButtonGroup[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
      13,  194, // properties
       1,  233, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  129,    2, 0x06 /* Public */,
       1,    1,  132,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,  135,    2, 0x08 /* Private */,
       7,    1,  138,    2, 0x08 /* Private */,
       9,    1,  141,    2, 0x0a /* Public */,
      11,    1,  144,    2, 0x0a /* Public */,
      13,    1,  147,    2, 0x0a /* Public */,
      14,    1,  150,    2, 0x0a /* Public */,
      16,    1,  153,    2, 0x0a /* Public */,
      19,    1,  156,    2, 0x0a /* Public */,
      21,    1,  159,    2, 0x0a /* Public */,
      23,    1,  162,    2, 0x0a /* Public */,
      25,    1,  165,    2, 0x0a /* Public */,
      27,    1,  168,    2, 0x0a /* Public */,
      29,    1,  171,    2, 0x0a /* Public */,
      31,    1,  174,    2, 0x0a /* Public */,
      33,    2,  177,    2, 0x0a /* Public */,
      33,    1,  182,    2, 0x2a /* Public | MethodCloned */,
      36,    0,  185,    2, 0x0a /* Public */,
      37,    2,  186,    2, 0x0a /* Public */,
      39,    0,  191,    2, 0x0a /* Public */,
      40,    0,  192,    2, 0x0a /* Public */,
      41,    0,  193,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, 0x80000000 | 4,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::QVariant,    8,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void, QMetaType::QColor,   20,
    QMetaType::Void, QMetaType::QColor,   22,
    QMetaType::Void, QMetaType::QColor,   24,
    QMetaType::Void, QMetaType::QColor,   26,
    QMetaType::Void, QMetaType::QColor,   28,
    QMetaType::Void, QMetaType::QColor,   30,
    QMetaType::Void, QMetaType::QColor,   32,
    QMetaType::Void, QMetaType::QColor, QMetaType::Bool,   34,   35,
    QMetaType::Void, QMetaType::QColor,   34,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4, QMetaType::Int,    5,   38,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
      10, QMetaType::Int, 0x00095103,
      12, QMetaType::Int, 0x00095103,
       3, QMetaType::Int, 0x00095103,
      15, QMetaType::QString, 0x00095103,
      18, 0x80000000 | 17, 0x0009510b,
      20, QMetaType::QColor, 0x00095103,
      22, QMetaType::QColor, 0x00095103,
      24, QMetaType::QColor, 0x00095103,
      26, QMetaType::QColor, 0x00095103,
      28, QMetaType::QColor, 0x00095103,
      30, QMetaType::QColor, 0x00095103,
      32, QMetaType::QColor, 0x00095103,
      34, QMetaType::QColor, 0x00095103,

 // enums: name, flags, count, data
      17, 0x0,    4,  237,

 // enum data: key, value
      42, uint(NavButtonGroup::LinePosition_Left),
      43, uint(NavButtonGroup::LinePosition_Right),
      44, uint(NavButtonGroup::LinePosition_Top),
      45, uint(NavButtonGroup::LinePosition_Bottom),

       0        // eod
};

void NavButtonGroup::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        NavButtonGroup *_t = static_cast<NavButtonGroup *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->buttonClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->buttonClicked((*reinterpret_cast< QAbstractButton*(*)>(_a[1]))); break;
        case 2: _t->onButtonClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->onValueChanged((*reinterpret_cast< const QVariant(*)>(_a[1]))); break;
        case 4: _t->setInterval((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->setLineLen((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->setIndex((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->setTexts((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->setLinePosition((*reinterpret_cast< const LinePosition(*)>(_a[1]))); break;
        case 9: _t->setLineColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 10: _t->setBtnNormalColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 11: _t->setBtnHoverColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 12: _t->setBtnDarkColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 13: _t->setTextNormalColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 14: _t->setTextHoverColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 15: _t->setTextDarkColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 16: _t->setBaseColor((*reinterpret_cast< const QColor(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 17: _t->setBaseColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 18: _t->init(); break;
        case 19: _t->addButton((*reinterpret_cast< QAbstractButton*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 20: _t->clearButton(); break;
        case 21: _t->addFinsh(); break;
        case 22: _t->setBtnStyle(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (NavButtonGroup::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NavButtonGroup::buttonClicked)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (NavButtonGroup::*_t)(QAbstractButton * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NavButtonGroup::buttonClicked)) {
                *result = 1;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        NavButtonGroup *_t = static_cast<NavButtonGroup *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->getInterval(); break;
        case 1: *reinterpret_cast< int*>(_v) = _t->getLineLen(); break;
        case 2: *reinterpret_cast< int*>(_v) = _t->getIndex(); break;
        case 3: *reinterpret_cast< QString*>(_v) = _t->getTexts(); break;
        case 4: *reinterpret_cast< LinePosition*>(_v) = _t->getLinePosition(); break;
        case 5: *reinterpret_cast< QColor*>(_v) = _t->getLineColor(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->getBtnNormalColor(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->getBtnHoverColor(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->getBtnDarkColor(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->getTextNormalColor(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->getTextHoverColor(); break;
        case 11: *reinterpret_cast< QColor*>(_v) = _t->getTextDarkColor(); break;
        case 12: *reinterpret_cast< QColor*>(_v) = _t->getBaseColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        NavButtonGroup *_t = static_cast<NavButtonGroup *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setInterval(*reinterpret_cast< int*>(_v)); break;
        case 1: _t->setLineLen(*reinterpret_cast< int*>(_v)); break;
        case 2: _t->setIndex(*reinterpret_cast< int*>(_v)); break;
        case 3: _t->setTexts(*reinterpret_cast< QString*>(_v)); break;
        case 4: _t->setLinePosition(*reinterpret_cast< LinePosition*>(_v)); break;
        case 5: _t->setLineColor(*reinterpret_cast< QColor*>(_v)); break;
        case 6: _t->setBtnNormalColor(*reinterpret_cast< QColor*>(_v)); break;
        case 7: _t->setBtnHoverColor(*reinterpret_cast< QColor*>(_v)); break;
        case 8: _t->setBtnDarkColor(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setTextNormalColor(*reinterpret_cast< QColor*>(_v)); break;
        case 10: _t->setTextHoverColor(*reinterpret_cast< QColor*>(_v)); break;
        case 11: _t->setTextDarkColor(*reinterpret_cast< QColor*>(_v)); break;
        case 12: _t->setBaseColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject NavButtonGroup::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_NavButtonGroup.data,
      qt_meta_data_NavButtonGroup,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *NavButtonGroup::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *NavButtonGroup::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_NavButtonGroup.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int NavButtonGroup::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 13;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void NavButtonGroup::buttonClicked(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void NavButtonGroup::buttonClicked(QAbstractButton * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
