/****************************************************************************
** Meta object code from reading C++ file 'slidertip.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../sdk/HeadFile/slidertip.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'slidertip.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SliderTip_t {
    QByteArrayData data[30];
    char stringdata0[365];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SliderTip_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SliderTip_t qt_meta_stringdata_SliderTip = {
    {
QT_MOC_LITERAL(0, 0, 9), // "SliderTip"
QT_MOC_LITERAL(1, 10, 7), // "clicked"
QT_MOC_LITERAL(2, 18, 0), // ""
QT_MOC_LITERAL(3, 19, 15), // "setBorderRadius"
QT_MOC_LITERAL(4, 35, 12), // "borderRadius"
QT_MOC_LITERAL(5, 48, 12), // "setArrowSize"
QT_MOC_LITERAL(6, 61, 9), // "arrowSize"
QT_MOC_LITERAL(7, 71, 13), // "setArrowStyle"
QT_MOC_LITERAL(8, 85, 10), // "ArrowStyle"
QT_MOC_LITERAL(9, 96, 10), // "arrowStyle"
QT_MOC_LITERAL(10, 107, 13), // "setBackground"
QT_MOC_LITERAL(11, 121, 10), // "background"
QT_MOC_LITERAL(12, 132, 13), // "setForeground"
QT_MOC_LITERAL(13, 146, 10), // "foreground"
QT_MOC_LITERAL(14, 157, 14), // "setLabTipWidth"
QT_MOC_LITERAL(15, 172, 11), // "labTipWidth"
QT_MOC_LITERAL(16, 184, 15), // "setLabTipHeight"
QT_MOC_LITERAL(17, 200, 12), // "labTipHeight"
QT_MOC_LITERAL(18, 213, 13), // "setLabTipFont"
QT_MOC_LITERAL(19, 227, 10), // "labTipFont"
QT_MOC_LITERAL(20, 238, 11), // "setShowTime"
QT_MOC_LITERAL(21, 250, 8), // "showTime"
QT_MOC_LITERAL(22, 259, 14), // "setClickEnable"
QT_MOC_LITERAL(23, 274, 11), // "clickEnable"
QT_MOC_LITERAL(24, 286, 7), // "setUnit"
QT_MOC_LITERAL(25, 294, 4), // "unit"
QT_MOC_LITERAL(26, 299, 15), // "ArrowStyle_Left"
QT_MOC_LITERAL(27, 315, 16), // "ArrowStyle_Right"
QT_MOC_LITERAL(28, 332, 14), // "ArrowStyle_Top"
QT_MOC_LITERAL(29, 347, 17) // "ArrowStyle_Bottom"

    },
    "SliderTip\0clicked\0\0setBorderRadius\0"
    "borderRadius\0setArrowSize\0arrowSize\0"
    "setArrowStyle\0ArrowStyle\0arrowStyle\0"
    "setBackground\0background\0setForeground\0"
    "foreground\0setLabTipWidth\0labTipWidth\0"
    "setLabTipHeight\0labTipHeight\0setLabTipFont\0"
    "labTipFont\0setShowTime\0showTime\0"
    "setClickEnable\0clickEnable\0setUnit\0"
    "unit\0ArrowStyle_Left\0ArrowStyle_Right\0"
    "ArrowStyle_Top\0ArrowStyle_Bottom"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SliderTip[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
      11,  108, // properties
       1,  141, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    1,   75,    2, 0x0a /* Public */,
       5,    1,   78,    2, 0x0a /* Public */,
       7,    1,   81,    2, 0x0a /* Public */,
      10,    1,   84,    2, 0x0a /* Public */,
      12,    1,   87,    2, 0x0a /* Public */,
      14,    1,   90,    2, 0x0a /* Public */,
      16,    1,   93,    2, 0x0a /* Public */,
      18,    1,   96,    2, 0x0a /* Public */,
      20,    1,   99,    2, 0x0a /* Public */,
      22,    1,  102,    2, 0x0a /* Public */,
      24,    1,  105,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void, QMetaType::QColor,   11,
    QMetaType::Void, QMetaType::QColor,   13,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::QFont,   19,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void, QMetaType::Bool,   23,
    QMetaType::Void, QMetaType::QString,   25,

 // properties: name, type, flags
       4, QMetaType::Int, 0x00095103,
       6, QMetaType::Int, 0x00095103,
       9, 0x80000000 | 8, 0x0009510b,
      11, QMetaType::QColor, 0x00095103,
      13, QMetaType::QColor, 0x00095103,
      15, QMetaType::Int, 0x00095103,
      17, QMetaType::Int, 0x00095103,
      19, QMetaType::QFont, 0x00095103,
      21, QMetaType::Bool, 0x00095103,
      23, QMetaType::Bool, 0x00095103,
      25, QMetaType::QString, 0x00095103,

 // enums: name, flags, count, data
       8, 0x0,    4,  145,

 // enum data: key, value
      26, uint(SliderTip::ArrowStyle_Left),
      27, uint(SliderTip::ArrowStyle_Right),
      28, uint(SliderTip::ArrowStyle_Top),
      29, uint(SliderTip::ArrowStyle_Bottom),

       0        // eod
};

void SliderTip::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SliderTip *_t = static_cast<SliderTip *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->clicked(); break;
        case 1: _t->setBorderRadius((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->setArrowSize((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->setArrowStyle((*reinterpret_cast< const ArrowStyle(*)>(_a[1]))); break;
        case 4: _t->setBackground((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 5: _t->setForeground((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 6: _t->setLabTipWidth((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->setLabTipHeight((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->setLabTipFont((*reinterpret_cast< const QFont(*)>(_a[1]))); break;
        case 9: _t->setShowTime((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->setClickEnable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->setUnit((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (SliderTip::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SliderTip::clicked)) {
                *result = 0;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        SliderTip *_t = static_cast<SliderTip *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->getBorderRadius(); break;
        case 1: *reinterpret_cast< int*>(_v) = _t->getArrowSize(); break;
        case 2: *reinterpret_cast< ArrowStyle*>(_v) = _t->getArrowStyle(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = _t->getBackground(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->getForeground(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->getLabTipWidth(); break;
        case 6: *reinterpret_cast< int*>(_v) = _t->getLabTipHeight(); break;
        case 7: *reinterpret_cast< QFont*>(_v) = _t->getLabTipFont(); break;
        case 8: *reinterpret_cast< bool*>(_v) = _t->getShowTime(); break;
        case 9: *reinterpret_cast< bool*>(_v) = _t->getClickEnable(); break;
        case 10: *reinterpret_cast< QString*>(_v) = _t->getUnit(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        SliderTip *_t = static_cast<SliderTip *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setBorderRadius(*reinterpret_cast< int*>(_v)); break;
        case 1: _t->setArrowSize(*reinterpret_cast< int*>(_v)); break;
        case 2: _t->setArrowStyle(*reinterpret_cast< ArrowStyle*>(_v)); break;
        case 3: _t->setBackground(*reinterpret_cast< QColor*>(_v)); break;
        case 4: _t->setForeground(*reinterpret_cast< QColor*>(_v)); break;
        case 5: _t->setLabTipWidth(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setLabTipHeight(*reinterpret_cast< int*>(_v)); break;
        case 7: _t->setLabTipFont(*reinterpret_cast< QFont*>(_v)); break;
        case 8: _t->setShowTime(*reinterpret_cast< bool*>(_v)); break;
        case 9: _t->setClickEnable(*reinterpret_cast< bool*>(_v)); break;
        case 10: _t->setUnit(*reinterpret_cast< QString*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject SliderTip::staticMetaObject = {
    { &QSlider::staticMetaObject, qt_meta_stringdata_SliderTip.data,
      qt_meta_data_SliderTip,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *SliderTip::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SliderTip::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SliderTip.stringdata0))
        return static_cast<void*>(this);
    return QSlider::qt_metacast(_clname);
}

int SliderTip::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QSlider::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 11;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 11;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 11;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 11;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 11;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void SliderTip::clicked()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
