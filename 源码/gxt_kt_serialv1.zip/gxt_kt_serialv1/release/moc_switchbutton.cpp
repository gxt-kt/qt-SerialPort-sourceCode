/****************************************************************************
** Meta object code from reading C++ file 'switchbutton.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../switchbutton.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'switchbutton.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SwitchButton_t {
    QByteArrayData data[39];
    char stringdata0[479];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SwitchButton_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SwitchButton_t qt_meta_stringdata_SwitchButton = {
    {
QT_MOC_LITERAL(0, 0, 12), // "SwitchButton"
QT_MOC_LITERAL(1, 13, 14), // "checkedChanged"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 7), // "checked"
QT_MOC_LITERAL(4, 37, 6), // "change"
QT_MOC_LITERAL(5, 44, 11), // "updateValue"
QT_MOC_LITERAL(6, 56, 8), // "setSpace"
QT_MOC_LITERAL(7, 65, 5), // "space"
QT_MOC_LITERAL(8, 71, 13), // "setRectRadius"
QT_MOC_LITERAL(9, 85, 10), // "rectRadius"
QT_MOC_LITERAL(10, 96, 10), // "setChecked"
QT_MOC_LITERAL(11, 107, 11), // "setShowText"
QT_MOC_LITERAL(12, 119, 8), // "showText"
QT_MOC_LITERAL(13, 128, 13), // "setShowCircle"
QT_MOC_LITERAL(14, 142, 10), // "showCircle"
QT_MOC_LITERAL(15, 153, 12), // "setAnimation"
QT_MOC_LITERAL(16, 166, 9), // "animation"
QT_MOC_LITERAL(17, 176, 14), // "setButtonStyle"
QT_MOC_LITERAL(18, 191, 11), // "ButtonStyle"
QT_MOC_LITERAL(19, 203, 11), // "buttonStyle"
QT_MOC_LITERAL(20, 215, 13), // "setBgColorOff"
QT_MOC_LITERAL(21, 229, 10), // "bgColorOff"
QT_MOC_LITERAL(22, 240, 12), // "setBgColorOn"
QT_MOC_LITERAL(23, 253, 9), // "bgColorOn"
QT_MOC_LITERAL(24, 263, 17), // "setSliderColorOff"
QT_MOC_LITERAL(25, 281, 14), // "sliderColorOff"
QT_MOC_LITERAL(26, 296, 16), // "setSliderColorOn"
QT_MOC_LITERAL(27, 313, 13), // "sliderColorOn"
QT_MOC_LITERAL(28, 327, 15), // "setTextColorOff"
QT_MOC_LITERAL(29, 343, 12), // "textColorOff"
QT_MOC_LITERAL(30, 356, 14), // "setTextColorOn"
QT_MOC_LITERAL(31, 371, 11), // "textColorOn"
QT_MOC_LITERAL(32, 383, 10), // "setTextOff"
QT_MOC_LITERAL(33, 394, 7), // "textOff"
QT_MOC_LITERAL(34, 402, 9), // "setTextOn"
QT_MOC_LITERAL(35, 412, 6), // "textOn"
QT_MOC_LITERAL(36, 419, 16), // "ButtonStyle_Rect"
QT_MOC_LITERAL(37, 436, 20), // "ButtonStyle_CircleIn"
QT_MOC_LITERAL(38, 457, 21) // "ButtonStyle_CircleOut"

    },
    "SwitchButton\0checkedChanged\0\0checked\0"
    "change\0updateValue\0setSpace\0space\0"
    "setRectRadius\0rectRadius\0setChecked\0"
    "setShowText\0showText\0setShowCircle\0"
    "showCircle\0setAnimation\0animation\0"
    "setButtonStyle\0ButtonStyle\0buttonStyle\0"
    "setBgColorOff\0bgColorOff\0setBgColorOn\0"
    "bgColorOn\0setSliderColorOff\0sliderColorOff\0"
    "setSliderColorOn\0sliderColorOn\0"
    "setTextColorOff\0textColorOff\0"
    "setTextColorOn\0textColorOn\0setTextOff\0"
    "textOff\0setTextOn\0textOn\0ButtonStyle_Rect\0"
    "ButtonStyle_CircleIn\0ButtonStyle_CircleOut"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SwitchButton[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
      15,  154, // properties
       1,  199, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  104,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,  107,    2, 0x08 /* Private */,
       5,    0,  108,    2, 0x08 /* Private */,
       6,    1,  109,    2, 0x0a /* Public */,
       8,    1,  112,    2, 0x0a /* Public */,
      10,    1,  115,    2, 0x0a /* Public */,
      11,    1,  118,    2, 0x0a /* Public */,
      13,    1,  121,    2, 0x0a /* Public */,
      15,    1,  124,    2, 0x0a /* Public */,
      17,    1,  127,    2, 0x0a /* Public */,
      20,    1,  130,    2, 0x0a /* Public */,
      22,    1,  133,    2, 0x0a /* Public */,
      24,    1,  136,    2, 0x0a /* Public */,
      26,    1,  139,    2, 0x0a /* Public */,
      28,    1,  142,    2, 0x0a /* Public */,
      30,    1,  145,    2, 0x0a /* Public */,
      32,    1,  148,    2, 0x0a /* Public */,
      34,    1,  151,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,   12,
    QMetaType::Void, QMetaType::Bool,   14,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, 0x80000000 | 18,   19,
    QMetaType::Void, QMetaType::QColor,   21,
    QMetaType::Void, QMetaType::QColor,   23,
    QMetaType::Void, QMetaType::QColor,   25,
    QMetaType::Void, QMetaType::QColor,   27,
    QMetaType::Void, QMetaType::QColor,   29,
    QMetaType::Void, QMetaType::QColor,   31,
    QMetaType::Void, QMetaType::QString,   33,
    QMetaType::Void, QMetaType::QString,   35,

 // properties: name, type, flags
       7, QMetaType::Int, 0x00095103,
       9, QMetaType::Int, 0x00095103,
       3, QMetaType::Bool, 0x00095103,
      12, QMetaType::Bool, 0x00095103,
      14, QMetaType::Bool, 0x00095103,
      16, QMetaType::Bool, 0x00095103,
      19, 0x80000000 | 18, 0x0009510b,
      21, QMetaType::QColor, 0x00095103,
      23, QMetaType::QColor, 0x00095103,
      25, QMetaType::QColor, 0x00095103,
      27, QMetaType::QColor, 0x00095103,
      29, QMetaType::QColor, 0x00095103,
      31, QMetaType::QColor, 0x00095103,
      33, QMetaType::QString, 0x00095103,
      35, QMetaType::QString, 0x00095103,

 // enums: name, flags, count, data
      18, 0x0,    3,  203,

 // enum data: key, value
      36, uint(SwitchButton::ButtonStyle_Rect),
      37, uint(SwitchButton::ButtonStyle_CircleIn),
      38, uint(SwitchButton::ButtonStyle_CircleOut),

       0        // eod
};

void SwitchButton::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SwitchButton *_t = static_cast<SwitchButton *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->checkedChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->change(); break;
        case 2: _t->updateValue(); break;
        case 3: _t->setSpace((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->setRectRadius((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->setChecked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->setShowText((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->setShowCircle((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->setAnimation((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->setButtonStyle((*reinterpret_cast< const ButtonStyle(*)>(_a[1]))); break;
        case 10: _t->setBgColorOff((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 11: _t->setBgColorOn((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 12: _t->setSliderColorOff((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 13: _t->setSliderColorOn((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 14: _t->setTextColorOff((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 15: _t->setTextColorOn((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 16: _t->setTextOff((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 17: _t->setTextOn((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (SwitchButton::*_t)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SwitchButton::checkedChanged)) {
                *result = 0;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        SwitchButton *_t = static_cast<SwitchButton *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->getSpace(); break;
        case 1: *reinterpret_cast< int*>(_v) = _t->getRectRadius(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->getChecked(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->getShowText(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->getShowCircle(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->getAnimation(); break;
        case 6: *reinterpret_cast< ButtonStyle*>(_v) = _t->getButtonStyle(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->getBgColorOff(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->getBgColorOn(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->getSliderColorOff(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->getSliderColorOn(); break;
        case 11: *reinterpret_cast< QColor*>(_v) = _t->getTextColorOff(); break;
        case 12: *reinterpret_cast< QColor*>(_v) = _t->getTextColorOn(); break;
        case 13: *reinterpret_cast< QString*>(_v) = _t->getTextOff(); break;
        case 14: *reinterpret_cast< QString*>(_v) = _t->getTextOn(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        SwitchButton *_t = static_cast<SwitchButton *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setSpace(*reinterpret_cast< int*>(_v)); break;
        case 1: _t->setRectRadius(*reinterpret_cast< int*>(_v)); break;
        case 2: _t->setChecked(*reinterpret_cast< bool*>(_v)); break;
        case 3: _t->setShowText(*reinterpret_cast< bool*>(_v)); break;
        case 4: _t->setShowCircle(*reinterpret_cast< bool*>(_v)); break;
        case 5: _t->setAnimation(*reinterpret_cast< bool*>(_v)); break;
        case 6: _t->setButtonStyle(*reinterpret_cast< ButtonStyle*>(_v)); break;
        case 7: _t->setBgColorOff(*reinterpret_cast< QColor*>(_v)); break;
        case 8: _t->setBgColorOn(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setSliderColorOff(*reinterpret_cast< QColor*>(_v)); break;
        case 10: _t->setSliderColorOn(*reinterpret_cast< QColor*>(_v)); break;
        case 11: _t->setTextColorOff(*reinterpret_cast< QColor*>(_v)); break;
        case 12: _t->setTextColorOn(*reinterpret_cast< QColor*>(_v)); break;
        case 13: _t->setTextOff(*reinterpret_cast< QString*>(_v)); break;
        case 14: _t->setTextOn(*reinterpret_cast< QString*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject SwitchButton::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_SwitchButton.data,
      qt_meta_data_SwitchButton,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *SwitchButton::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SwitchButton::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SwitchButton.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int SwitchButton::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 15;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 15;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 15;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 15;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 15;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void SwitchButton::checkedChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
