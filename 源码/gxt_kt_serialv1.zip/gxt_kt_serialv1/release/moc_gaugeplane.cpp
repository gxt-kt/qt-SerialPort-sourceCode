/****************************************************************************
** Meta object code from reading C++ file 'gaugeplane.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../gaugeplane.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'gaugeplane.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GaugePlane_t {
    QByteArrayData data[32];
    char stringdata0[435];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GaugePlane_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GaugePlane_t qt_meta_stringdata_GaugePlane = {
    {
QT_MOC_LITERAL(0, 0, 10), // "GaugePlane"
QT_MOC_LITERAL(1, 11, 10), // "degChanged"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 8), // "degValue"
QT_MOC_LITERAL(4, 32, 11), // "rollChanged"
QT_MOC_LITERAL(5, 44, 9), // "rollValue"
QT_MOC_LITERAL(6, 54, 22), // "setBorderOutColorStart"
QT_MOC_LITERAL(7, 77, 19), // "borderOutColorStart"
QT_MOC_LITERAL(8, 97, 20), // "setBorderOutColorEnd"
QT_MOC_LITERAL(9, 118, 17), // "borderOutColorEnd"
QT_MOC_LITERAL(10, 136, 21), // "setBorderInColorStart"
QT_MOC_LITERAL(11, 158, 18), // "borderInColorStart"
QT_MOC_LITERAL(12, 177, 19), // "setBorderInColorEnd"
QT_MOC_LITERAL(13, 197, 16), // "borderInColorEnd"
QT_MOC_LITERAL(14, 214, 10), // "setBgColor"
QT_MOC_LITERAL(15, 225, 7), // "bgColor"
QT_MOC_LITERAL(16, 233, 13), // "setPlaneColor"
QT_MOC_LITERAL(17, 247, 10), // "planeColor"
QT_MOC_LITERAL(18, 258, 13), // "setGlassColor"
QT_MOC_LITERAL(19, 272, 10), // "glassColor"
QT_MOC_LITERAL(20, 283, 13), // "setScaleColor"
QT_MOC_LITERAL(21, 297, 10), // "scaleColor"
QT_MOC_LITERAL(22, 308, 12), // "setLineColor"
QT_MOC_LITERAL(23, 321, 9), // "lineColor"
QT_MOC_LITERAL(24, 331, 12), // "setTextColor"
QT_MOC_LITERAL(25, 344, 9), // "textColor"
QT_MOC_LITERAL(26, 354, 15), // "setPointerColor"
QT_MOC_LITERAL(27, 370, 12), // "pointerColor"
QT_MOC_LITERAL(28, 383, 14), // "setHandleColor"
QT_MOC_LITERAL(29, 398, 11), // "handleColor"
QT_MOC_LITERAL(30, 410, 11), // "setDegValue"
QT_MOC_LITERAL(31, 422, 12) // "setRollValue"

    },
    "GaugePlane\0degChanged\0\0degValue\0"
    "rollChanged\0rollValue\0setBorderOutColorStart\0"
    "borderOutColorStart\0setBorderOutColorEnd\0"
    "borderOutColorEnd\0setBorderInColorStart\0"
    "borderInColorStart\0setBorderInColorEnd\0"
    "borderInColorEnd\0setBgColor\0bgColor\0"
    "setPlaneColor\0planeColor\0setGlassColor\0"
    "glassColor\0setScaleColor\0scaleColor\0"
    "setLineColor\0lineColor\0setTextColor\0"
    "textColor\0setPointerColor\0pointerColor\0"
    "setHandleColor\0handleColor\0setDegValue\0"
    "setRollValue"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GaugePlane[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
      14,  142, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   94,    2, 0x06 /* Public */,
       4,    1,   97,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,  100,    2, 0x0a /* Public */,
       8,    1,  103,    2, 0x0a /* Public */,
      10,    1,  106,    2, 0x0a /* Public */,
      12,    1,  109,    2, 0x0a /* Public */,
      14,    1,  112,    2, 0x0a /* Public */,
      16,    1,  115,    2, 0x0a /* Public */,
      18,    1,  118,    2, 0x0a /* Public */,
      20,    1,  121,    2, 0x0a /* Public */,
      22,    1,  124,    2, 0x0a /* Public */,
      24,    1,  127,    2, 0x0a /* Public */,
      26,    1,  130,    2, 0x0a /* Public */,
      28,    1,  133,    2, 0x0a /* Public */,
      30,    1,  136,    2, 0x0a /* Public */,
      31,    1,  139,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::QColor,    7,
    QMetaType::Void, QMetaType::QColor,    9,
    QMetaType::Void, QMetaType::QColor,   11,
    QMetaType::Void, QMetaType::QColor,   13,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void, QMetaType::QColor,   17,
    QMetaType::Void, QMetaType::QColor,   19,
    QMetaType::Void, QMetaType::QColor,   21,
    QMetaType::Void, QMetaType::QColor,   23,
    QMetaType::Void, QMetaType::QColor,   25,
    QMetaType::Void, QMetaType::QColor,   27,
    QMetaType::Void, QMetaType::QColor,   29,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    5,

 // properties: name, type, flags
       7, QMetaType::QColor, 0x00095103,
       9, QMetaType::QColor, 0x00095103,
      11, QMetaType::QColor, 0x00095103,
      13, QMetaType::QColor, 0x00095103,
      15, QMetaType::QColor, 0x00095103,
      17, QMetaType::QColor, 0x00095103,
      19, QMetaType::QColor, 0x00095103,
      21, QMetaType::QColor, 0x00095103,
      23, QMetaType::QColor, 0x00095103,
      25, QMetaType::QColor, 0x00095103,
      27, QMetaType::QColor, 0x00095103,
      29, QMetaType::QColor, 0x00095103,
       3, QMetaType::Int, 0x00095103,
       5, QMetaType::Int, 0x00095103,

       0        // eod
};

void GaugePlane::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        GaugePlane *_t = static_cast<GaugePlane *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->degChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->rollChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->setBorderOutColorStart((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 3: _t->setBorderOutColorEnd((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 4: _t->setBorderInColorStart((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 5: _t->setBorderInColorEnd((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 6: _t->setBgColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 7: _t->setPlaneColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 8: _t->setGlassColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 9: _t->setScaleColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 10: _t->setLineColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 11: _t->setTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 12: _t->setPointerColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 13: _t->setHandleColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 14: _t->setDegValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->setRollValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (GaugePlane::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GaugePlane::degChanged)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (GaugePlane::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GaugePlane::rollChanged)) {
                *result = 1;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        GaugePlane *_t = static_cast<GaugePlane *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = _t->getBorderOutColorStart(); break;
        case 1: *reinterpret_cast< QColor*>(_v) = _t->getBorderOutColorEnd(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->getBorderInColorStart(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = _t->getBorderInColorEnd(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->getBgColor(); break;
        case 5: *reinterpret_cast< QColor*>(_v) = _t->getPlaneColor(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->getGlassColor(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->getScaleColor(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->getLineColor(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->getTextColor(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->getPointerColor(); break;
        case 11: *reinterpret_cast< QColor*>(_v) = _t->getHandleColor(); break;
        case 12: *reinterpret_cast< int*>(_v) = _t->getDegValue(); break;
        case 13: *reinterpret_cast< int*>(_v) = _t->getRollValue(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        GaugePlane *_t = static_cast<GaugePlane *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setBorderOutColorStart(*reinterpret_cast< QColor*>(_v)); break;
        case 1: _t->setBorderOutColorEnd(*reinterpret_cast< QColor*>(_v)); break;
        case 2: _t->setBorderInColorStart(*reinterpret_cast< QColor*>(_v)); break;
        case 3: _t->setBorderInColorEnd(*reinterpret_cast< QColor*>(_v)); break;
        case 4: _t->setBgColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: _t->setPlaneColor(*reinterpret_cast< QColor*>(_v)); break;
        case 6: _t->setGlassColor(*reinterpret_cast< QColor*>(_v)); break;
        case 7: _t->setScaleColor(*reinterpret_cast< QColor*>(_v)); break;
        case 8: _t->setLineColor(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 10: _t->setPointerColor(*reinterpret_cast< QColor*>(_v)); break;
        case 11: _t->setHandleColor(*reinterpret_cast< QColor*>(_v)); break;
        case 12: _t->setDegValue(*reinterpret_cast< int*>(_v)); break;
        case 13: _t->setRollValue(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject GaugePlane::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_GaugePlane.data,
      qt_meta_data_GaugePlane,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *GaugePlane::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GaugePlane::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GaugePlane.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int GaugePlane::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 14;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void GaugePlane::degChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void GaugePlane::rollChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
