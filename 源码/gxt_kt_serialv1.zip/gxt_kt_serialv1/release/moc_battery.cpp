/****************************************************************************
** Meta object code from reading C++ file 'battery.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../sdk/HeadFile/battery.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'battery.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Battery_t {
    QByteArrayData data[35];
    char stringdata0[446];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Battery_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Battery_t qt_meta_stringdata_Battery = {
    {
QT_MOC_LITERAL(0, 0, 7), // "Battery"
QT_MOC_LITERAL(1, 8, 12), // "valueChanged"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 5), // "value"
QT_MOC_LITERAL(4, 28, 11), // "updateValue"
QT_MOC_LITERAL(5, 40, 8), // "setRange"
QT_MOC_LITERAL(6, 49, 8), // "minValue"
QT_MOC_LITERAL(7, 58, 8), // "maxValue"
QT_MOC_LITERAL(8, 67, 11), // "setMinValue"
QT_MOC_LITERAL(9, 79, 11), // "setMaxValue"
QT_MOC_LITERAL(10, 91, 8), // "setValue"
QT_MOC_LITERAL(11, 100, 13), // "setAlarmValue"
QT_MOC_LITERAL(12, 114, 10), // "alarmValue"
QT_MOC_LITERAL(13, 125, 7), // "setStep"
QT_MOC_LITERAL(14, 133, 4), // "step"
QT_MOC_LITERAL(15, 138, 14), // "setBorderWidth"
QT_MOC_LITERAL(16, 153, 11), // "borderWidth"
QT_MOC_LITERAL(17, 165, 15), // "setBorderRadius"
QT_MOC_LITERAL(18, 181, 12), // "borderRadius"
QT_MOC_LITERAL(19, 194, 11), // "setBgRadius"
QT_MOC_LITERAL(20, 206, 8), // "bgRadius"
QT_MOC_LITERAL(21, 215, 13), // "setHeadRadius"
QT_MOC_LITERAL(22, 229, 10), // "headRadius"
QT_MOC_LITERAL(23, 240, 19), // "setBorderColorStart"
QT_MOC_LITERAL(24, 260, 16), // "borderColorStart"
QT_MOC_LITERAL(25, 277, 17), // "setBorderColorEnd"
QT_MOC_LITERAL(26, 295, 14), // "borderColorEnd"
QT_MOC_LITERAL(27, 310, 18), // "setAlarmColorStart"
QT_MOC_LITERAL(28, 329, 15), // "alarmColorStart"
QT_MOC_LITERAL(29, 345, 16), // "setAlarmColorEnd"
QT_MOC_LITERAL(30, 362, 13), // "alarmColorEnd"
QT_MOC_LITERAL(31, 376, 19), // "setNormalColorStart"
QT_MOC_LITERAL(32, 396, 16), // "normalColorStart"
QT_MOC_LITERAL(33, 413, 17), // "setNormalColorEnd"
QT_MOC_LITERAL(34, 431, 14) // "normalColorEnd"

    },
    "Battery\0valueChanged\0\0value\0updateValue\0"
    "setRange\0minValue\0maxValue\0setMinValue\0"
    "setMaxValue\0setValue\0setAlarmValue\0"
    "alarmValue\0setStep\0step\0setBorderWidth\0"
    "borderWidth\0setBorderRadius\0borderRadius\0"
    "setBgRadius\0bgRadius\0setHeadRadius\0"
    "headRadius\0setBorderColorStart\0"
    "borderColorStart\0setBorderColorEnd\0"
    "borderColorEnd\0setAlarmColorStart\0"
    "alarmColorStart\0setAlarmColorEnd\0"
    "alarmColorEnd\0setNormalColorStart\0"
    "normalColorStart\0setNormalColorEnd\0"
    "normalColorEnd"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Battery[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
      15,  192, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  124,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,  127,    2, 0x08 /* Private */,
       5,    2,  128,    2, 0x0a /* Public */,
       5,    2,  133,    2, 0x0a /* Public */,
       8,    1,  138,    2, 0x0a /* Public */,
       9,    1,  141,    2, 0x0a /* Public */,
      10,    1,  144,    2, 0x0a /* Public */,
      10,    1,  147,    2, 0x0a /* Public */,
      11,    1,  150,    2, 0x0a /* Public */,
      11,    1,  153,    2, 0x0a /* Public */,
      13,    1,  156,    2, 0x0a /* Public */,
      13,    1,  159,    2, 0x0a /* Public */,
      15,    1,  162,    2, 0x0a /* Public */,
      17,    1,  165,    2, 0x0a /* Public */,
      19,    1,  168,    2, 0x0a /* Public */,
      21,    1,  171,    2, 0x0a /* Public */,
      23,    1,  174,    2, 0x0a /* Public */,
      25,    1,  177,    2, 0x0a /* Public */,
      27,    1,  180,    2, 0x0a /* Public */,
      29,    1,  183,    2, 0x0a /* Public */,
      31,    1,  186,    2, 0x0a /* Public */,
      33,    1,  189,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Double,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double, QMetaType::Double,    6,    7,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    6,    7,
    QMetaType::Void, QMetaType::Double,    6,
    QMetaType::Void, QMetaType::Double,    7,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Double,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Double,   14,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   18,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   22,
    QMetaType::Void, QMetaType::QColor,   24,
    QMetaType::Void, QMetaType::QColor,   26,
    QMetaType::Void, QMetaType::QColor,   28,
    QMetaType::Void, QMetaType::QColor,   30,
    QMetaType::Void, QMetaType::QColor,   32,
    QMetaType::Void, QMetaType::QColor,   34,

 // properties: name, type, flags
       6, QMetaType::Double, 0x00095103,
       7, QMetaType::Double, 0x00095103,
       3, QMetaType::Double, 0x00095103,
      12, QMetaType::Double, 0x00095103,
      14, QMetaType::Double, 0x00095103,
      16, QMetaType::Int, 0x00095103,
      18, QMetaType::Int, 0x00095103,
      20, QMetaType::Int, 0x00095103,
      22, QMetaType::Int, 0x00095103,
      24, QMetaType::QColor, 0x00095103,
      26, QMetaType::QColor, 0x00095103,
      28, QMetaType::QColor, 0x00095103,
      30, QMetaType::QColor, 0x00095103,
      32, QMetaType::QColor, 0x00095103,
      34, QMetaType::QColor, 0x00095103,

       0        // eod
};

void Battery::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Battery *_t = static_cast<Battery *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 1: _t->updateValue(); break;
        case 2: _t->setRange((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 3: _t->setRange((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->setMinValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 5: _t->setMaxValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 6: _t->setValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 7: _t->setValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->setAlarmValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 9: _t->setAlarmValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->setStep((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 11: _t->setStep((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->setBorderWidth((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->setBorderRadius((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->setBgRadius((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->setHeadRadius((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->setBorderColorStart((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 17: _t->setBorderColorEnd((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 18: _t->setAlarmColorStart((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 19: _t->setAlarmColorEnd((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 20: _t->setNormalColorStart((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 21: _t->setNormalColorEnd((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (Battery::*_t)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Battery::valueChanged)) {
                *result = 0;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        Battery *_t = static_cast<Battery *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< double*>(_v) = _t->getMinValue(); break;
        case 1: *reinterpret_cast< double*>(_v) = _t->getMaxValue(); break;
        case 2: *reinterpret_cast< double*>(_v) = _t->getValue(); break;
        case 3: *reinterpret_cast< double*>(_v) = _t->getAlarmValue(); break;
        case 4: *reinterpret_cast< double*>(_v) = _t->getStep(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->getBorderWidth(); break;
        case 6: *reinterpret_cast< int*>(_v) = _t->getBorderRadius(); break;
        case 7: *reinterpret_cast< int*>(_v) = _t->getBgRadius(); break;
        case 8: *reinterpret_cast< int*>(_v) = _t->getHeadRadius(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->getBorderColorStart(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->getBorderColorEnd(); break;
        case 11: *reinterpret_cast< QColor*>(_v) = _t->getAlarmColorStart(); break;
        case 12: *reinterpret_cast< QColor*>(_v) = _t->getAlarmColorEnd(); break;
        case 13: *reinterpret_cast< QColor*>(_v) = _t->getNormalColorStart(); break;
        case 14: *reinterpret_cast< QColor*>(_v) = _t->getNormalColorEnd(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        Battery *_t = static_cast<Battery *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setMinValue(*reinterpret_cast< double*>(_v)); break;
        case 1: _t->setMaxValue(*reinterpret_cast< double*>(_v)); break;
        case 2: _t->setValue(*reinterpret_cast< double*>(_v)); break;
        case 3: _t->setAlarmValue(*reinterpret_cast< double*>(_v)); break;
        case 4: _t->setStep(*reinterpret_cast< double*>(_v)); break;
        case 5: _t->setBorderWidth(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setBorderRadius(*reinterpret_cast< int*>(_v)); break;
        case 7: _t->setBgRadius(*reinterpret_cast< int*>(_v)); break;
        case 8: _t->setHeadRadius(*reinterpret_cast< int*>(_v)); break;
        case 9: _t->setBorderColorStart(*reinterpret_cast< QColor*>(_v)); break;
        case 10: _t->setBorderColorEnd(*reinterpret_cast< QColor*>(_v)); break;
        case 11: _t->setAlarmColorStart(*reinterpret_cast< QColor*>(_v)); break;
        case 12: _t->setAlarmColorEnd(*reinterpret_cast< QColor*>(_v)); break;
        case 13: _t->setNormalColorStart(*reinterpret_cast< QColor*>(_v)); break;
        case 14: _t->setNormalColorEnd(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject Battery::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_Battery.data,
      qt_meta_data_Battery,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Battery::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Battery::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Battery.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Battery::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 15;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 15;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 15;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 15;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 15;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void Battery::valueChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
