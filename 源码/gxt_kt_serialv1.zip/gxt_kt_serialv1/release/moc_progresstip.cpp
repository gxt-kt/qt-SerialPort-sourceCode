/****************************************************************************
** Meta object code from reading C++ file 'progresstip.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../sdk/HeadFile/progresstip.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'progresstip.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ProgressTip_t {
    QByteArrayData data[26];
    char stringdata0[260];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ProgressTip_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ProgressTip_t qt_meta_stringdata_ProgressTip = {
    {
QT_MOC_LITERAL(0, 0, 11), // "ProgressTip"
QT_MOC_LITERAL(1, 12, 12), // "valueChanged"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 5), // "value"
QT_MOC_LITERAL(4, 32, 8), // "setRange"
QT_MOC_LITERAL(5, 41, 8), // "minValue"
QT_MOC_LITERAL(6, 50, 8), // "maxValue"
QT_MOC_LITERAL(7, 59, 11), // "setMinValue"
QT_MOC_LITERAL(8, 71, 11), // "setMaxValue"
QT_MOC_LITERAL(9, 83, 8), // "setValue"
QT_MOC_LITERAL(10, 92, 10), // "setPercent"
QT_MOC_LITERAL(11, 103, 7), // "percent"
QT_MOC_LITERAL(12, 111, 10), // "setPadding"
QT_MOC_LITERAL(13, 122, 7), // "padding"
QT_MOC_LITERAL(14, 130, 9), // "setRadius"
QT_MOC_LITERAL(15, 140, 6), // "radius"
QT_MOC_LITERAL(16, 147, 13), // "setValueBrush"
QT_MOC_LITERAL(17, 161, 10), // "valueBrush"
QT_MOC_LITERAL(18, 172, 13), // "setValueColor"
QT_MOC_LITERAL(19, 186, 10), // "valueColor"
QT_MOC_LITERAL(20, 197, 10), // "setBgColor"
QT_MOC_LITERAL(21, 208, 7), // "bgColor"
QT_MOC_LITERAL(22, 216, 11), // "setTipColor"
QT_MOC_LITERAL(23, 228, 8), // "tipColor"
QT_MOC_LITERAL(24, 237, 12), // "setTextColor"
QT_MOC_LITERAL(25, 250, 9) // "textColor"

    },
    "ProgressTip\0valueChanged\0\0value\0"
    "setRange\0minValue\0maxValue\0setMinValue\0"
    "setMaxValue\0setValue\0setPercent\0percent\0"
    "setPadding\0padding\0setRadius\0radius\0"
    "setValueBrush\0valueBrush\0setValueColor\0"
    "valueColor\0setBgColor\0bgColor\0setTipColor\0"
    "tipColor\0setTextColor\0textColor"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ProgressTip[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
      11,  138, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   89,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    2,   92,    2, 0x0a /* Public */,
       4,    2,   97,    2, 0x0a /* Public */,
       7,    1,  102,    2, 0x0a /* Public */,
       8,    1,  105,    2, 0x0a /* Public */,
       9,    1,  108,    2, 0x0a /* Public */,
       9,    1,  111,    2, 0x0a /* Public */,
      10,    1,  114,    2, 0x0a /* Public */,
      12,    1,  117,    2, 0x0a /* Public */,
      14,    1,  120,    2, 0x0a /* Public */,
      16,    1,  123,    2, 0x0a /* Public */,
      18,    1,  126,    2, 0x0a /* Public */,
      20,    1,  129,    2, 0x0a /* Public */,
      22,    1,  132,    2, 0x0a /* Public */,
      24,    1,  135,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Double,    3,

 // slots: parameters
    QMetaType::Void, QMetaType::Double, QMetaType::Double,    5,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    5,    6,
    QMetaType::Void, QMetaType::Double,    5,
    QMetaType::Void, QMetaType::Double,    6,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Bool,   11,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::QBrush,   17,
    QMetaType::Void, QMetaType::QColor,   19,
    QMetaType::Void, QMetaType::QColor,   21,
    QMetaType::Void, QMetaType::QColor,   23,
    QMetaType::Void, QMetaType::QColor,   25,

 // properties: name, type, flags
       5, QMetaType::Double, 0x00095103,
       6, QMetaType::Double, 0x00095103,
       3, QMetaType::Double, 0x00095103,
      11, QMetaType::Bool, 0x00095103,
      13, QMetaType::Int, 0x00095103,
      15, QMetaType::Int, 0x00095103,
      17, QMetaType::QBrush, 0x00095103,
      19, QMetaType::QColor, 0x00095103,
      21, QMetaType::QColor, 0x00095103,
      23, QMetaType::QColor, 0x00095103,
      25, QMetaType::QColor, 0x00095103,

       0        // eod
};

void ProgressTip::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ProgressTip *_t = static_cast<ProgressTip *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 1: _t->setRange((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 2: _t->setRange((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: _t->setMinValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 4: _t->setMaxValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 5: _t->setValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 6: _t->setValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->setPercent((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->setPadding((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->setRadius((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->setValueBrush((*reinterpret_cast< const QBrush(*)>(_a[1]))); break;
        case 11: _t->setValueColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 12: _t->setBgColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 13: _t->setTipColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 14: _t->setTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (ProgressTip::*_t)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ProgressTip::valueChanged)) {
                *result = 0;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        ProgressTip *_t = static_cast<ProgressTip *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< double*>(_v) = _t->getMinValue(); break;
        case 1: *reinterpret_cast< double*>(_v) = _t->getMaxValue(); break;
        case 2: *reinterpret_cast< double*>(_v) = _t->getValue(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->getPercent(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->getPadding(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->getRadius(); break;
        case 6: *reinterpret_cast< QBrush*>(_v) = _t->getValueBrush(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->getValueColor(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->getBgColor(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->getTipColor(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->getTextColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        ProgressTip *_t = static_cast<ProgressTip *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setMinValue(*reinterpret_cast< double*>(_v)); break;
        case 1: _t->setMaxValue(*reinterpret_cast< double*>(_v)); break;
        case 2: _t->setValue(*reinterpret_cast< double*>(_v)); break;
        case 3: _t->setPercent(*reinterpret_cast< bool*>(_v)); break;
        case 4: _t->setPadding(*reinterpret_cast< int*>(_v)); break;
        case 5: _t->setRadius(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setValueBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 7: _t->setValueColor(*reinterpret_cast< QColor*>(_v)); break;
        case 8: _t->setBgColor(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setTipColor(*reinterpret_cast< QColor*>(_v)); break;
        case 10: _t->setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject ProgressTip::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ProgressTip.data,
      qt_meta_data_ProgressTip,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *ProgressTip::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ProgressTip::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ProgressTip.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int ProgressTip::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 11;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 11;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 11;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 11;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 11;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void ProgressTip::valueChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
