/****************************************************************************
** Meta object code from reading C++ file 'panelitem.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../panelitem.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'panelitem.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PanelItem_t {
    QByteArrayData data[41];
    char stringdata0[557];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PanelItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PanelItem_t qt_meta_stringdata_PanelItem = {
    {
QT_MOC_LITERAL(0, 0, 9), // "PanelItem"
QT_MOC_LITERAL(1, 10, 10), // "checkAlarm"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 8), // "setAlarm"
QT_MOC_LITERAL(4, 31, 5), // "alarm"
QT_MOC_LITERAL(5, 37, 9), // "setEnable"
QT_MOC_LITERAL(6, 47, 6), // "enable"
QT_MOC_LITERAL(7, 54, 14), // "setTitleHeight"
QT_MOC_LITERAL(8, 69, 11), // "titleHeight"
QT_MOC_LITERAL(9, 81, 12), // "setTitleText"
QT_MOC_LITERAL(10, 94, 9), // "titleText"
QT_MOC_LITERAL(11, 104, 12), // "setTitleFont"
QT_MOC_LITERAL(12, 117, 9), // "titleFont"
QT_MOC_LITERAL(13, 127, 17), // "setTitleAlignment"
QT_MOC_LITERAL(14, 145, 9), // "Alignment"
QT_MOC_LITERAL(15, 155, 14), // "titleAlignment"
QT_MOC_LITERAL(16, 170, 13), // "setTitleColor"
QT_MOC_LITERAL(17, 184, 10), // "titleColor"
QT_MOC_LITERAL(18, 195, 20), // "setTitleDisableColor"
QT_MOC_LITERAL(19, 216, 17), // "titleDisableColor"
QT_MOC_LITERAL(20, 234, 14), // "setBorderWidth"
QT_MOC_LITERAL(21, 249, 11), // "borderWidth"
QT_MOC_LITERAL(22, 261, 15), // "setBorderRadius"
QT_MOC_LITERAL(23, 277, 12), // "borderRadius"
QT_MOC_LITERAL(24, 290, 14), // "setBorderColor"
QT_MOC_LITERAL(25, 305, 11), // "borderColor"
QT_MOC_LITERAL(26, 317, 21), // "setBorderDisableColor"
QT_MOC_LITERAL(27, 339, 18), // "borderDisableColor"
QT_MOC_LITERAL(28, 358, 16), // "setAlarmInterval"
QT_MOC_LITERAL(29, 375, 13), // "alarmInterval"
QT_MOC_LITERAL(30, 389, 17), // "setAlarmTextColor"
QT_MOC_LITERAL(31, 407, 14), // "alarmTextColor"
QT_MOC_LITERAL(32, 422, 17), // "setAlarmDarkColor"
QT_MOC_LITERAL(33, 440, 14), // "alarmDarkColor"
QT_MOC_LITERAL(34, 455, 19), // "setAlarmNormalColor"
QT_MOC_LITERAL(35, 475, 16), // "alarmNormalColor"
QT_MOC_LITERAL(36, 492, 7), // "isAlarm"
QT_MOC_LITERAL(37, 500, 8), // "isEnable"
QT_MOC_LITERAL(38, 509, 14), // "Alignment_Left"
QT_MOC_LITERAL(39, 524, 16), // "Alignment_Center"
QT_MOC_LITERAL(40, 541, 15) // "Alignment_Right"

    },
    "PanelItem\0checkAlarm\0\0setAlarm\0alarm\0"
    "setEnable\0enable\0setTitleHeight\0"
    "titleHeight\0setTitleText\0titleText\0"
    "setTitleFont\0titleFont\0setTitleAlignment\0"
    "Alignment\0titleAlignment\0setTitleColor\0"
    "titleColor\0setTitleDisableColor\0"
    "titleDisableColor\0setBorderWidth\0"
    "borderWidth\0setBorderRadius\0borderRadius\0"
    "setBorderColor\0borderColor\0"
    "setBorderDisableColor\0borderDisableColor\0"
    "setAlarmInterval\0alarmInterval\0"
    "setAlarmTextColor\0alarmTextColor\0"
    "setAlarmDarkColor\0alarmDarkColor\0"
    "setAlarmNormalColor\0alarmNormalColor\0"
    "isAlarm\0isEnable\0Alignment_Left\0"
    "Alignment_Center\0Alignment_Right"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PanelItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
      16,  148, // properties
       1,  196, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   99,    2, 0x08 /* Private */,
       3,    1,  100,    2, 0x0a /* Public */,
       5,    1,  103,    2, 0x0a /* Public */,
       7,    1,  106,    2, 0x0a /* Public */,
       9,    1,  109,    2, 0x0a /* Public */,
      11,    1,  112,    2, 0x0a /* Public */,
      13,    1,  115,    2, 0x0a /* Public */,
      16,    1,  118,    2, 0x0a /* Public */,
      18,    1,  121,    2, 0x0a /* Public */,
      20,    1,  124,    2, 0x0a /* Public */,
      22,    1,  127,    2, 0x0a /* Public */,
      24,    1,  130,    2, 0x0a /* Public */,
      26,    1,  133,    2, 0x0a /* Public */,
      28,    1,  136,    2, 0x0a /* Public */,
      30,    1,  139,    2, 0x0a /* Public */,
      32,    1,  142,    2, 0x0a /* Public */,
      34,    1,  145,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QFont,   12,
    QMetaType::Void, 0x80000000 | 14,   15,
    QMetaType::Void, QMetaType::QColor,   17,
    QMetaType::Void, QMetaType::QColor,   19,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, QMetaType::QColor,   25,
    QMetaType::Void, QMetaType::QColor,   27,
    QMetaType::Void, QMetaType::Int,   29,
    QMetaType::Void, QMetaType::QColor,   31,
    QMetaType::Void, QMetaType::QColor,   33,
    QMetaType::Void, QMetaType::QColor,   35,

 // properties: name, type, flags
       8, QMetaType::Int, 0x00095103,
      10, QMetaType::QString, 0x00095103,
      12, QMetaType::QFont, 0x00095103,
      15, 0x80000000 | 14, 0x0009510b,
      17, QMetaType::QColor, 0x00095103,
      19, QMetaType::QColor, 0x00095103,
      21, QMetaType::Int, 0x00095103,
      23, QMetaType::Int, 0x00095103,
      25, QMetaType::QColor, 0x00095103,
      27, QMetaType::QColor, 0x00095103,
      29, QMetaType::Int, 0x00095103,
      31, QMetaType::QColor, 0x00095103,
      33, QMetaType::QColor, 0x00095103,
      35, QMetaType::QColor, 0x00095103,
      36, QMetaType::Bool, 0x00095003,
      37, QMetaType::Bool, 0x00095003,

 // enums: name, flags, count, data
      14, 0x0,    3,  200,

 // enum data: key, value
      38, uint(PanelItem::Alignment_Left),
      39, uint(PanelItem::Alignment_Center),
      40, uint(PanelItem::Alignment_Right),

       0        // eod
};

void PanelItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        PanelItem *_t = static_cast<PanelItem *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->checkAlarm(); break;
        case 1: _t->setAlarm((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->setEnable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->setTitleHeight((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->setTitleText((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->setTitleFont((*reinterpret_cast< const QFont(*)>(_a[1]))); break;
        case 6: _t->setTitleAlignment((*reinterpret_cast< const Alignment(*)>(_a[1]))); break;
        case 7: _t->setTitleColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 8: _t->setTitleDisableColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 9: _t->setBorderWidth((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->setBorderRadius((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->setBorderColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 12: _t->setBorderDisableColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 13: _t->setAlarmInterval((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->setAlarmTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 15: _t->setAlarmDarkColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 16: _t->setAlarmNormalColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        default: ;
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        PanelItem *_t = static_cast<PanelItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->getTitleHeight(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->getTitleText(); break;
        case 2: *reinterpret_cast< QFont*>(_v) = _t->getTitleFont(); break;
        case 3: *reinterpret_cast< Alignment*>(_v) = _t->getTitleAlignment(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->getTitleColor(); break;
        case 5: *reinterpret_cast< QColor*>(_v) = _t->getTitleDisableColor(); break;
        case 6: *reinterpret_cast< int*>(_v) = _t->getBorderWidth(); break;
        case 7: *reinterpret_cast< int*>(_v) = _t->getBorderRadius(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->getBorderColor(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->getBorderDisableColor(); break;
        case 10: *reinterpret_cast< int*>(_v) = _t->getAlarmInterval(); break;
        case 11: *reinterpret_cast< QColor*>(_v) = _t->getAlarmTextColor(); break;
        case 12: *reinterpret_cast< QColor*>(_v) = _t->getAlarmDarkColor(); break;
        case 13: *reinterpret_cast< QColor*>(_v) = _t->getAlarmNormalColor(); break;
        case 14: *reinterpret_cast< bool*>(_v) = _t->getIsAlarm(); break;
        case 15: *reinterpret_cast< bool*>(_v) = _t->getIsEnable(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        PanelItem *_t = static_cast<PanelItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTitleHeight(*reinterpret_cast< int*>(_v)); break;
        case 1: _t->setTitleText(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setTitleFont(*reinterpret_cast< QFont*>(_v)); break;
        case 3: _t->setTitleAlignment(*reinterpret_cast< Alignment*>(_v)); break;
        case 4: _t->setTitleColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: _t->setTitleDisableColor(*reinterpret_cast< QColor*>(_v)); break;
        case 6: _t->setBorderWidth(*reinterpret_cast< int*>(_v)); break;
        case 7: _t->setBorderRadius(*reinterpret_cast< int*>(_v)); break;
        case 8: _t->setBorderColor(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setBorderDisableColor(*reinterpret_cast< QColor*>(_v)); break;
        case 10: _t->setAlarmInterval(*reinterpret_cast< int*>(_v)); break;
        case 11: _t->setAlarmTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 12: _t->setAlarmDarkColor(*reinterpret_cast< QColor*>(_v)); break;
        case 13: _t->setAlarmNormalColor(*reinterpret_cast< QColor*>(_v)); break;
        case 14: _t->setAlarm(*reinterpret_cast< bool*>(_v)); break;
        case 15: _t->setEnable(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject PanelItem::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_PanelItem.data,
      qt_meta_data_PanelItem,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *PanelItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PanelItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PanelItem.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int PanelItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 17;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 16;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
