/********************************************************************************
** Form generated from reading UI file 'scopech.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCOPECH_H
#define UI_SCOPECH_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ScopeCh
{
public:
    QCheckBox *ScopeCh_n;
    QLabel *ScopeCh_num;
    QLabel *FpsVal;

    void setupUi(QWidget *ScopeCh)
    {
        if (ScopeCh->objectName().isEmpty())
            ScopeCh->setObjectName(QStringLiteral("ScopeCh"));
        ScopeCh->resize(205, 24);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ScopeCh->sizePolicy().hasHeightForWidth());
        ScopeCh->setSizePolicy(sizePolicy);
        ScopeCh->setMinimumSize(QSize(205, 24));
        ScopeCh->setMaximumSize(QSize(205, 24));
        ScopeCh->setAutoFillBackground(false);
        ScopeCh->setStyleSheet(QStringLiteral("font: 75 10pt \"Consolas\";"));
        ScopeCh_n = new QCheckBox(ScopeCh);
        ScopeCh_n->setObjectName(QStringLiteral("ScopeCh_n"));
        ScopeCh_n->setGeometry(QRect(2, 2, 55, 20));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(ScopeCh_n->sizePolicy().hasHeightForWidth());
        ScopeCh_n->setSizePolicy(sizePolicy1);
        ScopeCh_n->setMinimumSize(QSize(55, 20));
        ScopeCh_n->setMaximumSize(QSize(55, 20));
        ScopeCh_n->setChecked(false);
        ScopeCh_num = new QLabel(ScopeCh);
        ScopeCh_num->setObjectName(QStringLiteral("ScopeCh_num"));
        ScopeCh_num->setGeometry(QRect(60, 2, 100, 20));
        sizePolicy1.setHeightForWidth(ScopeCh_num->sizePolicy().hasHeightForWidth());
        ScopeCh_num->setSizePolicy(sizePolicy1);
        ScopeCh_num->setMinimumSize(QSize(100, 20));
        ScopeCh_num->setMaximumSize(QSize(100, 20));
        ScopeCh_num->setLayoutDirection(Qt::LeftToRight);
        ScopeCh_num->setAutoFillBackground(false);
        ScopeCh_num->setStyleSheet(QStringLiteral("font: 75 11pt \"Consolas\";"));
        ScopeCh_num->setFrameShape(QFrame::NoFrame);
        ScopeCh_num->setFrameShadow(QFrame::Plain);
        ScopeCh_num->setScaledContents(false);
        ScopeCh_num->setWordWrap(false);
        ScopeCh_num->setOpenExternalLinks(false);
        FpsVal = new QLabel(ScopeCh);
        FpsVal->setObjectName(QStringLiteral("FpsVal"));
        FpsVal->setGeometry(QRect(172, 4, 31, 16));
        FpsVal->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        FpsVal->setAlignment(Qt::AlignCenter);
        FpsVal->setTextInteractionFlags(Qt::TextBrowserInteraction);

        retranslateUi(ScopeCh);

        QMetaObject::connectSlotsByName(ScopeCh);
    } // setupUi

    void retranslateUi(QWidget *ScopeCh)
    {
        ScopeCh->setWindowTitle(QApplication::translate("ScopeCh", "Form", Q_NULLPTR));
        ScopeCh_n->setText(QApplication::translate("ScopeCh", "Chn", Q_NULLPTR));
        ScopeCh_num->setText(QApplication::translate("ScopeCh", "ScopeCh_num", Q_NULLPTR));
        FpsVal->setText(QApplication::translate("ScopeCh", "0", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ScopeCh: public Ui_ScopeCh {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCOPECH_H
