#include "basicinfo.h"
#include <stdio.h>

Ui::Widget *my_ui = nullptr;


void ui_init(Ui::Widget *ui_ptr)
{
    my_ui = ui_ptr;
}

BasicInfo::BasicInfo()
{

}

//BasicInfo basic_info;
long long int BasicInfo::SendCnt=0;
long long int BasicInfo::RecCnt=0;
long long int BasicInfo::RecCntTot=0;
long long int BasicInfo::AgreeCnt=0;
void BasicInfo::AddSendNum(int n){
    SendCnt+=n;
    SendNumShow();
}
void BasicInfo::AddRecNum(int n){
    RecCnt+=n;
    RecCntTot+=n;
    RecNumShow();
}
long BasicInfo::GetRecNum(void){
    return RecCntTot;
}
void BasicInfo::AddAgreeNum(int n){
    AgreeCnt+=n;
}
long BasicInfo::GetAgreeNum(void){
    return AgreeCnt;
}
void BasicInfo::ClearRecSendNum(void){
    SendCnt=0;
    RecCnt=0;
    RecSendNumShow();
}

void BasicInfo::RecSendNumShow(void)
{
    char str[12]={0};
    sprintf(str,"%lld",RecCnt);
    my_ui->RecNum->setText(str);
    sprintf(str,"%lld",SendCnt);
    my_ui->SendNum->setText(str);
}

void BasicInfo::SendNumShow(void)
{
    char str[12]={0};
    sprintf(str,"%lld",SendCnt);
    my_ui->SendNum->setText(str);
}
void BasicInfo::RecNumShow(void)
{
    char str[12]={0};
    sprintf(str,"%lld",RecCnt);
    my_ui->RecNum->setText(str);
}
