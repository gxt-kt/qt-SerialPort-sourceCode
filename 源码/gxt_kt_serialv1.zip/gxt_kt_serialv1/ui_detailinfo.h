/********************************************************************************
** Form generated from reading UI file 'detailinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DETAILINFO_H
#define UI_DETAILINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DetailInfo
{
public:
    QGridLayout *gridLayout;
    QTreeWidget *treeWidget;

    void setupUi(QWidget *DetailInfo)
    {
        if (DetailInfo->objectName().isEmpty())
            DetailInfo->setObjectName(QStringLiteral("DetailInfo"));
        DetailInfo->resize(759, 442);
        gridLayout = new QGridLayout(DetailInfo);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        treeWidget = new QTreeWidget(DetailInfo);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem(treeWidget);
        new QTreeWidgetItem(__qtreewidgetitem);
        new QTreeWidgetItem(__qtreewidgetitem);
        new QTreeWidgetItem(__qtreewidgetitem);
        new QTreeWidgetItem(__qtreewidgetitem);
        new QTreeWidgetItem(__qtreewidgetitem);
        QTreeWidgetItem *__qtreewidgetitem1 = new QTreeWidgetItem(treeWidget);
        new QTreeWidgetItem(__qtreewidgetitem1);
        new QTreeWidgetItem(__qtreewidgetitem1);
        new QTreeWidgetItem(__qtreewidgetitem1);
        new QTreeWidgetItem(__qtreewidgetitem1);
        new QTreeWidgetItem(__qtreewidgetitem1);
        QTreeWidgetItem *__qtreewidgetitem2 = new QTreeWidgetItem(treeWidget);
        new QTreeWidgetItem(__qtreewidgetitem2);
        new QTreeWidgetItem(__qtreewidgetitem2);
        new QTreeWidgetItem(__qtreewidgetitem2);
        new QTreeWidgetItem(__qtreewidgetitem2);
        new QTreeWidgetItem(__qtreewidgetitem2);
        QTreeWidgetItem *__qtreewidgetitem3 = new QTreeWidgetItem(treeWidget);
        new QTreeWidgetItem(__qtreewidgetitem3);
        new QTreeWidgetItem(__qtreewidgetitem3);
        new QTreeWidgetItem(__qtreewidgetitem3);
        new QTreeWidgetItem(__qtreewidgetitem3);
        new QTreeWidgetItem(__qtreewidgetitem3);
        QTreeWidgetItem *__qtreewidgetitem4 = new QTreeWidgetItem(treeWidget);
        new QTreeWidgetItem(__qtreewidgetitem4);
        new QTreeWidgetItem(__qtreewidgetitem4);
        new QTreeWidgetItem(__qtreewidgetitem4);
        QTreeWidgetItem *__qtreewidgetitem5 = new QTreeWidgetItem(treeWidget);
        new QTreeWidgetItem(__qtreewidgetitem5);
        new QTreeWidgetItem(__qtreewidgetitem5);
        new QTreeWidgetItem(__qtreewidgetitem5);
        new QTreeWidgetItem(__qtreewidgetitem5);
        QTreeWidgetItem *__qtreewidgetitem6 = new QTreeWidgetItem(treeWidget);
        new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem6);
        QTreeWidgetItem *__qtreewidgetitem7 = new QTreeWidgetItem(treeWidget);
        new QTreeWidgetItem(__qtreewidgetitem7);
        new QTreeWidgetItem(__qtreewidgetitem7);
        new QTreeWidgetItem(treeWidget);
        new QTreeWidgetItem(treeWidget);
        treeWidget->setObjectName(QStringLiteral("treeWidget"));

        gridLayout->addWidget(treeWidget, 0, 0, 1, 1);


        retranslateUi(DetailInfo);

        QMetaObject::connectSlotsByName(DetailInfo);
    } // setupUi

    void retranslateUi(QWidget *DetailInfo)
    {
        DetailInfo->setWindowTitle(QApplication::translate("DetailInfo", "Form", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem = treeWidget->headerItem();
        ___qtreewidgetitem->setText(4, QApplication::translate("DetailInfo", "\350\257\264\346\230\2162", Q_NULLPTR));
        ___qtreewidgetitem->setText(3, QApplication::translate("DetailInfo", "\350\257\264\346\230\2161", Q_NULLPTR));
        ___qtreewidgetitem->setText(2, QApplication::translate("DetailInfo", "\351\242\221\347\216\207", Q_NULLPTR));
        ___qtreewidgetitem->setText(1, QApplication::translate("DetailInfo", "\346\225\260\346\215\256\345\200\274", Q_NULLPTR));
        ___qtreewidgetitem->setText(0, QApplication::translate("DetailInfo", "ID", Q_NULLPTR));

        const bool __sortingEnabled = treeWidget->isSortingEnabled();
        treeWidget->setSortingEnabled(false);
        QTreeWidgetItem *___qtreewidgetitem1 = treeWidget->topLevelItem(0);
        ___qtreewidgetitem1->setText(3, QApplication::translate("DetailInfo", "\347\244\272\346\263\242\345\231\250\351\200\232\351\201\223", Q_NULLPTR));
        ___qtreewidgetitem1->setText(0, QApplication::translate("DetailInfo", "0xF1", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem2 = ___qtreewidgetitem1->child(0);
        ___qtreewidgetitem2->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem2->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem2->setText(0, QApplication::translate("DetailInfo", "ch1", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem3 = ___qtreewidgetitem1->child(1);
        ___qtreewidgetitem3->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem3->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem3->setText(0, QApplication::translate("DetailInfo", "ch2", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem4 = ___qtreewidgetitem1->child(2);
        ___qtreewidgetitem4->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem4->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem4->setText(0, QApplication::translate("DetailInfo", "ch3", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem5 = ___qtreewidgetitem1->child(3);
        ___qtreewidgetitem5->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem5->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem5->setText(0, QApplication::translate("DetailInfo", "ch4", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem6 = ___qtreewidgetitem1->child(4);
        ___qtreewidgetitem6->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem6->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem6->setText(0, QApplication::translate("DetailInfo", "ch5", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem7 = treeWidget->topLevelItem(1);
        ___qtreewidgetitem7->setText(3, QApplication::translate("DetailInfo", "\347\244\272\346\263\242\345\231\250\351\200\232\351\201\223", Q_NULLPTR));
        ___qtreewidgetitem7->setText(0, QApplication::translate("DetailInfo", "0xF2", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem8 = ___qtreewidgetitem7->child(0);
        ___qtreewidgetitem8->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem8->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem8->setText(0, QApplication::translate("DetailInfo", "ch6", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem9 = ___qtreewidgetitem7->child(1);
        ___qtreewidgetitem9->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem9->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem9->setText(0, QApplication::translate("DetailInfo", "ch7", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem10 = ___qtreewidgetitem7->child(2);
        ___qtreewidgetitem10->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem10->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem10->setText(0, QApplication::translate("DetailInfo", "ch8", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem11 = ___qtreewidgetitem7->child(3);
        ___qtreewidgetitem11->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem11->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem11->setText(0, QApplication::translate("DetailInfo", "ch9", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem12 = ___qtreewidgetitem7->child(4);
        ___qtreewidgetitem12->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem12->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem12->setText(0, QApplication::translate("DetailInfo", "ch10", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem13 = treeWidget->topLevelItem(2);
        ___qtreewidgetitem13->setText(3, QApplication::translate("DetailInfo", "\347\244\272\346\263\242\345\231\250\351\200\232\351\201\223", Q_NULLPTR));
        ___qtreewidgetitem13->setText(0, QApplication::translate("DetailInfo", "0xF3", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem14 = ___qtreewidgetitem13->child(0);
        ___qtreewidgetitem14->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem14->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem14->setText(0, QApplication::translate("DetailInfo", "ch11", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem15 = ___qtreewidgetitem13->child(1);
        ___qtreewidgetitem15->setText(2, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem15->setText(1, QApplication::translate("DetailInfo", "0", Q_NULLPTR));
        ___qtreewidgetitem15->setText(0, QApplication::translate("DetailInfo", "ch12", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem16 = ___qtreewidgetitem13->child(2);
        ___qtreewidgetitem16->setText(0, QApplication::translate("DetailInfo", "ch13", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem17 = ___qtreewidgetitem13->child(3);
        ___qtreewidgetitem17->setText(0, QApplication::translate("DetailInfo", "ch14", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem18 = ___qtreewidgetitem13->child(4);
        ___qtreewidgetitem18->setText(0, QApplication::translate("DetailInfo", "ch15", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem19 = treeWidget->topLevelItem(3);
        ___qtreewidgetitem19->setText(3, QApplication::translate("DetailInfo", "\347\244\272\346\263\242\345\231\250\351\200\232\351\201\223", Q_NULLPTR));
        ___qtreewidgetitem19->setText(0, QApplication::translate("DetailInfo", "0xF4", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem20 = ___qtreewidgetitem19->child(0);
        ___qtreewidgetitem20->setText(0, QApplication::translate("DetailInfo", "ch16", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem21 = ___qtreewidgetitem19->child(1);
        ___qtreewidgetitem21->setText(0, QApplication::translate("DetailInfo", "ch17", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem22 = ___qtreewidgetitem19->child(2);
        ___qtreewidgetitem22->setText(0, QApplication::translate("DetailInfo", "ch18", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem23 = ___qtreewidgetitem19->child(3);
        ___qtreewidgetitem23->setText(0, QApplication::translate("DetailInfo", "ch19", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem24 = ___qtreewidgetitem19->child(4);
        ___qtreewidgetitem24->setText(0, QApplication::translate("DetailInfo", "ch20", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem25 = treeWidget->topLevelItem(4);
        ___qtreewidgetitem25->setText(4, QApplication::translate("DetailInfo", "3d \346\227\213\350\275\254\351\241\272\345\272\217 ZYX", Q_NULLPTR));
        ___qtreewidgetitem25->setText(3, QApplication::translate("DetailInfo", "\346\254\247\346\213\211\350\247\222", Q_NULLPTR));
        ___qtreewidgetitem25->setText(0, QApplication::translate("DetailInfo", "0x03", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem26 = ___qtreewidgetitem25->child(0);
        ___qtreewidgetitem26->setText(0, QApplication::translate("DetailInfo", "Roll", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem27 = ___qtreewidgetitem25->child(1);
        ___qtreewidgetitem27->setText(0, QApplication::translate("DetailInfo", "Pitch", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem28 = ___qtreewidgetitem25->child(2);
        ___qtreewidgetitem28->setText(0, QApplication::translate("DetailInfo", "Yaw", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem29 = treeWidget->topLevelItem(5);
        ___qtreewidgetitem29->setText(4, QApplication::translate("DetailInfo", "3d \346\227\213\350\275\254\351\241\272\345\272\217 ZYX", Q_NULLPTR));
        ___qtreewidgetitem29->setText(3, QApplication::translate("DetailInfo", "\345\233\233\345\205\203\346\225\260", Q_NULLPTR));
        ___qtreewidgetitem29->setText(0, QApplication::translate("DetailInfo", "0x04", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem30 = ___qtreewidgetitem29->child(0);
        ___qtreewidgetitem30->setText(0, QApplication::translate("DetailInfo", "x", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem31 = ___qtreewidgetitem29->child(1);
        ___qtreewidgetitem31->setText(0, QApplication::translate("DetailInfo", "y", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem32 = ___qtreewidgetitem29->child(2);
        ___qtreewidgetitem32->setText(0, QApplication::translate("DetailInfo", "z", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem33 = ___qtreewidgetitem29->child(3);
        ___qtreewidgetitem33->setText(0, QApplication::translate("DetailInfo", "w", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem34 = treeWidget->topLevelItem(6);
        ___qtreewidgetitem34->setText(3, QApplication::translate("DetailInfo", "\351\201\245\346\216\247\345\231\250\346\225\260\345\200\274", Q_NULLPTR));
        ___qtreewidgetitem34->setText(0, QApplication::translate("DetailInfo", "0x40", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem35 = ___qtreewidgetitem34->child(0);
        ___qtreewidgetitem35->setText(0, QApplication::translate("DetailInfo", "ch1", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem36 = ___qtreewidgetitem34->child(1);
        ___qtreewidgetitem36->setText(0, QApplication::translate("DetailInfo", "ch2", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem37 = ___qtreewidgetitem34->child(2);
        ___qtreewidgetitem37->setText(0, QApplication::translate("DetailInfo", "ch3", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem38 = ___qtreewidgetitem34->child(3);
        ___qtreewidgetitem38->setText(0, QApplication::translate("DetailInfo", "ch4", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem39 = ___qtreewidgetitem34->child(4);
        ___qtreewidgetitem39->setText(0, QApplication::translate("DetailInfo", "ch5", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem40 = ___qtreewidgetitem34->child(5);
        ___qtreewidgetitem40->setText(0, QApplication::translate("DetailInfo", "ch6", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem41 = ___qtreewidgetitem34->child(6);
        ___qtreewidgetitem41->setText(0, QApplication::translate("DetailInfo", "ch7", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem42 = ___qtreewidgetitem34->child(7);
        ___qtreewidgetitem42->setText(0, QApplication::translate("DetailInfo", "ch8", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem43 = ___qtreewidgetitem34->child(8);
        ___qtreewidgetitem43->setText(0, QApplication::translate("DetailInfo", "ch9", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem44 = ___qtreewidgetitem34->child(9);
        ___qtreewidgetitem44->setText(0, QApplication::translate("DetailInfo", "ch10", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem45 = ___qtreewidgetitem34->child(10);
        ___qtreewidgetitem45->setText(0, QApplication::translate("DetailInfo", "ch11", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem46 = ___qtreewidgetitem34->child(11);
        ___qtreewidgetitem46->setText(0, QApplication::translate("DetailInfo", "ch12", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem47 = treeWidget->topLevelItem(7);
        ___qtreewidgetitem47->setText(3, QApplication::translate("DetailInfo", "\347\224\265\345\216\213/\347\224\265\346\265\201", Q_NULLPTR));
        ___qtreewidgetitem47->setText(0, QApplication::translate("DetailInfo", "0x0D", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem48 = ___qtreewidgetitem47->child(0);
        ___qtreewidgetitem48->setText(3, QApplication::translate("DetailInfo", "\347\224\265\345\216\213\345\200\274\357\274\214\345\215\225\344\275\215V", Q_NULLPTR));
        ___qtreewidgetitem48->setText(0, QApplication::translate("DetailInfo", "Voltage", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem49 = ___qtreewidgetitem47->child(1);
        ___qtreewidgetitem49->setText(3, QApplication::translate("DetailInfo", "\347\224\265\346\265\201\345\200\274\357\274\214\345\215\225\344\275\215A", Q_NULLPTR));
        ___qtreewidgetitem49->setText(0, QApplication::translate("DetailInfo", "Current", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem50 = treeWidget->topLevelItem(8);
        ___qtreewidgetitem50->setText(0, QApplication::translate("DetailInfo", "\346\226\260\345\273\272\351\241\271\347\233\256", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem51 = treeWidget->topLevelItem(9);
        ___qtreewidgetitem51->setText(0, QApplication::translate("DetailInfo", "\346\226\260\345\273\272\351\241\271\347\233\256", Q_NULLPTR));
        treeWidget->setSortingEnabled(__sortingEnabled);

    } // retranslateUi

};

namespace Ui {
    class DetailInfo: public Ui_DetailInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DETAILINFO_H
