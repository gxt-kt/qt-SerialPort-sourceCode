#include "scoperightbtn.h"
#include "ui_scoperightbtn.h"
#include "QDebug"
#include "config.h"
#include "scopech.h"

scopeRightBtn::scopeRightBtn(QWidget *parent) :
    QMenu(parent),
    ui(new Ui::scopeRightBtn)
{
    ui->setupUi(this);
    ui->colorChoose->setShowColorName(0);
    ui->colorChoose->initItems();

//    connect(ui->Ensure,&QPushButton::clicked,[=](){
//        //按下确定键--存储信息，关闭当前窗口

//    QString colStr=ui->colorComboBox->getColorName();//获取颜色
//    QColor col;
//    col.setNamedColor(colStr);
//    QVariant qva;//写入对应通道颜色
//    qva.setValue<QColor>(col);
//    Config().Set("ScopeCol",QString("ch%1").arg(curChN),qva);

//    connect(this,&scopeRightBtn::Scopeflush,[=](){//发送刷新信号

//    });
//    //emit Scopeflush(curChN);//返回当前信号值
//    flush_test();
//    this->close();
//    });

    connect(ui->Cancel,&QPushButton::clicked,[=](){
        //按下取消--关闭当前窗口
        this->close();
    });
}

scopeRightBtn::~scopeRightBtn()
{
    delete ui;
}


