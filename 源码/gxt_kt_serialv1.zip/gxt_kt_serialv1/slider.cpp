#include "slider.h"
#include "ui_slider.h"
#include <qvalidator.h>
#include "QDebug"
#include "basicinfo.h"
#include "serialgetbyte.h"
#include "widget.h"
#include "config.h"

//有一个bug，就是手输val，确认后会刷新滑动条，滑动条触发connect导致刷新了val，可以先断开connect，show后再连接
//发现上面那个好像不太行，因为用的lamda
//可以定义一个全局变量，收输后置1，connect后如果是1清空就不更改val值，在清空标志位
#if _MSC_VER >= 1600
#pragma execution_character_set("utf-8")
#endif
Slider::Slider(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Slider)
{
    ui->setupUi(this);

    //ui->xslider->setSingleStep(100);


    //qDebug()<<"ceshi_val"<<this->objectName()<< Config().Get(this->objectName(),"val").value<double>();
//    for(int i=1;i<=20;i++)
//    {
//        ui->lineEdit_val->setText( QString("%1").arg(  Config().Get(QString("%1_%2").arg(this->objectName()).arg(i) ,"val" ).value<float>()));
////        ui->lineEdit_min->setText(QString("%1").arg(  Config().Get(this->objectName(),"min").value<float>()  ));
////        ui->lineEdit_max->setText(QString("%1").arg(  Config().Get(this->objectName(),"max").value<float>()  ));
//         ui->lineEdit_min->setText( QString("%1").arg(  Config().Get(QString("%1_%2").arg(this->objectName()).arg(i) ,"min" ).value<float>()));
//          ui->lineEdit_max->setText( QString("%1").arg(  Config().Get(QString("%1_%2").arg(this->objectName()).arg(i) ,"max" ).value<float>()));
//    }
//        qDebug()<<this->objectName();
    //static int slider_i;
    //slider_i++;
//    qDebug()<<slider_i;
//    qDebug()<<Config().Get(QString("%1_%2").arg(this->objectName()).arg(slider_i) ,"val" ).value<float>();
    //Slider *slider=this->findChild<Slider *>(QString("%1_%2").arg(this->objectName()).arg(slider_i));
    //if(slider!=NULL) qDebug()<<slider_i<<slider->objectName();
    //else qDebug()<<"NULL";
    //qDebug()<<objectName();
    //GetVal();
    //ui->lineEdit_val->setText(QString("%1").arg(slider_i));
    //ui->lineEdit_val->setText(QString("%1").arg(Config().Get(QString("%1_%2").arg(this->objectName()).arg(slider_i) ,"val" ).value<float>()));

    QRegExp regx("^(-?[0]|-?[1-9][0-9]{0,7})(?:\\.\\d{1,6})?$|(^\\t?$)$");//正则表达式
    QValidator *vad=new QRegExpValidator(regx,this);
    ui->lineEdit_val->setValidator(vad);
    ui->lineEdit_min->setValidator(vad);
    ui->lineEdit_max->setValidator(vad);

    if( ui->lineEdit_max->text().toFloat() != ui->lineEdit_min->text().toFloat() )
    {//防止最大值最小值相等出错
        int per=1000*(ui->lineEdit_val->text().toFloat()-ui->lineEdit_min->text().toFloat())/
                (ui->lineEdit_max->text().toFloat()-ui->lineEdit_min->text().toFloat());
        if(per<=1000&&per>=0) ui->xslider->setValue(per);
    }else {ui->xslider->setValue(1000);}
    ui->xslider->show();

    lastVal=(int)ui->xslider->value();

    connect(ui->lineEdit_min,&QLineEdit::selectionChanged,[=](){
        ui->checkBox_RT->setChecked(0);
    });
    connect(ui->lineEdit_min,&QLineEdit::textEdited,[=](){
        ui->checkBox_RT->setChecked(0);
    });

    //更改最小值
    connect(ui->lineEdit_min,&QLineEdit::editingFinished,[=](){
//        if(ui->lineEdit_min->text().toFloat() > ui->lineEdit_max->text().toFloat())
//        {
//            qDebug()<<QStringLiteral("提示");
//            ui->lineEdit_min->setText(ui->lineEdit_max->text());
//            return;
//        }
        if(ui->lineEdit_min->text().toFloat() > ui->lineEdit_val->text().toFloat())
        {
            qDebug()<<QStringLiteral("提示");
            ui->lineEdit_min->setText(ui->lineEdit_val->text());
            return;
        }
        if( ui->lineEdit_max->text().toFloat() != ui->lineEdit_min->text().toFloat() )
        {//防止最大值最小值相等出错
            int per=1000.0f*(ui->lineEdit_val->text().toFloat()-ui->lineEdit_min->text().toFloat())/
                    (ui->lineEdit_max->text().toFloat()-ui->lineEdit_min->text().toFloat());
            if(per<=1000&&per>=0) ui->xslider->setValue(per);
        }else {ui->xslider->setValue(1000);}

        bug_resolve1=1;

        ui->xslider->show();
        flush();
    });

    connect(ui->lineEdit_max,&QLineEdit::selectionChanged,[=](){
        ui->checkBox_RT->setChecked(0);
    });
    connect(ui->lineEdit_max,&QLineEdit::textEdited,[=](){
        ui->checkBox_RT->setChecked(0);
    });

    //更改最大值
    connect(ui->lineEdit_max,&QLineEdit::editingFinished,[=](){
//        if(ui->lineEdit_max->text().toFloat() < ui->lineEdit_min->text().toFloat())
//        {
//            qDebug()<<QStringLiteral("提示");
//            ui->lineEdit_max->setText(ui->lineEdit_min->text());
//            return;
//        }
        if(ui->lineEdit_max->text().toFloat() < ui->lineEdit_val->text().toFloat())
        {
            qDebug()<<QStringLiteral("提示");
            ui->lineEdit_max->setText(ui->lineEdit_val->text());
            return;
        }
        if( ui->lineEdit_max->text().toFloat() != ui->lineEdit_min->text().toFloat() )
        {//防止最大值最小值相等出错
            int per=1000*(ui->lineEdit_val->text().toFloat()-ui->lineEdit_min->text().toFloat())/
                    (ui->lineEdit_max->text().toFloat()-ui->lineEdit_min->text().toFloat());
            if(per<=1000&&per>=0) ui->xslider->setValue(per);
        }else {ui->xslider->setValue(1000);}

        bug_resolve1=1;

        ui->xslider->show();
        flush();
    });


    connect(ui->lineEdit_val,&QLineEdit::selectionChanged,[=](){
        ui->checkBox_RT->setChecked(0);
    });
    connect(ui->lineEdit_val,&QLineEdit::textEdited,[=](){
        ui->checkBox_RT->setChecked(0);
    });

    //更改VAL
    connect(ui->lineEdit_val,&QLineEdit::editingFinished,[=](){
//        if( ui->lineEdit_max->text().toFloat() != ui->lineEdit_min->text().toFloat() )
//        {//防止最大值最小值相等出错
//            int per=1000.0*(ui->lineEdit_val->text().toFloat()-ui->lineEdit_min->text().toFloat())/
//                    (ui->lineEdit_max->text().toFloat()-ui->lineEdit_min->text().toFloat());
//            if(per<=1000&&per>=0) ui->xslider->setValue(per);
//        }else {ui->xslider->setValue(1000);}
//        ui->xslider->show();
         if( ui->lineEdit_val->text().toFloat() < ui->lineEdit_min->text().toFloat() )//小于最小值
             ui->lineEdit_val->setText(ui->lineEdit_min->text());
         else if(ui->lineEdit_val->text().toFloat() > ui->lineEdit_max->text().toFloat())//大于最大值
             ui->lineEdit_val->setText(ui->lineEdit_max->text());

         int per=1000.0*(ui->lineEdit_val->text().toFloat()-ui->lineEdit_min->text().toFloat())/
                 (ui->lineEdit_max->text().toFloat()-ui->lineEdit_min->text().toFloat());
         if(per<=1000&&per>=0) ui->xslider->setValue(per);

         bug_resolve1=1;
         ui->xslider->show();
        flush();
    });

    //Slider信号处理
    connect(ui->xslider,&XSlider::valueChanged,[=](){
         //bug_resolve1++;
        //if(bug_resolve1==1){bug_resolve1=0;return;}

        //怀疑误点击，取消RT
        if(((float)(ui->xslider->value()-lastVal)/1000.0f)>0.2 || ((float)(ui->xslider->value()-lastVal)/1000.0f)<-0.2)
        {ui->checkBox_RT->setChecked(0);ui->checkBox_RT->show();}
        lastVal=ui->xslider->value();


        float newVal=((float)ui->xslider->value())/1000.0f*(ui->lineEdit_max->text().toFloat() - ui->lineEdit_min->text().toFloat())+ui->lineEdit_min->text().toFloat();
        QString str_val = QString("%1").arg(newVal);
        ui->lineEdit_val->setText(str_val);ui->lineEdit_val->show();


        if(ui->checkBox_RT->checkState()==2)//注意这里QTcheckbox打勾是等于2，不是1  确定发送
        {
            gxtSendSliderPid(this->objectName().replace(QRegExp("^slider_"),"").toInt(),newVal);
        }
        //qDebug()<<newVal;//调试
        flush();
    });

}

Slider::~Slider()
{
    delete ui;
}

void Slider::flush(void)
{
    Config().Set(this->objectName(),"val",ui->lineEdit_val->text().toFloat());
    Config().Set(this->objectName(),"min",ui->lineEdit_min->text().toFloat());
    Config().Set(this->objectName(),"max",ui->lineEdit_max->text().toFloat());
}

float Slider::GetVal(void)
{
    return ui->lineEdit_val->text().toFloat();
}

char gxt_data_to_send[150];
void gxtSendSliderPid(int sendCh,float gxt_a)//B0用来一个一个发送
{
    uchar gxt_cnt=0;//计数
    uchar gxt_sc=0;//对总数进行累加
    uchar gxt_ac=0;//ac对sc进行累加

    gxt_data_to_send[gxt_cnt++]=0xAA;//帧头
    gxt_data_to_send[gxt_cnt++]=0xFF;//帧头
    gxt_data_to_send[gxt_cnt++]=0xB0;//通道
    gxt_data_to_send[gxt_cnt++]=0;//数据字节数

    gxt_data_to_send[gxt_cnt++]=(char)sendCh;

    gxt_data_to_send[gxt_cnt++]=BYTE0(gxt_a);
    gxt_data_to_send[gxt_cnt++]=BYTE1(gxt_a);
    gxt_data_to_send[gxt_cnt++]=BYTE2(gxt_a);
    gxt_data_to_send[gxt_cnt++]=BYTE3(gxt_a);

    gxt_data_to_send[3]=gxt_cnt-4;

    for(uchar gxt_i=0;gxt_i<gxt_data_to_send[3]+4;gxt_i++)
    {
        gxt_sc+=gxt_data_to_send[gxt_i];
        gxt_ac+=gxt_sc;
    }

    gxt_data_to_send[gxt_cnt++]=gxt_sc;
    gxt_data_to_send[gxt_cnt++]=gxt_ac;

    if(my_ui->Btn_open->getChecked()==1)//打开了才算
    {
        Serialport->write(gxt_data_to_send,gxt_cnt);//发送数组
        BasicInfo::AddSendNum(gxt_cnt);

        QTime current_time = QTime::currentTime();
        int hour = current_time.hour();        //当前的小时
        int minute = current_time.minute();    //当前的分
        int second = current_time.second();    //当前的秒
        int msec = current_time.msec();        //当前的毫秒
        QString time_str;
        time_str.sprintf("\nT%d:%02d:%02d/%03d>>",hour,minute,second,msec);

        my_ui->textEdit->moveCursor(QTextCursor::End);
        my_ui->textEdit->setTextColor(QColor(175, 105, 105));
        my_ui->textEdit->insertPlainText(time_str);

        my_ui->textEdit->setTextColor(QColor(0, 0, 0));
        my_ui->textEdit->insertPlainText(QString("PId-Ch%1-%2").arg(sendCh).arg(gxt_a));
    }
}


void gxtSendSliderPid(int sendCh,float gxt_a,float gxt_b,float gxt_c,float gxt_d,float gxt_e)//B0用来一个一个发送
{
    uchar gxt_cnt=0;//计数
    uchar gxt_sc=0;//对总数进行累加
    uchar gxt_ac=0;//ac对sc进行累加

    gxt_data_to_send[gxt_cnt++]=0xAA;//帧头
    gxt_data_to_send[gxt_cnt++]=0xFF;//帧头
    gxt_data_to_send[gxt_cnt++]=0xB0+sendCh;//通道
    gxt_data_to_send[gxt_cnt++]=0;//数据字节数

    gxt_data_to_send[gxt_cnt++]=BYTE0(gxt_a);
    gxt_data_to_send[gxt_cnt++]=BYTE1(gxt_a);
    gxt_data_to_send[gxt_cnt++]=BYTE2(gxt_a);
    gxt_data_to_send[gxt_cnt++]=BYTE3(gxt_a);

    gxt_data_to_send[gxt_cnt++]=BYTE0(gxt_b);
    gxt_data_to_send[gxt_cnt++]=BYTE1(gxt_b);
    gxt_data_to_send[gxt_cnt++]=BYTE2(gxt_b);
    gxt_data_to_send[gxt_cnt++]=BYTE3(gxt_b);

    gxt_data_to_send[gxt_cnt++]=BYTE0(gxt_c);
    gxt_data_to_send[gxt_cnt++]=BYTE1(gxt_c);
    gxt_data_to_send[gxt_cnt++]=BYTE2(gxt_c);
    gxt_data_to_send[gxt_cnt++]=BYTE3(gxt_c);

    gxt_data_to_send[gxt_cnt++]=BYTE0(gxt_d);
    gxt_data_to_send[gxt_cnt++]=BYTE1(gxt_d);
    gxt_data_to_send[gxt_cnt++]=BYTE2(gxt_d);
    gxt_data_to_send[gxt_cnt++]=BYTE3(gxt_d);

    gxt_data_to_send[gxt_cnt++]=BYTE0(gxt_e);
    gxt_data_to_send[gxt_cnt++]=BYTE1(gxt_e);
    gxt_data_to_send[gxt_cnt++]=BYTE2(gxt_e);
    gxt_data_to_send[gxt_cnt++]=BYTE3(gxt_e);

    gxt_data_to_send[3]=gxt_cnt-4;

    for(uchar gxt_i=0;gxt_i<gxt_data_to_send[3]+4;gxt_i++)
    {
        gxt_sc+=gxt_data_to_send[gxt_i];
        gxt_ac+=gxt_sc;
    }

    gxt_data_to_send[gxt_cnt++]=gxt_sc;
    gxt_data_to_send[gxt_cnt++]=gxt_ac;

    if(my_ui->Btn_open->getChecked()==1)//打开了才算
    {
        Serialport->write(gxt_data_to_send,gxt_cnt);//发送数组
        BasicInfo::AddSendNum(gxt_cnt);

        QTime current_time = QTime::currentTime();
        int hour = current_time.hour();        //当前的小时
        int minute = current_time.minute();    //当前的分
        int second = current_time.second();    //当前的秒
        int msec = current_time.msec();        //当前的毫秒
        QString time_str;
        time_str.sprintf("\nT%d:%02d:%02d/%03d>>",hour,minute,second,msec);

        my_ui->textEdit->moveCursor(QTextCursor::End);
        my_ui->textEdit->setTextColor(QColor(175, 105, 105));
        my_ui->textEdit->insertPlainText(time_str);
        my_ui->textEdit->moveCursor(QTextCursor::End);
        my_ui->textEdit->setTextColor(QColor(0, 0, 0));
        my_ui->textEdit->insertPlainText(QString("PId-G%1-%2/%3/%4/%5/%6").arg(sendCh).arg(gxt_a).arg(gxt_b).arg(gxt_c).arg(gxt_d).arg(gxt_e));
    }
}
