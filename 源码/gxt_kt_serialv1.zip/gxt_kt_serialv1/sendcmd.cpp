#include "sendcmd.h"
#include "ui_sendcmd.h"
#include "datastorage.h"
#include "basicinfo.h"
SendCmd::SendCmd(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SendCmd)
{
    ui->setupUi(this);

    ui->cmdSend->setStyleSheet("QPushButton{color: rgb(118, 61, 0);background-color: rgb(137, 194, 255);border:2px groove gray;border-radius:10px;padding:2px 4px;border-style: outset;}"
                                               "QPushButton:hover{background-color:rgb(229, 241, 251); color: black;}"
                                               "QPushButton:pressed{background-color:rgb(204, 228, 247);border-style: inset;}"
                               "QPushButton{font: 11pt '汉仪黑荔枝体简'}");

    connect(ui->cmdSend,&QPushButton::clicked,[=](){
        if(SerPort->isOpen()==0){return;qDebug("return!");}
        if(my_ui->SendHex->isChecked()==1)
        {
        QByteArray arr;
        QString data=ui->cmdTextEdit->toPlainText();
        //分析字符串格式中是否带空格
        for(int i = 0;i<data.size();i++)
        {
            if(data[i]==' ')
                continue;   //跳过

            int num  = data.mid(i,2).toUInt(nullptr,16);
            i++;
            arr.append(num);
        }
        QString ReadSend=ui->cmdComboBox->currentText();
        if(ReadSend=="/r/n"){arr.append(0x0D);arr.append(0x0A);}
        else if(ReadSend=="/r") arr.append(0x0D);
        else if(ReadSend=="/n") arr.append(0x0A);
        SerPort->write(arr);//发送HEX格式原始数据
        BasicInfo::AddSendNum(arr.size());
        }
        else
        {QString send_b=ui->cmdTextEdit->toPlainText();
            QString ReadSend=ui->cmdComboBox->currentText();
            if(ReadSend=="/r/n"){send_b.append(0x0D);send_b.append(0x0A);}
            else if(ReadSend=="/r") send_b.append(0x0D);
            else if(ReadSend=="/n") send_b.append(0x0A);
        SerPort->write(send_b.toLocal8Bit().data());
        BasicInfo::AddSendNum(send_b.size());
        }
    });

}

SendCmd::~SendCmd()
{
    delete ui;
}
