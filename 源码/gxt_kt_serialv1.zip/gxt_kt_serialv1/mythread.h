﻿#ifndef MYTHREAD_H
#define MYTHREAD_H

//#include <QObject>
//#include <QWidget>
#include <QThread>
#include "QDebug"



#endif // MYTHREAD_H
