/********************************************************************************
** Form generated from reading UI file 'scope.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCOPE_H
#define UI_SCOPE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <scopech.h>
#include "panelitem.h"
#include "switchbutton.h"
#include "xxwcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_scope
{
public:
    QGridLayout *gridLayout_2;
    QVBoxLayout *verticalLayout_3;
    XxwCustomPlot *ScopePlot;
    QHBoxLayout *horizontalLayout_2;
    SwitchButton *ScopeShow;
    QPushButton *ShowAll;
    QPushButton *ShowClear;
    QRadioButton *AutoRun;
    QRadioButton *ShowPoint;
    QLabel *label_2;
    QComboBox *Xpoint;
    QLabel *XYval;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_2;
    PanelItem *panelItem;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    ScopeCh *Scope_Ch1;
    ScopeCh *widget_8;
    ScopeCh *Scope_Ch2;
    ScopeCh *widget_9;
    ScopeCh *Scope_Ch3;
    ScopeCh *widget_10;
    ScopeCh *Scope_Ch4;
    ScopeCh *widget_11;
    ScopeCh *Scope_Ch5;
    ScopeCh *widget_14;
    QFrame *line;
    ScopeCh *Scope_Ch6;
    ScopeCh *widget_18;
    ScopeCh *Scope_Ch7;
    ScopeCh *widget_16;
    ScopeCh *Scope_Ch8;
    ScopeCh *widget_20;
    ScopeCh *Scope_Ch9;
    ScopeCh *widget_30;
    ScopeCh *Scope_Ch10;
    ScopeCh *widget_26;
    QFrame *line_2;
    ScopeCh *Scope_Ch11;
    ScopeCh *widget_24;
    ScopeCh *Scope_Ch12;
    ScopeCh *widget_28;
    ScopeCh *Scope_Ch13;
    ScopeCh *widget_38;
    ScopeCh *Scope_Ch14;
    ScopeCh *widget_34;
    ScopeCh *Scope_Ch15;
    ScopeCh *widget_32;
    QFrame *line_3;
    ScopeCh *Scope_Ch16;
    ScopeCh *widget_36;
    ScopeCh *Scope_Ch17;
    ScopeCh *widget_50;
    ScopeCh *Scope_Ch18;
    ScopeCh *widget_45;
    ScopeCh *Scope_Ch19;
    ScopeCh *widget_41;
    ScopeCh *Scope_Ch20;
    ScopeCh *widget_48;
    QHBoxLayout *horizontalLayout;
    QPushButton *AutoDetect;
    QLabel *label;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *scope)
    {
        if (scope->objectName().isEmpty())
            scope->setObjectName(QStringLiteral("scope"));
        scope->resize(1116, 613);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(scope->sizePolicy().hasHeightForWidth());
        scope->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QStringLiteral("Consolas"));
        font.setPointSize(12);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(9);
        scope->setFont(font);
        scope->setFocusPolicy(Qt::ClickFocus);
        scope->setAutoFillBackground(true);
        scope->setStyleSheet(QStringLiteral("font: 75 12pt \"Consolas\";"));
        gridLayout_2 = new QGridLayout(scope);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        ScopePlot = new XxwCustomPlot(scope);
        ScopePlot->setObjectName(QStringLiteral("ScopePlot"));
        ScopePlot->setMinimumSize(QSize(865, 557));
        ScopePlot->setMaximumSize(QSize(50000, 500000));
        ScopePlot->setAutoFillBackground(false);
        ScopePlot->setStyleSheet(QStringLiteral("border-color: rgb(125, 145, 255);"));

        verticalLayout_3->addWidget(ScopePlot);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        ScopeShow = new SwitchButton(scope);
        ScopeShow->setObjectName(QStringLiteral("ScopeShow"));
        ScopeShow->setMinimumSize(QSize(95, 33));
        ScopeShow->setMaximumSize(QSize(95, 33));
        ScopeShow->setSpace(2);
        ScopeShow->setRectRadius(5);
        ScopeShow->setChecked(false);
        ScopeShow->setShowText(true);
        ScopeShow->setShowCircle(false);
        ScopeShow->setAnimation(true);
        ScopeShow->setButtonStyle(SwitchButton::ButtonStyle_Rect);
        ScopeShow->setBgColorOn(QColor(255, 153, 28));

        horizontalLayout_2->addWidget(ScopeShow);

        ShowAll = new QPushButton(scope);
        ShowAll->setObjectName(QStringLiteral("ShowAll"));
        ShowAll->setMinimumSize(QSize(92, 33));
        ShowAll->setMaximumSize(QSize(92, 33));
        ShowAll->setStyleSheet(QString::fromUtf8("font: 14pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));

        horizontalLayout_2->addWidget(ShowAll);

        ShowClear = new QPushButton(scope);
        ShowClear->setObjectName(QStringLiteral("ShowClear"));
        ShowClear->setMinimumSize(QSize(92, 33));
        ShowClear->setMaximumSize(QSize(92, 33));
        ShowClear->setStyleSheet(QString::fromUtf8("font: 14pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));

        horizontalLayout_2->addWidget(ShowClear);

        AutoRun = new QRadioButton(scope);
        AutoRun->setObjectName(QStringLiteral("AutoRun"));
        AutoRun->setMinimumSize(QSize(107, 28));
        AutoRun->setMaximumSize(QSize(107, 28));
        AutoRun->setAutoFillBackground(false);
        AutoRun->setStyleSheet(QString::fromUtf8("font: 14pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        AutoRun->setAutoExclusive(false);

        horizontalLayout_2->addWidget(AutoRun);

        ShowPoint = new QRadioButton(scope);
        ShowPoint->setObjectName(QStringLiteral("ShowPoint"));
        ShowPoint->setMinimumSize(QSize(107, 28));
        ShowPoint->setMaximumSize(QSize(107, 28));
        ShowPoint->setStyleSheet(QString::fromUtf8("font: 14pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        ShowPoint->setAutoExclusive(false);

        horizontalLayout_2->addWidget(ShowPoint);

        label_2 = new QLabel(scope);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setMinimumSize(QSize(20, 22));
        label_2->setMaximumSize(QSize(20, 22));

        horizontalLayout_2->addWidget(label_2);

        Xpoint = new QComboBox(scope);
        Xpoint->setObjectName(QStringLiteral("Xpoint"));
        Xpoint->setMinimumSize(QSize(80, 30));
        Xpoint->setMaximumSize(QSize(80, 30));
        Xpoint->setEditable(true);

        horizontalLayout_2->addWidget(Xpoint);

        XYval = new QLabel(scope);
        XYval->setObjectName(QStringLiteral("XYval"));
        XYval->setMinimumSize(QSize(191, 23));
        XYval->setMaximumSize(QSize(10000, 23));
        XYval->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_2->addWidget(XYval);


        verticalLayout_3->addLayout(horizontalLayout_2);


        gridLayout_2->addLayout(verticalLayout_3, 0, 0, 1, 1);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(1);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        panelItem = new PanelItem(scope);
        panelItem->setObjectName(QStringLiteral("panelItem"));
        panelItem->setMinimumSize(QSize(219, 563));
        panelItem->setMaximumSize(QSize(219, 563));
        panelItem->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        panelItem->setTitleHeight(20);
        QFont font1;
        font1.setFamily(QString::fromUtf8("\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200"));
        font1.setPointSize(12);
        panelItem->setTitleFont(font1);
        panelItem->setBorderRadius(8);
        panelItem->setBorderColor(QColor(17, 74, 195));
        panelItem->setProperty("isAlarm", QVariant(false));
        widget = new QWidget(panelItem);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(4, 22, 215, 539));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(2);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(2, 2, 2, 2);
        Scope_Ch1 = new ScopeCh(widget);
        Scope_Ch1->setObjectName(QStringLiteral("Scope_Ch1"));
        sizePolicy.setHeightForWidth(Scope_Ch1->sizePolicy().hasHeightForWidth());
        Scope_Ch1->setSizePolicy(sizePolicy);
        Scope_Ch1->setMinimumSize(QSize(205, 24));
        Scope_Ch1->setMaximumSize(QSize(205, 24));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200"));
        font2.setPointSize(12);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setWeight(50);
        Scope_Ch1->setFont(font2);
        Scope_Ch1->setMouseTracking(false);
        Scope_Ch1->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch1->setAutoFillBackground(true);
        widget_8 = new ScopeCh(Scope_Ch1);
        widget_8->setObjectName(QStringLiteral("widget_8"));
        widget_8->setGeometry(QRect(140, 24, 389, 24));
        widget_8->setFont(font2);
        widget_8->setMouseTracking(false);
        widget_8->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_8->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch1);

        Scope_Ch2 = new ScopeCh(widget);
        Scope_Ch2->setObjectName(QStringLiteral("Scope_Ch2"));
        sizePolicy.setHeightForWidth(Scope_Ch2->sizePolicy().hasHeightForWidth());
        Scope_Ch2->setSizePolicy(sizePolicy);
        Scope_Ch2->setMinimumSize(QSize(205, 24));
        Scope_Ch2->setMaximumSize(QSize(205, 24));
        Scope_Ch2->setFont(font2);
        Scope_Ch2->setMouseTracking(false);
        Scope_Ch2->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch2->setAutoFillBackground(true);
        widget_9 = new ScopeCh(Scope_Ch2);
        widget_9->setObjectName(QStringLiteral("widget_9"));
        widget_9->setGeometry(QRect(140, 24, 389, 24));
        widget_9->setFont(font2);
        widget_9->setMouseTracking(false);
        widget_9->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_9->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch2);

        Scope_Ch3 = new ScopeCh(widget);
        Scope_Ch3->setObjectName(QStringLiteral("Scope_Ch3"));
        sizePolicy.setHeightForWidth(Scope_Ch3->sizePolicy().hasHeightForWidth());
        Scope_Ch3->setSizePolicy(sizePolicy);
        Scope_Ch3->setMinimumSize(QSize(205, 24));
        Scope_Ch3->setMaximumSize(QSize(205, 24));
        Scope_Ch3->setFont(font2);
        Scope_Ch3->setMouseTracking(false);
        Scope_Ch3->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch3->setAutoFillBackground(true);
        widget_10 = new ScopeCh(Scope_Ch3);
        widget_10->setObjectName(QStringLiteral("widget_10"));
        widget_10->setGeometry(QRect(140, 24, 389, 24));
        widget_10->setFont(font2);
        widget_10->setMouseTracking(false);
        widget_10->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_10->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch3);

        Scope_Ch4 = new ScopeCh(widget);
        Scope_Ch4->setObjectName(QStringLiteral("Scope_Ch4"));
        sizePolicy.setHeightForWidth(Scope_Ch4->sizePolicy().hasHeightForWidth());
        Scope_Ch4->setSizePolicy(sizePolicy);
        Scope_Ch4->setMinimumSize(QSize(205, 24));
        Scope_Ch4->setMaximumSize(QSize(205, 24));
        Scope_Ch4->setFont(font2);
        Scope_Ch4->setMouseTracking(false);
        Scope_Ch4->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch4->setAutoFillBackground(true);
        widget_11 = new ScopeCh(Scope_Ch4);
        widget_11->setObjectName(QStringLiteral("widget_11"));
        widget_11->setGeometry(QRect(140, 24, 389, 24));
        widget_11->setFont(font2);
        widget_11->setMouseTracking(false);
        widget_11->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_11->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch4);

        Scope_Ch5 = new ScopeCh(widget);
        Scope_Ch5->setObjectName(QStringLiteral("Scope_Ch5"));
        sizePolicy.setHeightForWidth(Scope_Ch5->sizePolicy().hasHeightForWidth());
        Scope_Ch5->setSizePolicy(sizePolicy);
        Scope_Ch5->setMinimumSize(QSize(205, 24));
        Scope_Ch5->setMaximumSize(QSize(205, 24));
        Scope_Ch5->setFont(font2);
        Scope_Ch5->setMouseTracking(false);
        Scope_Ch5->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch5->setAutoFillBackground(true);
        widget_14 = new ScopeCh(Scope_Ch5);
        widget_14->setObjectName(QStringLiteral("widget_14"));
        widget_14->setGeometry(QRect(140, 24, 389, 24));
        widget_14->setFont(font2);
        widget_14->setMouseTracking(false);
        widget_14->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_14->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch5);

        line = new QFrame(widget);
        line->setObjectName(QStringLiteral("line"));
        line->setStyleSheet(QStringLiteral("color: rgb(17, 74, 195);"));
        line->setFrameShadow(QFrame::Plain);
        line->setLineWidth(3);
        line->setFrameShape(QFrame::HLine);

        verticalLayout->addWidget(line);

        Scope_Ch6 = new ScopeCh(widget);
        Scope_Ch6->setObjectName(QStringLiteral("Scope_Ch6"));
        sizePolicy.setHeightForWidth(Scope_Ch6->sizePolicy().hasHeightForWidth());
        Scope_Ch6->setSizePolicy(sizePolicy);
        Scope_Ch6->setMinimumSize(QSize(205, 24));
        Scope_Ch6->setMaximumSize(QSize(205, 24));
        Scope_Ch6->setFont(font2);
        Scope_Ch6->setMouseTracking(false);
        Scope_Ch6->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch6->setAutoFillBackground(true);
        widget_18 = new ScopeCh(Scope_Ch6);
        widget_18->setObjectName(QStringLiteral("widget_18"));
        widget_18->setGeometry(QRect(140, 24, 389, 24));
        widget_18->setFont(font2);
        widget_18->setMouseTracking(false);
        widget_18->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_18->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch6);

        Scope_Ch7 = new ScopeCh(widget);
        Scope_Ch7->setObjectName(QStringLiteral("Scope_Ch7"));
        sizePolicy.setHeightForWidth(Scope_Ch7->sizePolicy().hasHeightForWidth());
        Scope_Ch7->setSizePolicy(sizePolicy);
        Scope_Ch7->setMinimumSize(QSize(205, 24));
        Scope_Ch7->setMaximumSize(QSize(205, 24));
        Scope_Ch7->setFont(font2);
        Scope_Ch7->setMouseTracking(false);
        Scope_Ch7->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch7->setAutoFillBackground(true);
        widget_16 = new ScopeCh(Scope_Ch7);
        widget_16->setObjectName(QStringLiteral("widget_16"));
        widget_16->setGeometry(QRect(140, 24, 389, 24));
        widget_16->setFont(font2);
        widget_16->setMouseTracking(false);
        widget_16->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_16->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch7);

        Scope_Ch8 = new ScopeCh(widget);
        Scope_Ch8->setObjectName(QStringLiteral("Scope_Ch8"));
        sizePolicy.setHeightForWidth(Scope_Ch8->sizePolicy().hasHeightForWidth());
        Scope_Ch8->setSizePolicy(sizePolicy);
        Scope_Ch8->setMinimumSize(QSize(205, 24));
        Scope_Ch8->setMaximumSize(QSize(205, 24));
        Scope_Ch8->setFont(font2);
        Scope_Ch8->setMouseTracking(false);
        Scope_Ch8->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch8->setAutoFillBackground(true);
        widget_20 = new ScopeCh(Scope_Ch8);
        widget_20->setObjectName(QStringLiteral("widget_20"));
        widget_20->setGeometry(QRect(140, 24, 389, 24));
        widget_20->setFont(font2);
        widget_20->setMouseTracking(false);
        widget_20->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_20->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch8);

        Scope_Ch9 = new ScopeCh(widget);
        Scope_Ch9->setObjectName(QStringLiteral("Scope_Ch9"));
        sizePolicy.setHeightForWidth(Scope_Ch9->sizePolicy().hasHeightForWidth());
        Scope_Ch9->setSizePolicy(sizePolicy);
        Scope_Ch9->setMinimumSize(QSize(205, 24));
        Scope_Ch9->setMaximumSize(QSize(205, 24));
        Scope_Ch9->setFont(font2);
        Scope_Ch9->setMouseTracking(false);
        Scope_Ch9->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch9->setAutoFillBackground(true);
        widget_30 = new ScopeCh(Scope_Ch9);
        widget_30->setObjectName(QStringLiteral("widget_30"));
        widget_30->setGeometry(QRect(140, 24, 389, 24));
        widget_30->setFont(font2);
        widget_30->setMouseTracking(false);
        widget_30->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_30->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch9);

        Scope_Ch10 = new ScopeCh(widget);
        Scope_Ch10->setObjectName(QStringLiteral("Scope_Ch10"));
        sizePolicy.setHeightForWidth(Scope_Ch10->sizePolicy().hasHeightForWidth());
        Scope_Ch10->setSizePolicy(sizePolicy);
        Scope_Ch10->setMinimumSize(QSize(205, 24));
        Scope_Ch10->setMaximumSize(QSize(205, 24));
        Scope_Ch10->setFont(font2);
        Scope_Ch10->setMouseTracking(false);
        Scope_Ch10->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch10->setAutoFillBackground(true);
        widget_26 = new ScopeCh(Scope_Ch10);
        widget_26->setObjectName(QStringLiteral("widget_26"));
        widget_26->setGeometry(QRect(140, 24, 389, 24));
        widget_26->setFont(font2);
        widget_26->setMouseTracking(false);
        widget_26->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_26->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch10);

        line_2 = new QFrame(widget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setStyleSheet(QStringLiteral("color: rgb(17, 74, 195);"));
        line_2->setFrameShadow(QFrame::Plain);
        line_2->setLineWidth(3);
        line_2->setFrameShape(QFrame::HLine);

        verticalLayout->addWidget(line_2);

        Scope_Ch11 = new ScopeCh(widget);
        Scope_Ch11->setObjectName(QStringLiteral("Scope_Ch11"));
        sizePolicy.setHeightForWidth(Scope_Ch11->sizePolicy().hasHeightForWidth());
        Scope_Ch11->setSizePolicy(sizePolicy);
        Scope_Ch11->setMinimumSize(QSize(205, 24));
        Scope_Ch11->setMaximumSize(QSize(205, 24));
        Scope_Ch11->setFont(font2);
        Scope_Ch11->setMouseTracking(false);
        Scope_Ch11->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch11->setAutoFillBackground(true);
        widget_24 = new ScopeCh(Scope_Ch11);
        widget_24->setObjectName(QStringLiteral("widget_24"));
        widget_24->setGeometry(QRect(140, 24, 389, 24));
        widget_24->setFont(font2);
        widget_24->setMouseTracking(false);
        widget_24->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_24->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch11);

        Scope_Ch12 = new ScopeCh(widget);
        Scope_Ch12->setObjectName(QStringLiteral("Scope_Ch12"));
        sizePolicy.setHeightForWidth(Scope_Ch12->sizePolicy().hasHeightForWidth());
        Scope_Ch12->setSizePolicy(sizePolicy);
        Scope_Ch12->setMinimumSize(QSize(205, 24));
        Scope_Ch12->setMaximumSize(QSize(205, 24));
        Scope_Ch12->setFont(font2);
        Scope_Ch12->setMouseTracking(false);
        Scope_Ch12->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch12->setAutoFillBackground(true);
        widget_28 = new ScopeCh(Scope_Ch12);
        widget_28->setObjectName(QStringLiteral("widget_28"));
        widget_28->setGeometry(QRect(140, 24, 389, 24));
        widget_28->setFont(font2);
        widget_28->setMouseTracking(false);
        widget_28->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_28->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch12);

        Scope_Ch13 = new ScopeCh(widget);
        Scope_Ch13->setObjectName(QStringLiteral("Scope_Ch13"));
        sizePolicy.setHeightForWidth(Scope_Ch13->sizePolicy().hasHeightForWidth());
        Scope_Ch13->setSizePolicy(sizePolicy);
        Scope_Ch13->setMinimumSize(QSize(205, 24));
        Scope_Ch13->setMaximumSize(QSize(205, 24));
        Scope_Ch13->setFont(font2);
        Scope_Ch13->setMouseTracking(false);
        Scope_Ch13->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch13->setAutoFillBackground(true);
        widget_38 = new ScopeCh(Scope_Ch13);
        widget_38->setObjectName(QStringLiteral("widget_38"));
        widget_38->setGeometry(QRect(140, 24, 389, 24));
        widget_38->setFont(font2);
        widget_38->setMouseTracking(false);
        widget_38->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_38->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch13);

        Scope_Ch14 = new ScopeCh(widget);
        Scope_Ch14->setObjectName(QStringLiteral("Scope_Ch14"));
        sizePolicy.setHeightForWidth(Scope_Ch14->sizePolicy().hasHeightForWidth());
        Scope_Ch14->setSizePolicy(sizePolicy);
        Scope_Ch14->setMinimumSize(QSize(205, 24));
        Scope_Ch14->setMaximumSize(QSize(205, 24));
        Scope_Ch14->setFont(font2);
        Scope_Ch14->setMouseTracking(false);
        Scope_Ch14->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch14->setAutoFillBackground(true);
        widget_34 = new ScopeCh(Scope_Ch14);
        widget_34->setObjectName(QStringLiteral("widget_34"));
        widget_34->setGeometry(QRect(140, 24, 389, 24));
        widget_34->setFont(font2);
        widget_34->setMouseTracking(false);
        widget_34->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_34->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch14);

        Scope_Ch15 = new ScopeCh(widget);
        Scope_Ch15->setObjectName(QStringLiteral("Scope_Ch15"));
        sizePolicy.setHeightForWidth(Scope_Ch15->sizePolicy().hasHeightForWidth());
        Scope_Ch15->setSizePolicy(sizePolicy);
        Scope_Ch15->setMinimumSize(QSize(205, 24));
        Scope_Ch15->setMaximumSize(QSize(205, 24));
        Scope_Ch15->setFont(font2);
        Scope_Ch15->setMouseTracking(false);
        Scope_Ch15->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch15->setAutoFillBackground(true);
        widget_32 = new ScopeCh(Scope_Ch15);
        widget_32->setObjectName(QStringLiteral("widget_32"));
        widget_32->setGeometry(QRect(140, 24, 389, 24));
        widget_32->setFont(font2);
        widget_32->setMouseTracking(false);
        widget_32->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_32->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch15);

        line_3 = new QFrame(widget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setStyleSheet(QStringLiteral("color: rgb(17, 74, 195);"));
        line_3->setFrameShadow(QFrame::Plain);
        line_3->setLineWidth(3);
        line_3->setFrameShape(QFrame::HLine);

        verticalLayout->addWidget(line_3);

        Scope_Ch16 = new ScopeCh(widget);
        Scope_Ch16->setObjectName(QStringLiteral("Scope_Ch16"));
        sizePolicy.setHeightForWidth(Scope_Ch16->sizePolicy().hasHeightForWidth());
        Scope_Ch16->setSizePolicy(sizePolicy);
        Scope_Ch16->setMinimumSize(QSize(205, 24));
        Scope_Ch16->setMaximumSize(QSize(205, 24));
        Scope_Ch16->setFont(font2);
        Scope_Ch16->setMouseTracking(false);
        Scope_Ch16->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch16->setAutoFillBackground(true);
        widget_36 = new ScopeCh(Scope_Ch16);
        widget_36->setObjectName(QStringLiteral("widget_36"));
        widget_36->setGeometry(QRect(140, 24, 389, 24));
        widget_36->setFont(font2);
        widget_36->setMouseTracking(false);
        widget_36->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_36->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch16);

        Scope_Ch17 = new ScopeCh(widget);
        Scope_Ch17->setObjectName(QStringLiteral("Scope_Ch17"));
        sizePolicy.setHeightForWidth(Scope_Ch17->sizePolicy().hasHeightForWidth());
        Scope_Ch17->setSizePolicy(sizePolicy);
        Scope_Ch17->setMinimumSize(QSize(205, 24));
        Scope_Ch17->setMaximumSize(QSize(205, 24));
        Scope_Ch17->setFont(font2);
        Scope_Ch17->setMouseTracking(false);
        Scope_Ch17->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch17->setAutoFillBackground(true);
        widget_50 = new ScopeCh(Scope_Ch17);
        widget_50->setObjectName(QStringLiteral("widget_50"));
        widget_50->setGeometry(QRect(140, 24, 389, 24));
        widget_50->setFont(font2);
        widget_50->setMouseTracking(false);
        widget_50->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_50->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch17);

        Scope_Ch18 = new ScopeCh(widget);
        Scope_Ch18->setObjectName(QStringLiteral("Scope_Ch18"));
        sizePolicy.setHeightForWidth(Scope_Ch18->sizePolicy().hasHeightForWidth());
        Scope_Ch18->setSizePolicy(sizePolicy);
        Scope_Ch18->setMinimumSize(QSize(205, 24));
        Scope_Ch18->setMaximumSize(QSize(205, 24));
        Scope_Ch18->setFont(font2);
        Scope_Ch18->setMouseTracking(false);
        Scope_Ch18->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch18->setAutoFillBackground(true);
        widget_45 = new ScopeCh(Scope_Ch18);
        widget_45->setObjectName(QStringLiteral("widget_45"));
        widget_45->setGeometry(QRect(140, 24, 389, 24));
        widget_45->setFont(font2);
        widget_45->setMouseTracking(false);
        widget_45->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_45->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch18);

        Scope_Ch19 = new ScopeCh(widget);
        Scope_Ch19->setObjectName(QStringLiteral("Scope_Ch19"));
        sizePolicy.setHeightForWidth(Scope_Ch19->sizePolicy().hasHeightForWidth());
        Scope_Ch19->setSizePolicy(sizePolicy);
        Scope_Ch19->setMinimumSize(QSize(205, 24));
        Scope_Ch19->setMaximumSize(QSize(205, 24));
        Scope_Ch19->setFont(font2);
        Scope_Ch19->setMouseTracking(false);
        Scope_Ch19->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch19->setAutoFillBackground(true);
        widget_41 = new ScopeCh(Scope_Ch19);
        widget_41->setObjectName(QStringLiteral("widget_41"));
        widget_41->setGeometry(QRect(140, 24, 389, 24));
        widget_41->setFont(font2);
        widget_41->setMouseTracking(false);
        widget_41->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_41->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch19);

        Scope_Ch20 = new ScopeCh(widget);
        Scope_Ch20->setObjectName(QStringLiteral("Scope_Ch20"));
        sizePolicy.setHeightForWidth(Scope_Ch20->sizePolicy().hasHeightForWidth());
        Scope_Ch20->setSizePolicy(sizePolicy);
        Scope_Ch20->setMinimumSize(QSize(205, 24));
        Scope_Ch20->setMaximumSize(QSize(205, 24));
        Scope_Ch20->setFont(font2);
        Scope_Ch20->setMouseTracking(false);
        Scope_Ch20->setContextMenuPolicy(Qt::DefaultContextMenu);
        Scope_Ch20->setAutoFillBackground(true);
        widget_48 = new ScopeCh(Scope_Ch20);
        widget_48->setObjectName(QStringLiteral("widget_48"));
        widget_48->setGeometry(QRect(140, 24, 389, 24));
        widget_48->setFont(font2);
        widget_48->setMouseTracking(false);
        widget_48->setContextMenuPolicy(Qt::DefaultContextMenu);
        widget_48->setAutoFillBackground(true);

        verticalLayout->addWidget(Scope_Ch20);


        verticalLayout_2->addWidget(panelItem);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        AutoDetect = new QPushButton(scope);
        AutoDetect->setObjectName(QStringLiteral("AutoDetect"));
        AutoDetect->setMinimumSize(QSize(80, 33));
        AutoDetect->setMaximumSize(QSize(80, 33));
        AutoDetect->setStyleSheet(QString::fromUtf8("font: 14pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));

        horizontalLayout->addWidget(AutoDetect);

        label = new QLabel(scope);
        label->setObjectName(QStringLiteral("label"));
        label->setMinimumSize(QSize(95, 23));
        label->setMaximumSize(QSize(95, 23));

        horizontalLayout->addWidget(label);


        verticalLayout_2->addLayout(horizontalLayout);


        gridLayout->addLayout(verticalLayout_2, 0, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 36, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 1, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 1, 1, 1);


        retranslateUi(scope);

        QMetaObject::connectSlotsByName(scope);
    } // setupUi

    void retranslateUi(QWidget *scope)
    {
        scope->setWindowTitle(QApplication::translate("scope", "Form", Q_NULLPTR));
        ScopeShow->setTextOff(QApplication::translate("scope", "\346\211\223\345\274\200", Q_NULLPTR));
        ScopeShow->setTextOn(QApplication::translate("scope", "\345\205\263\351\227\255", Q_NULLPTR));
        ShowAll->setText(QApplication::translate("scope", "\345\233\276\345\203\217\345\205\250\346\230\276", Q_NULLPTR));
        ShowClear->setText(QApplication::translate("scope", "\346\270\205\347\251\272\346\263\242\345\275\242", Q_NULLPTR));
        AutoRun->setText(QApplication::translate("scope", "\350\207\252\345\212\250\346\273\232\345\212\250", Q_NULLPTR));
        ShowPoint->setText(QApplication::translate("scope", "\346\230\276\347\244\272\346\270\270\346\240\207", Q_NULLPTR));
        label_2->setText(QApplication::translate("scope", "X:", Q_NULLPTR));
        Xpoint->clear();
        Xpoint->insertItems(0, QStringList()
         << QApplication::translate("scope", "10", Q_NULLPTR)
         << QApplication::translate("scope", "50", Q_NULLPTR)
         << QApplication::translate("scope", "100", Q_NULLPTR)
         << QApplication::translate("scope", "500", Q_NULLPTR)
         << QApplication::translate("scope", "1000", Q_NULLPTR)
         << QApplication::translate("scope", "3000", Q_NULLPTR)
         << QApplication::translate("scope", "5000", Q_NULLPTR)
         << QApplication::translate("scope", "10000", Q_NULLPTR)
         << QApplication::translate("scope", "30000", Q_NULLPTR)
         << QApplication::translate("scope", "50000", Q_NULLPTR)
        );
        XYval->setText(QApplication::translate("scope", "(x,y)", Q_NULLPTR));
        panelItem->setTitleText(QApplication::translate("scope", "\346\263\242\345\275\242\346\230\276\347\244\272", Q_NULLPTR));
        AutoDetect->setText(QApplication::translate("scope", "Auto", Q_NULLPTR));
        label->setText(QApplication::translate("scope", "FPS: 1234 ", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class scope: public Ui_scope {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCOPE_H
