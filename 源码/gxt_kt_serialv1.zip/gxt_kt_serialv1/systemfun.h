﻿#ifndef SYSTEMFUN_H
#define SYSTEMFUN_H

#include <QObject>
#include <QWidget>
#include "ui_widget.h"
#include "basicinfo.h"


void System_Init(void);


class SystemFun
{
public:
    SystemFun();
};

#endif // SYSTEMFUN_H
