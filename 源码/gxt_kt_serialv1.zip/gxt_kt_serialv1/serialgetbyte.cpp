﻿#include "serialgetbyte.h"
#include "datastorage.h"
#include "scope.h"
#include "datastorage.h"
#include "mywidget.h"
#include "widget.h"
#include "string.h"
#if _MSC_VER >= 1600
#pragma execution_character_set("utf-8")
#endif

FlyBaseInfo gxtfly;
ScopeData scoData;
static uchar SerialBuf[256]={0};
int ChFps[0xff+1]={0};//因为我们最多需要0xff，所以多分配一个
int SerialGetOneByte(uchar byte)
{
    //qDebug() << "id======:" << QThread::currentThreadId();
    static uchar getSta;
    static uchar getNum=0;
    static uchar get_i=0;
    uchar check_1=0,check_2=0;
    if(getSta==0)//还没开始接收
    {
        if(byte == startByte) //帧头
        {getSta=1;SerialBuf[get_i++]=byte;/*qDebug("get帧头");*/}//获取帧头
        else {getSta=0;get_i=0;get_i=0;/*qDebug("no-zhentou");*/}
    }
    else if(getSta==1) //接收第二个数据-目标地址
    {
         SerialBuf[get_i++]=byte;
         getSta=2;
         //qDebug("get地址");
    }
    else if(getSta==2)//接收第三个数据-功能码
    {
        SerialBuf[get_i++]=byte;
        getSta=3;
        //qDebug("get-fun");
    }
    else if(getSta==3)//接收数据长度
    {
        SerialBuf[get_i++]=byte;
        getSta=4;
        getNum=byte+2;//数据长度 +2是为了拿下数据校验
        if(getNum>60){qDebug("数据超长!");getSta=0;getNum=0;get_i=0;return 0;}
        //qDebug("get数据长度");
    }
    else if(getSta==4)//开始接收数据
    {
        SerialBuf[get_i++]=byte;
        getNum--;
        if(getNum==0)//接收完成
        {getSta=0;getNum=0;

//            for(u8 i=0; i<len-2; i++)
//              {
//                  check_sum1 += *(data+i);
//                  check_sum2 += check_sum1;
//              }
//              if((check_sum1 != *(data+len-2)) || (check_sum2 != *(data+len-1)))	//判断sum校验
//              {
//              return;
//              }
            for(uchar i=0;i<get_i-2;i++)
            {
                check_1+=*(SerialBuf+i);
                check_2+=check_1;
            }
            if((check_1 != *(SerialBuf+get_i-2)) || (check_2 != *(SerialBuf+get_i-1)))	//判断sum校验
            {
                get_i=0;getSta=0;getNum=0;//清空状态，准备下次接收
                qDebug("校验出错");
                return 0;//
            }
            SerialFunction(SerialBuf,get_i);//已经通过校验，把数据传给处理函数
            BasicInfo::AddAgreeNum(get_i);//添加已经通过校验的数据
            int tem_i=get_i;//先把变量存起来，因为后面要returnget_i
            get_i=0;//清空计数
            //qDebug("complete");//完成一次接收
            return tem_i;
        }
        return 0;
    }
    return 0;
}


void SerialFunction(uchar *buf,uchar len)//第一个数是*buf+4
{
    int i=0;
    int sendNum;
    float floatNum;
    int chnum;

    if(buf[2]==0xF1 && (buf[3]%4==0))//示波器通道--F1
    {ChFps[0xF1]++;

        int ss=buf[3]/4;
        if(ss>5) ss=5;
        for(i=4;i<=ss*4;i+=4)
        {
            chnum=(int)(i/4);
            if(chtype[chnum]==0)//int
            {
                sendNum=(buf[i+3]<<24)|(buf[i+2]<<16)|(buf[i+1]<<8)|(buf[i]);
                AddDataFromSerial((int)(i/4),(int)sendNum);//添加数据
                scoData.scoIntData[chnum]=sendNum;
            }else if(chtype[chnum]==1){//float
                floatNum=*((float*)(buf+i));
                AddDataFromSerial((int)(i/4),(float)floatNum);//添加数据
                scoData.scofloData[chnum]=floatNum;
            }
        }
    }else if(buf[2]==0xF1 && ((buf[3]-1)%4==0))//cpp版本自适应
    {ChFps[0xF1]++;
        uint8_t recN=buf[4]>>5;//获取数据个数

        for(int reci=1;reci<=recN;reci++)
        {
            if(buf[4]&(1<<(5-reci))){//float
                //qDebug()<<reci<<"float";
                floatNum=*((float*)(buf+4*reci+1));
                AddDataFromSerial(reci,(float)floatNum);//添加数据
                scoData.scofloData[reci]=floatNum;
                chtype[reci]=1;
            }
            else {//int
                //qDebug()<<reci<<"int";
                sendNum=(buf[4*reci+4]<<24)|(buf[4*reci+3]<<16)|(buf[4*reci+2]<<8)|(buf[4*reci+1]);
                AddDataFromSerial(reci,(int)sendNum);//添加数据
                scoData.scoIntData[reci]=sendNum;
                chtype[reci]=0;
            }
        }
    }else if(buf[2]==0xF2 && (buf[3]%4==0))//示波器通道--F2
    {ChFps[0xF2]++;
       // qDebug("F2");
        int ss=buf[3]/4;
        if(ss>5) ss=5;
        for(i=4;i<=ss*4;i+=4)
        {
            chnum=(int)(i/4)+5;
            if(chtype[chnum]==0)//int
            {
                sendNum=(buf[i+3]<<24)|(buf[i+2]<<16)|(buf[i+1]<<8)|(buf[i]);
                AddDataFromSerial((int)(i/4)+5,(int)sendNum);//添加数据
                scoData.scoIntData[chnum]=sendNum;
            }else if(chtype[chnum]==1){//float
                floatNum=*((float*)(buf+i));
                AddDataFromSerial((int)(i/4)+5,(float)floatNum);//添加数据
                scoData.scoIntData[chnum]=floatNum;
            }
        }
    }else if(buf[2]==0xF2 && ((buf[3]-1)%4==0))//cpp版本自适应
    {ChFps[0xF2]++;
        uint8_t recN=buf[4]>>5;//获取数据个数

        for(int reci=1;reci<=recN;reci++)
        {
            if(buf[4]&(1<<(5-reci))){//float
               // qDebug()<<reci<<"float";
                floatNum=*((float*)(buf+4*reci+1));
                AddDataFromSerial(reci+5,(float)floatNum);//添加数据
                scoData.scofloData[reci+5]=floatNum;
                chtype[reci+5]=1;
            }
            else {//int
               // qDebug()<<reci<<"int";
                sendNum=(buf[4*reci+4]<<24)|(buf[4*reci+3]<<16)|(buf[4*reci+2]<<8)|(buf[4*reci+1]);
                AddDataFromSerial(reci+5,(int)sendNum);//添加数据
                scoData.scoIntData[reci+5]=sendNum;
                chtype[reci+5]=0;
            }
        }
    }else if(buf[2]==0xF3 && (buf[3]%4==0))//示波器通道--F3
    {ChFps[0xF3]++;
       // qDebug("F3");
        int ss=buf[3]/4;
        if(ss>5) ss=5;
        for(i=4;i<=ss*4;i+=4)
        {
            chnum=(int)(i/4)+10;
            if(chtype[chnum]==0)//int
            {
                sendNum=(buf[i+3]<<24)|(buf[i+2]<<16)|(buf[i+1]<<8)|(buf[i]);
                AddDataFromSerial((int)(i/4)+10,(int)sendNum);//添加数据
                scoData.scoIntData[chnum]=sendNum;
            }else if(chtype[chnum]==1){//float
                floatNum=*((float*)(buf+i));
                AddDataFromSerial((int)(i/4)+10,(float)floatNum);//添加数据
                scoData.scoIntData[chnum]=floatNum;
            }
        }
    }else if(buf[2]==0xF3 && ((buf[3]-1)%4==0))//cpp版本自适应
    {ChFps[0xF3]++;
        uint8_t recN=buf[4]>>5;//获取数据个数

        for(int reci=1;reci<=recN;reci++)
        {
            if(buf[4]&(1<<(5-reci))){//float
               // qDebug()<<reci<<"float";
                floatNum=*((float*)(buf+4*reci+1));
                AddDataFromSerial(reci+10,(float)floatNum);//添加数据
                scoData.scofloData[reci+10]=floatNum;
                chtype[reci+10]=1;
            }
            else {//int
               // qDebug()<<reci<<"int";
                sendNum=(buf[4*reci+4]<<24)|(buf[4*reci+3]<<16)|(buf[4*reci+2]<<8)|(buf[4*reci+1]);
                AddDataFromSerial(reci+10,(int)sendNum);//添加数据
                scoData.scoIntData[reci+10]=sendNum;
                chtype[reci+10]=0;
            }
        }
    }else if(buf[2]==0xF4 && (buf[3]%4==0))//示波器通道--F4
    {ChFps[0xF4]++;
        //qDebug("F4");
        int ss=buf[3]/4;
        if(ss>5) ss=5;
        for(i=4;i<=ss*4;i+=4)
        {
            chnum=(int)(i/4)+15;
            if(chtype[chnum]==0)//int
            {
                sendNum=(buf[i+3]<<24)|(buf[i+2]<<16)|(buf[i+1]<<8)|(buf[i]);
                AddDataFromSerial((int)(i/4)+15,(int)sendNum);//添加数据
                scoData.scoIntData[chnum]=sendNum;
            }else if(chtype[chnum]==1){//float
                floatNum=*((float*)(buf+i));
                AddDataFromSerial((int)(i/4)+15,(float)floatNum);//添加数据
                scoData.scoIntData[chnum]=floatNum;
            }
        }
    }else if(buf[2]==0xF4 && ((buf[3]-1)%4==0))//cpp版本自适应
    {ChFps[0xF4]++;
        uint8_t recN=buf[4]>>5;//获取数据个数

        for(int reci=1;reci<=recN;reci++)
        {
            if(buf[4]&(1<<(5-reci))){//float
               // qDebug()<<reci<<"float";
                floatNum=*((float*)(buf+4*reci+1));
                AddDataFromSerial(reci+15,(float)floatNum);//添加数据
                scoData.scofloData[reci+15]=floatNum;
                chtype[reci+15]=1;
            }
            else {//int
               // qDebug()<<reci<<"int";
                sendNum=(buf[4*reci+4]<<24)|(buf[4*reci+3]<<16)|(buf[4*reci+2]<<8)|(buf[4*reci+1]);
                AddDataFromSerial(reci+15,(int)sendNum);//添加数据
                scoData.scoIntData[reci+15]=sendNum;
                chtype[reci+15]=0;
            }
        }
    }
    else if(buf[2]==EulerPoint)//欧拉角
    {ChFps[EulerPoint]++;

        gxtfly.degData1.Roll=(float)((buf[5]<<8)|buf[4])/100;//Roll
        gxtfly.degData1.Pitch=(float)((buf[7]<<8)|buf[6])/100;//Pitch
        gxtfly.degData1.Yaw=(float)((buf[9]<<8)|buf[8])/100;//Yaw
        if(my_ui->oulajiao->isChecked()==1)
        {
            my_ui->gaugerollpitch->setRollValue(gxtfly.degData1.Roll);//设置地平仪
            my_ui->gaugerollpitch->setDegValue( gxtfly.degData1.Pitch);//设置地平仪
            my_ui->gaugeyaw->setValue(gxtfly.degData1.Yaw);//设置指南针
            my_ui->stl3d->SetVal(gxtfly.degData1.Roll,gxtfly.degData1.Pitch,gxtfly.degData1.Yaw);//设置3d

            QString tem_str;
            tem_str.sprintf("%.2f",gxtfly.degData1.Roll);my_ui->Roll->setText(tem_str);
            tem_str.sprintf("%.2f",gxtfly.degData1.Pitch);my_ui->Pitch->setText(tem_str);
            tem_str.sprintf("%.2f",gxtfly.degData1.Yaw);my_ui->Yaw->setText(tem_str);
        }
    }else if(buf[2]==Quaternion)//四元数
    {ChFps[Quaternion]++;
        gxtfly.degData1.q0=(float)((int16_t)((buf[5]<<8)|buf[4]))/10000;
        gxtfly.degData1.q1=(float)((int16_t)((buf[7]<<8)|buf[6]))/10000;
        gxtfly.degData1.q2=(float)((int16_t)((buf[9]<<8)|buf[8]))/10000;
        gxtfly.degData1.q3=(float)((int16_t)((buf[11]<<8)|buf[10]))/10000;
        if(my_ui->siyuanshu->isChecked()==1)
        {
            my_ui->stl3d->SetVal2(gxtfly.degData1.q0,gxtfly.degData1.q1,gxtfly.degData1.q2,gxtfly.degData1.q3,
                                  &gxtfly.degData1.RollFromQua,&gxtfly.degData1.PitchFromQua,&gxtfly.degData1.YawFromQua);
            //qDebug()<<"val "<<temRoll<<temPitch<<temYaw;//由四元数算出的欧拉角
             my_ui->gaugerollpitch->setRollValue(gxtfly.degData1.RollFromQua);
             my_ui->gaugerollpitch->setDegValue(gxtfly.degData1.PitchFromQua);
             my_ui->gaugeyaw->setValue(gxtfly.degData1.YawFromQua);

            QString tem_str;
            tem_str.sprintf("%.2f",gxtfly.degData1.RollFromQua);my_ui->Roll->setText(tem_str);
            tem_str.sprintf("%.2f",gxtfly.degData1.PitchFromQua);my_ui->Pitch->setText(tem_str);
            tem_str.sprintf("%.2f",gxtfly.degData1.YawFromQua);my_ui->Yaw->setText(tem_str);
        }
    }else if(buf[2]==RemoteControl)//遥控器
    {ChFps[RemoteControl]++;
        for(i=1;i<=buf[3]/2;i++)
        {
            gxtfly.RC.ch[i]=((int16_t)((buf[5+2*i-2]<<8)|buf[4+2*i-2]));//写入相应通道值
           QProgressBar* qprogressbar=my_this->findChild<QProgressBar*>("rcCh"+QString::number(i));
            if(qprogressbar!=NULL){ qprogressbar->setValue(gxtfly.RC.ch[i]);qprogressbar->show();}
            // qDebug()<<gxtfly.RC.ch[i];
        }
    }else if(buf[2]==VoltageCurrent)//电压电流
    {ChFps[VoltageCurrent]++;
       gxtfly.volAndCur.voltage=(float)((buf[5]<<8)|buf[4])/100;
       gxtfly.volAndCur.current=(float)((buf[7]<<8)|buf[6])/100;
       //qDebug()<<gxtfly.volAndCur.voltage<<" "<<gxtfly.volAndCur.current;
       my_ui->Voltage->setText(QString("%1").arg(gxtfly.volAndCur.voltage));
       if(my_ui->voltage_sel->currentIndex()!=0)
       {
           float battery_val=(gxtfly.volAndCur.voltage/my_ui->voltage_sel->currentIndex()-3.7)/0.5;
           if(battery_val<0) battery_val=0;
           if(battery_val>1) battery_val=1;
           my_ui->battery->setValue(battery_val*100);
           //qDebug()<<battery_val;
       }
    }else if(buf[2]==ColorString)//带颜色的字符串
    {ChFps[ColorString]++;
        QTime current_time = QTime::currentTime();
        int hour = current_time.hour();        //当前的小时
        int minute = current_time.minute();    //当前的分
        int second = current_time.second();    //当前的秒
        int msec = current_time.msec();        //当前的毫秒
        QString time_str;
        time_str.sprintf("\nT%d:%02d:%02d/%03d<<",hour,minute,second,msec);

        my_ui->textEdit->moveCursor(QTextCursor::End);
        my_ui->textEdit->setTextColor(QColor(75, 105, 105));
        my_ui->textEdit->insertPlainText(time_str);

        my_ui->textEdit->setTextColor(QColor(0, 0, 0));
        QByteArray bytearr((char*)(buf+5),buf[3]-1);//由于第一个是颜色，所以从后面开始算
        //qDebug()<<buf[3]<<buf[4]<<buf[5]<<buf[6];
        if(buf[4]==gxtBLACK)  my_ui->textEdit->setTextColor(QColor(0, 0, 0));
        else if(buf[4]==gxtWHITE) my_ui->textEdit->setTextColor(QColor(255, 255, 255));
        else if(buf[4]==gxtRED) my_ui->textEdit->setTextColor(QColor(255, 0, 0));
        else if(buf[4]==gxtGREEN) my_ui->textEdit->setTextColor(QColor(0, 255, 0));
        else if(buf[4]==gxtBLUE) my_ui->textEdit->setTextColor(QColor(0, 0, 255));
        else if(buf[4]==gxtORANGE) my_ui->textEdit->setTextColor(QColor(255, 165, 0));
        else if(buf[4]==gxtYELLOW) my_ui->textEdit->setTextColor(QColor(255, 255, 0));
        else if(buf[4]==gxtCYAN) my_ui->textEdit->setTextColor(QColor(0, 255, 255));
        else if(buf[4]==gxtMagenta) my_ui->textEdit->setTextColor(QColor(255, 0, 255));

        QString sStr = QString::fromLocal8Bit( bytearr);
        my_ui->textEdit->insertPlainText(sStr);
    }
}

