#ifndef BASICINFO_H
#define BASICINFO_H

#include <QWidget>
//#include <widget.h>
#include "ui_widget.h"
#include <QFile>
#include <QFileInfo>
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QTime>
#include <QTimer>
#include <QProcess>
#include <QDir>


extern Ui::Widget *my_ui;

void ui_init(Ui::Widget *ui_ptr);


class BasicInfo :public QWidget
{
public:
    BasicInfo();
    static long long int SendCnt;
    static long long int RecCnt;
    static long long int AgreeCnt;
    static long long int RecCntTot;
    static void AddSendNum(int n);
    static void AddRecNum(int n);
    static long GetRecNum(void);
    static void AddAgreeNum(int n);
    static long GetAgreeNum(void);
    static void ClearRecSendNum(void);
    static void RecSendNumShow(void);
    static void RecNumShow(void);
    static void SendNumShow(void);
    //void RecSendNumShow(void);
};
#endif // BASICINFO_H
