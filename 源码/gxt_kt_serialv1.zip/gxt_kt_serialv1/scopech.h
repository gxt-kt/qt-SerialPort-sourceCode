﻿#ifndef SCOPECH_H
#define SCOPECH_H

#include <QWidget>
#include <QMouseEvent>
#include "scoperightbtn.h"
namespace Ui {
class ScopeCh;
}
void flush_test(void);
class ScopeCh : public QWidget
{
    Q_OBJECT

public:
    explicit ScopeCh(QWidget *parent = nullptr);
    ~ScopeCh();
    void show_menu(void);
private:
    Ui::ScopeCh *ui;
protected:
    void mousePressEvent(QMouseEvent *event);

signals:
    void ChooseN(int n);
    void SendAdd(ScopeCh *scope);
public:
    //QString colString;
    bool getIfChecked(void);//判断是否选中
    void setChecked(bool i);//设置选中状态
    QColor getChCol(void);//获取颜色
    void setChCol(QColor col);//获取颜色
    void setChNText(QString str);//获取颜色
    //uint8_t getLineWidth(void);//设置线宽 ---移到scope实现
    //uint8_t //设置点的类型
    void setLabelText(QString str);
    void setLabelText(float num);
    void setLabelText(int num);
    void setFpsVal(int fps);
    int getFpsVal(void);

    scopeRightBtn *MenuChoose;
};

#endif // SCOPECH_H
