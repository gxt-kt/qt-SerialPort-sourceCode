#include "detailinfo.h"
#include "ui_detailinfo.h"
#include "serialgetbyte.h"

bool DetailInfo::OpenSta=0;
DetailInfo *DetailPtr=nullptr;
DetailInfo::DetailInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DetailInfo)
{
    ui->setupUi(this);
    setAttribute(Qt::WA_QuitOnClose,false);
    this->setWindowTitle("DetailInfo");
    ui->treeWidget->setHeaderLabel("详细信息");
    initQTree();
    flushTim=new QTimer;
    flushTim->setInterval(20);//50hz刷新
    connect(flushTim,&QTimer::timeout,this,&DetailInfo::flushTimOut);
    flushTim->start();
}

DetailInfo::~DetailInfo()
{
    delete ui;
}

void DetailInfo::initQTree()
{
//    itemId=new QTreeWidgetItem(ui->treeWidget);
//    itemId->setText(0,"0x00");
//    QTreeWidgetItem* itemId2=new QTreeWidgetItem(ui->treeWidget);
//    itemId2->setText(0,"0x02");
//    QTreeWidgetItem *itemId0x00=new QTreeWidgetItem(itemId);
//    itemId0x00->setText(0,"acc1");
//    itemId0x00->setText(1,"acc2");
}

void DetailInfo::ItemSetVal(uint8_t ch,int val)
{
    QString string;
    string.sprintf("0x%02X",ch);//转成0x**的16进制形式
    QList<QTreeWidgetItem *> findItem= ui->treeWidget->findItems(string,0);//默认第零列寻找
    if(findItem.size()!=0)//找到对应的
    {
        //findItem[0]->setText(0,"0x05");
        qDebug(".....");
    }
}

bool showFpsEn=0;//是否在下次定时器刷新时显示帧率
void DetailInfo::flushTimOut()//50hz刷新数据
{
    /************1s设置显示一次帧率***************/
    static QTime time1s(QTime::currentTime());
    double key = time1s.elapsed(); // 开始到现在的时间，单位秒
    static double lastFpsKey;
    if (key-lastFpsKey > 1000) // 每1秒执行一次
    {
        lastFpsKey=key;
        showFpsEn=1;//可以在下次刷新时显示帧率了
    }
    //qDebug()<<time1s.elapsed();

    uint8_t ch;
    QString string;
    QList<QTreeWidgetItem *> findItem;
    /*////////////////////////*/
    ch=0xf1;//示波器通道1
    string.sprintf("0x%02X",ch);//转成0x**的16进制形式
    findItem= ui->treeWidget->findItems(string,0);//默认第零列寻找
    if(findItem.size()!=0)//找到对应的
    {
        for(int chi=1;chi<=5;chi++)
        {
            if(chtype[chi]==0)findItem[0]->child(chi-1)->setText(1,QString("%1").arg(scoData.scoIntData[chi]));
            else findItem[0]->child(chi-1)->setText(1,QString("%1").arg(scoData.scofloData[chi]));
            if(showFpsEn)findItem[0]->child(chi-1)->setText(2,QString("%1").arg(ChFps[0xf1]));
        }
    }
    /*////////////////////////*/
    ch=0xf2;//示波器通道2
    string.sprintf("0x%02X",ch);//转成0x**的16进制形式
    findItem= ui->treeWidget->findItems(string,0);//默认第零列寻找
    if(findItem.size()!=0)//找到对应的
    {
        for(int chi=6;chi<=10;chi++)
        {
            if(chtype[chi]==0)findItem[0]->child(chi-6)->setText(1,QString("%1").arg(scoData.scoIntData[chi]));
            else findItem[0]->child(chi-6)->setText(1,QString("%1").arg(scoData.scofloData[chi]));
            if(showFpsEn)findItem[0]->child(chi-6)->setText(2,QString("%1").arg(ChFps[0xf2]));
        }
    }
    /*////////////////////////*/
    ch=0xf3;//示波器通道3
    string.sprintf("0x%02X",ch);//转成0x**的16进制形式
    findItem= ui->treeWidget->findItems(string,0);//默认第零列寻找
    if(findItem.size()!=0)//找到对应的
    {
        for(int chi=11;chi<=15;chi++)
        {
            if(chtype[chi]==0)findItem[0]->child(chi-11)->setText(1,QString("%1").arg(scoData.scoIntData[chi]));
            else findItem[0]->child(chi-11)->setText(1,QString("%1").arg(scoData.scofloData[chi]));
            if(showFpsEn)findItem[0]->child(chi-11)->setText(2,QString("%1").arg(ChFps[0xf3]));
        }
    }
    /*////////////////////////*/
    ch=0xf4;//示波器通道4
    string.sprintf("0x%02X",ch);//转成0x**的16进制形式
    findItem= ui->treeWidget->findItems(string,0);//默认第零列寻找
    if(findItem.size()!=0)//找到对应的
    {
        for(int chi=16;chi<=20;chi++)
        {
            if(chtype[chi]==0)findItem[0]->child(chi-16)->setText(1,QString("%1").arg(scoData.scoIntData[chi]));
            else findItem[0]->child(chi-16)->setText(1,QString("%1").arg(scoData.scofloData[chi]));
            if(showFpsEn)findItem[0]->child(chi-16)->setText(2,QString("%1").arg(ChFps[0xf4]));
        }
    }
    /*////////////////////////*/
    ch=EulerPoint;//欧拉角
    string.sprintf("0x%02X",ch);//转成0x**的16进制形式
    findItem= ui->treeWidget->findItems(string,0);//默认第零列寻找
    if(findItem.size()!=0)//找到对应的
    {
        findItem[0]->child(0)->setText(1,QString("%1").arg(gxtfly.degData1.Roll));
        findItem[0]->child(1)->setText(1,QString("%1").arg(gxtfly.degData1.Pitch));
        findItem[0]->child(2)->setText(1,QString("%1").arg(gxtfly.degData1.Yaw));
        if(showFpsEn){
            findItem[0]->child(0)->setText(2,QString("%1").arg(ChFps[EulerPoint]));
            findItem[0]->child(1)->setText(2,QString("%1").arg(ChFps[EulerPoint]));
            findItem[0]->child(2)->setText(2,QString("%1").arg(ChFps[EulerPoint]));
        }
    }

    /*////////////////////////*/
    ch=Quaternion;//四元数
    string.sprintf("0x%02X",ch);//转成0x**的16进制形式
    findItem= ui->treeWidget->findItems(string,0);//默认第零列寻找
    if(findItem.size()!=0)//找到对应的
    {
        findItem[0]->child(0)->setText(1,QString("%1").arg(gxtfly.degData1.q0));
        findItem[0]->child(1)->setText(1,QString("%1").arg(gxtfly.degData1.q1));
        findItem[0]->child(2)->setText(1,QString("%1").arg(gxtfly.degData1.q2));
        findItem[0]->child(3)->setText(1,QString("%1").arg(gxtfly.degData1.q3));
        if(showFpsEn){
            findItem[0]->child(0)->setText(2,QString("%1").arg(ChFps[Quaternion]));
            findItem[0]->child(1)->setText(2,QString("%1").arg(ChFps[Quaternion]));
            findItem[0]->child(2)->setText(2,QString("%1").arg(ChFps[Quaternion]));
            findItem[0]->child(3)->setText(2,QString("%1").arg(ChFps[Quaternion]));
        }
    }
    /*////////////////////////*/
    ch=RemoteControl;//遥控器数值
    string.sprintf("0x%02X",ch);//转成0x**的16进制形式
    findItem= ui->treeWidget->findItems(string,0);//默认第零列寻找
    if(findItem.size()!=0)//找到对应的
    {
        for(int chi=0;chi<=11;chi++)
        findItem[0]->child(chi)->setText(1,QString("%1").arg(gxtfly.RC.ch[chi+1]));
        if(showFpsEn){
            for(int chi=0;chi<=11;chi++)findItem[0]->child(chi)->setText(2,QString("%1").arg(ChFps[RemoteControl]));
        }
    }
    /*////////////////////////*/
    ch=VoltageCurrent;//电压电流
    string.sprintf("0x%02X",ch);//转成0x**的16进制形式
    findItem= ui->treeWidget->findItems(string,0);//默认第零列寻找
    if(findItem.size()!=0)//找到对应的
    {
        findItem[0]->child(0)->setText(1,QString("%1").arg(gxtfly.volAndCur.voltage));
        findItem[0]->child(1)->setText(1,QString("%1").arg(gxtfly.volAndCur.current));
        if(showFpsEn){
            for(int chi=0;chi<findItem[0]->childCount();chi++)findItem[0]->child(chi)->setText(2,QString("%1").arg(ChFps[VoltageCurrent]));
        }
    }

    /*进行相应处理*/
    if(showFpsEn==1)//显示完了
    {
        for(int chfpsi=0;chfpsi<=0xff;chfpsi++)//清空数据
        {ChFps[chfpsi]=0;}
        showFpsEn=0;//清空标志位
    }
    //qDebug()<<"end"<<time1s.elapsed();
}
