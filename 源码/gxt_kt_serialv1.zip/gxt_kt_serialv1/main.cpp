#include "widget.h"
#include <QtWidgets/QApplication>
#include "GuiThreadRun.hpp"
#include <QApplication>
#include <GL/glut.h>
#include "config.h"
#include <qregexp.h>
//#include <assimp/Importer.hpp>


int main(int argc, char *argv[])
{
//    qreal  cx = GetSystemMetrics(SM_CXSCREEN);
//    qreal scale = cx / 960;
    // qputenv("QT_SCALE_FACTOR", QString::number(scale).toLatin1());
    //qputenv("QT_SCALE_FACTOR", "2.0");
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    magnifyStr=Config().Get("System","magnify").value<QString>();
    QRegExp rx("\\d+");
    QString d;
    int data_d;
    rx.indexIn(magnifyStr,0);
    d = rx.cap(0);
    data_d = d.toInt();
    qDebug()<<data_d<<endl;

    QString string;
    string.sprintf("%.2f",(float)data_d/100);

    if(data_d>20) {qputenv("QT_SCALE_FACTOR",string.toLatin1());qDebug()<<string.toLatin1();}
    else qputenv("QT_SCALE_FACTOR","1.0");
    //qputenv("QT_SCALE_FACTOR","1.0");

    //qputenv("QT_SCALE_FACTOR","0.75");

    SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS);
    QApplication a(argc, argv);
    glutInit(&argc, argv);
    Widget w;
    w.setWindowIcon(QIcon(":/stlfile/ico.ico"));
    w.show();
    a.connect(&a,SIGNAL(lastWindowClosed()),&a,SLOT(quit()));
    //Assimp::Importer importer;
    return a.exec();
}
