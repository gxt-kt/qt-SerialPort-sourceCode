/********************************************************************************
** Form generated from reading UI file 'scoperightbtn.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCOPERIGHTBTN_H
#define UI_SCOPERIGHTBTN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>
#include "colorcombobox.h"

QT_BEGIN_NAMESPACE

class Ui_scopeRightBtn
{
public:
    QLabel *label;
    QFrame *line_2;
    QLabel *label_2;
    QComboBox *Numintfloat;
    QComboBox *comboBox_2;
    QFrame *line_3;
    QComboBox *comboBox_3;
    ColorComboBox *colorChoose;
    QPushButton *Ensure;
    QFrame *line_4;
    QPushButton *Cancel;

    void setupUi(QWidget *scopeRightBtn)
    {
        if (scopeRightBtn->objectName().isEmpty())
            scopeRightBtn->setObjectName(QStringLiteral("scopeRightBtn"));
        scopeRightBtn->resize(180, 170);
        scopeRightBtn->setMinimumSize(QSize(180, 170));
        scopeRightBtn->setMaximumSize(QSize(180, 170));
        scopeRightBtn->setStyleSheet(QLatin1String("QMenu {\n"
"	color:black;\n"
"	background-color:white; \n"
"	border-radius:3px;\n"
"	padding:5px;\n"
"	margin:6px;\n"
"}\n"
"QMenu::item:text { \n"
"	padding-left:10px;\n"
"	padding-right:10px;\n"
"}\n"
"QMenu::item:selected{ \n"
"	color:#1aa3ff;\n"
"	background-color: #e5f5ff;\n"
"	border-radius:3px;\n"
"}\n"
"QMenu::separator{\n"
"	height:1px;\n"
"	background:#bbbbbb;\n"
"	margin:5px;\n"
"	margin-left:10px;\n"
"	margin-right:10px;\n"
"}"));
        label = new QLabel(scopeRightBtn);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 12, 83, 21));
        label->setMinimumSize(QSize(83, 21));
        label->setMaximumSize(QSize(83, 21));
        label->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        line_2 = new QFrame(scopeRightBtn);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setGeometry(QRect(10, 68, 161, 16));
        line_2->setStyleSheet(QStringLiteral("color: rgb(0, 0, 0);"));
        line_2->setFrameShadow(QFrame::Plain);
        line_2->setLineWidth(2);
        line_2->setFrameShape(QFrame::HLine);
        label_2 = new QLabel(scopeRightBtn);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 50, 83, 21));
        label_2->setMinimumSize(QSize(83, 21));
        label_2->setMaximumSize(QSize(83, 21));
        label_2->setStyleSheet(QString::fromUtf8("font: 12pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        Numintfloat = new QComboBox(scopeRightBtn);
        Numintfloat->setObjectName(QStringLiteral("Numintfloat"));
        Numintfloat->setGeometry(QRect(86, 46, 85, 25));
        Numintfloat->setMinimumSize(QSize(85, 25));
        Numintfloat->setMaximumSize(QSize(85, 25));
        Numintfloat->setStyleSheet(QString::fromUtf8("font: 13pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(198, 0, 99);"));
        comboBox_2 = new QComboBox(scopeRightBtn);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(86, 10, 85, 25));
        comboBox_2->setMinimumSize(QSize(85, 25));
        comboBox_2->setMaximumSize(QSize(85, 25));
        comboBox_2->setStyleSheet(QString::fromUtf8("font: 13pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";\n"
"color: rgb(41, 182, 33);"));
        comboBox_2->setEditable(true);
        comboBox_2->setMaxVisibleItems(30);
        line_3 = new QFrame(scopeRightBtn);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setGeometry(QRect(10, 34, 161, 16));
        line_3->setStyleSheet(QStringLiteral("color: rgb(0, 0, 0);"));
        line_3->setFrameShadow(QFrame::Plain);
        line_3->setLineWidth(2);
        line_3->setFrameShape(QFrame::HLine);
        comboBox_3 = new QComboBox(scopeRightBtn);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        comboBox_3->setGeometry(QRect(96, 82, 70, 25));
        comboBox_3->setMinimumSize(QSize(70, 25));
        comboBox_3->setMaximumSize(QSize(85, 25));
        comboBox_3->setStyleSheet(QString::fromUtf8("font: 13pt \"\346\261\211\344\273\252\345\270\205\347\272\277\344\275\223W\";"));
        colorChoose = new ColorComboBox(scopeRightBtn);
        colorChoose->setObjectName(QStringLiteral("colorChoose"));
        colorChoose->setGeometry(QRect(12, 82, 77, 25));
        colorChoose->setMinimumSize(QSize(70, 25));
        colorChoose->setMaximumSize(QSize(16777215, 25));
        colorChoose->setAutoFillBackground(true);
        colorChoose->setEditable(false);
        colorChoose->setMaxVisibleItems(25);
        colorChoose->setInsertPolicy(QComboBox::InsertAfterCurrent);
        colorChoose->setSizeAdjustPolicy(QComboBox::AdjustToContents);
        colorChoose->setIconSize(QSize(50, 16));
        colorChoose->setDuplicatesEnabled(false);
        colorChoose->setFrame(true);
        colorChoose->setShowColorName(false);
        Ensure = new QPushButton(scopeRightBtn);
        Ensure->setObjectName(QStringLiteral("Ensure"));
        Ensure->setGeometry(QRect(10, 116, 97, 43));
        Ensure->setStyleSheet(QString::fromUtf8("font: 14pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        line_4 = new QFrame(scopeRightBtn);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setGeometry(QRect(10, 104, 161, 16));
        line_4->setStyleSheet(QStringLiteral("color: rgb(0, 0, 0);"));
        line_4->setFrameShadow(QFrame::Plain);
        line_4->setLineWidth(2);
        line_4->setFrameShape(QFrame::HLine);
        Cancel = new QPushButton(scopeRightBtn);
        Cancel->setObjectName(QStringLiteral("Cancel"));
        Cancel->setGeometry(QRect(110, 116, 61, 43));
        Cancel->setStyleSheet(QString::fromUtf8("font: 14pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        line_3->raise();
        label->raise();
        line_2->raise();
        label_2->raise();
        Numintfloat->raise();
        comboBox_2->raise();
        comboBox_3->raise();
        colorChoose->raise();
        Ensure->raise();
        line_4->raise();
        Cancel->raise();

        retranslateUi(scopeRightBtn);

        Numintfloat->setCurrentIndex(1);
        comboBox_2->setCurrentIndex(0);
        comboBox_3->setCurrentIndex(1);
        colorChoose->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(scopeRightBtn);
    } // setupUi

    void retranslateUi(QWidget *scopeRightBtn)
    {
        scopeRightBtn->setWindowTitle(QApplication::translate("scopeRightBtn", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("scopeRightBtn", "\346\233\262\347\272\277\345\220\215\347\247\260", Q_NULLPTR));
        label_2->setText(QApplication::translate("scopeRightBtn", "\346\225\260\346\215\256\347\261\273\345\236\213", Q_NULLPTR));
        Numintfloat->clear();
        Numintfloat->insertItems(0, QStringList()
         << QApplication::translate("scopeRightBtn", "int", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "float", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "u8", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "s8", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "u16", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "s16", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "u32", Q_NULLPTR)
        );
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("scopeRightBtn", "Ch1", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "Ch2", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "Ch3", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "Ch4", Q_NULLPTR)
        );
        comboBox_3->clear();
        comboBox_3->insertItems(0, QStringList()
         << QApplication::translate("scopeRightBtn", "int", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "float", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "u8", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "s8", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "u16", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "s16", Q_NULLPTR)
         << QApplication::translate("scopeRightBtn", "u32", Q_NULLPTR)
        );
        colorChoose->setCurrentText(QApplication::translate("scopeRightBtn", "antiquewhite", Q_NULLPTR));
        Ensure->setText(QApplication::translate("scopeRightBtn", "\347\241\256\345\256\232", Q_NULLPTR));
        Cancel->setText(QApplication::translate("scopeRightBtn", "\345\217\226\346\266\210", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class scopeRightBtn: public Ui_scopeRightBtn {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCOPERIGHTBTN_H
