﻿#include "widget.h"
#include "ui_widget.h"

#include "QSerialPortInfo"
#include "QtSerialPort"
#include "QMessageBox"
#include "QByteArray"
#include "basicinfo.h"
#include "scope.h"
#include "systemfun.h"
#include "serialgetbyte.h"
#include "navbar.h"
#include <QtWidgets/QApplication>
#include "GuiThreadRun.hpp"
#include "navbuttongroup.h"
#include "datastorage.h"
#include "usb_listener.h"
#include "datastorage.h"
//extern BasicInfo basic_info;
#include "config.h"
#include "slider.h"
#include "ui_slider.h"
#include "detailinfo.h"
// 添加文件引用
#include <QMetaType>

#if _MSC_VER >= 1600
#pragma execution_character_set("utf-8")
#endif

QByteArray serialBuffer;
int maxLength=0;
int maxLength2=0;
int cntVs=0;
int cntVs2=0;
QTimer *rec_buf_flush;
usb_listener *m_usb_listener = Q_NULLPTR;
QTimer *serialTim=nullptr;
QSerialPort *Serialport;
Widget *my_this;
QTimer *recTextUpdata=nullptr;
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui_init(ui);
    my_this=this;
    //refreshDPI();
    m_usb_listener = new usb_listener;
    qApp->installNativeEventFilter(m_usb_listener);
    connect(m_usb_listener, &usb_listener::DevicePlugIn, [=](){
        //do something...
        ui->SerialNum->clear();
        QStringList serialNamePort;
        foreach(const QSerialPortInfo &info,QSerialPortInfo::availablePorts())
        {
            serialNamePort<<info.portName();
            qDebug()<<info.portName()<< info.description();
        }
        ui->SerialNum->addItems(serialNamePort);
    });
    m_usb_listener->EmitMySignal();     //手动触发一次

    Serialport = new QSerialPort(this);
    SerPort=Serialport;
    connect(ui->Btn_open, &SwitchButton::checkedChanged, this,&Widget::SlotTest);//打开串口信号槽

    //硬件连接
    connect(Serialport, static_cast<void (QSerialPort::*)(QSerialPort::SerialPortError)>(&QSerialPort::error),  this, &Widget::handleSerialError);


    recTextUpdata=new QTimer;
    recTextUpdata->setInterval(1000);//1s更新1次
    connect(recTextUpdata,&QTimer::timeout,[=](){
        static long lastAgreeNum;
        static long lastCntNum;
        if((BasicInfo::GetRecNum()-lastCntNum)==0) { //说明1s内没接收到数据
            QPalette qpa;
            qpa.setColor(QPalette::WindowText,Qt::red);
            ui->errPer->setPalette(qpa);
            ui->errPer->setText("None");
        }
        else//设置错误码率
        {float errPer=1-(float)(BasicInfo::GetAgreeNum()-lastAgreeNum)/(float)(BasicInfo::GetRecNum()-lastCntNum);
        QString str;str.sprintf("%.2f%",errPer*100);
        QPalette qpa;
        qDebug()<<errPer;
        if(errPer>0.3)qpa.setColor(QPalette::WindowText,Qt::red);
        else qpa.setColor(QPalette::WindowText,QColor(24, 143, 255));
        ui->errPer->setPalette(qpa);
        ui->errPer->setText(str);
        }
        lastAgreeNum=BasicInfo::GetAgreeNum();
        lastCntNum=BasicInfo::GetRecNum();
        //qDebug()<<BasicInfo::GetAgreeNum();
    });
    recTextUpdata->start();
#if 1
    ui->rec_buf->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);//始终显示进度条
    ui->rec_buf->setReadOnly(1);//只读

    rec_buf_flush=new QTimer;
    rec_buf_flush->setInterval(50);
    connect(rec_buf_flush, &QTimer::timeout, [=](){
        if(ui->Btn_open->getChecked()==0){serialBuffer.clear();return;}
        ui->rec_buf->insertPlainText(QString::fromLocal8Bit( serialBuffer ));
        QTextCursor tc = ui->rec_buf->textCursor();//获取当前光标位置
//        if(tc.columnNumber()>=116)//bug1
//        {//qDebug()<<tc.columnNumber();
//            tc.insertBlock();
//        }
         tc.movePosition(QTextCursor::End);
       // tc.insertBlock();
        serialBuffer.clear();
        ui->rec_buf->verticalScrollBar()->setValue(ui->rec_buf->verticalScrollBar()->maximum());
    });
   // rec_buf_flush->start();
    //串口数据获取
    connect(Serialport,&QSerialPort::readyRead,[=](){//串口缓冲区有数据
        QByteArray buf = Serialport->readAll();
        BasicInfo::AddRecNum(buf.size());
        if(!buf.isEmpty())
        {
            for(int buf_i=0;buf_i<buf.size();buf_i++)
            {
                int removeN= SerialGetOneByte((uchar)buf[buf_i]);//数据协议解析
                if(ui->RemoveAgree->isChecked()==1)
                {if(removeN!=0) {//qDebug()<<removeN;
                        if((buf_i-removeN+1)>=0)
                        {
                           // qDebug()<<"start"<<buf.size();
                            buf.remove(buf_i-removeN+1,removeN);//需要移除一部分数据
                            buf_i-=removeN;//buf_i;//if(buf_i<0) buf_i=0;
                           // qDebug("%x %x %x",(uchar)buf[buf_i],(uchar)buf[buf_i+1],(uchar)buf[buf_i+2]);
                            //qDebug()<<"end"<<buf.size();
                        }
                    }}

            }
        }
        if(ui->ShowOpen->isChecked()==1)
        {
            QString res=QString(buf);
                if(!buf.isEmpty())
                {
                    //将QByteArray数据类型转换，要能正确显示中文，需要使用QString::fromLocal8Bit
                    QString str = QString::fromLocal8Bit( buf );
                    //qDebug()<< str.length() <<endl;
                    if(ui->ShowTime->isChecked()==1)//显示时间戳
                   {
                        ui->rec_buf->setTextColor(QColor(80, 150, 150));
                        QTime current_time = QTime::currentTime();
                        int hour = current_time.hour();        //当前的小时
                        int minute = current_time.minute();    //当前的分
                        int second = current_time.second();    //当前的秒
                        int msec = current_time.msec();        //当前的毫秒
                        QString time_str;
                        time_str.sprintf("\nT%d:%02d:%02d/%03d<<",hour,minute,second,msec);
                        //serialBuffer.append(time_str);//写入缓冲区
                        ui->rec_buf->insertPlainText(time_str);
                        ui->rec_buf->verticalScrollBar()->setValue(ui->rec_buf->verticalScrollBar()->maximum());
                        //ui->rec_buf->moveCursor(QTextCursor::End);
                        //ui->rec_buf->append(time_str);
                        ui->rec_buf->setTextColor(QColor("black"));
                   }
                    if (ui->ShowHex->isChecked())// 如果以16进制显示数据：
                    {
                        QString hex_data = buf.toHex().data(); // 将buf里的数据转换为16进制
                        hex_data = hex_data.toUpper(); // 转换为大写
                        QString hex_str;
                        // 将16进制转换为大写
                        for (int i=0; i< hex_data.length(); i+=2)
                        {
                            QString st = hex_data.mid(i,2);
                            hex_str+=st;
                            hex_str+=' ';
                        }

//                        if(!ui->rec_buf->verticalScrollBar()->isVisible())
//                        {
//                            QTextCursor tc = ui->rec_buf->textCursor();//获取当前光标位置 bug1
//                            int tcx=tc.columnNumber();//获取当前列
//                            if(cntVs<100){ cntVs++;
//                                qDebug()<<cntVs;
//                                if(tcx>maxLength) {qDebug()<<"max="<<maxLength;maxLength=tcx;}
//                            }else {
//                                //qDebug()<<tcx;
//                                if(tcx>maxLength)
//                                {maxLength=tc.columnNumber();tc.insertBlock();}
//                                else if(tcx==maxLength) tc.insertBlock();
//                            }
//                        }
                        QTextCursor tc = ui->rec_buf->textCursor();//获取当前光标位置
                        if(tc.columnNumber()>=116)//bug1
                        {qDebug()<<tc.columnNumber();
                            tc.insertBlock();
                        }
                        //if(tc.atBlockEnd()) ui->rec_buf->append("");
                        //qDebug()<<"?"<<tc.block().position();
                        //serialBuffer.append(hex_str);//写入缓冲区
                        ui->rec_buf->insertPlainText(hex_str);
                        //ui->rec_buf->moveCursor(QTextCursor::End);
                        ui->rec_buf->verticalScrollBar()->setValue(ui->rec_buf->verticalScrollBar()->maximum());
                        //QTextCursor:: positionInBlock()
                        //ui->rec_buf->append(hex_str);
                    }
                    else
                    {
//                        if(!ui->rec_buf->verticalScrollBar()->isVisible())//出现再计数
//                        {
//                            QTextCursor tc = ui->rec_buf->textCursor();//获取当前光标位置
//                            int tcx=tc.columnNumber();//获取当前列
//                            if(cntVs2<100){ cntVs2++;
//                                qDebug()<<cntVs2;
//                                if(tcx>maxLength2) {qDebug()<<"max="<<maxLength2;maxLength2=tcx;}
//                            }else {
//                                //qDebug()<<tcx;
//                                if(maxLength2<maxLength)maxLength2=maxLength;
//                                if(tcx>maxLength2)
//                                {maxLength2=tc.columnNumber();tc.insertBlock();}
//                                else if(tcx==maxLength2) tc.insertBlock();
//                            }
//                        }
                        QTextCursor tc = ui->rec_buf->textCursor();//获取当前光标位置
                        if(tc.columnNumber()>=116)//bug1
                        {qDebug()<<tc.columnNumber();
                            tc.insertBlock();
                        }
                       // serialBuffer.append(str);//写入缓冲区
                        ui->rec_buf->insertPlainText(str);
                        //ui->rec_buf->moveCursor(QTextCursor::End);
                        ui->rec_buf->verticalScrollBar()->setValue(ui->rec_buf->verticalScrollBar()->maximum());
                    }
                }
                buf.clear();
        }
        //else {Serialport->clear();}
    });
#endif


    connect(ui->BtnRecClr,&QPushButton::clicked,[=](){
        ui->rec_buf->clear();
        cntVs2=0;
        cntVs=0;
    });

    connect(ui->BtnSend,&QPushButton::clicked,[=](){
        if(Serialport->isOpen()==0){return;qDebug("return!");}
        if(ui->SendHex->isChecked()==1)
        {
        QByteArray arr;
        QString data=ui->send_buf->toPlainText();
        //分析字符串格式中是否带空格
        for(int i = 0;i<data.size();i++)
        {
            if(data[i]==' ')
                continue;   //跳过
            int num  = data.mid(i,2).toUInt(nullptr,16);
            i++;
            //qDebug()<<num<<" ";
            arr.append(num);
        }
        if(ui->SendNewL->isChecked()==1){//发送新行
            arr.append(0x0D);
            arr.append(0x0A);
        }
        //send_buf_len += arr.length();
        //发送HEX格式原始数据
        Serialport->write(arr);
        BasicInfo::AddSendNum(arr.size());
        }
        else
        {QString send_b=ui->send_buf->toPlainText();
            if(ui->SendNewL->isChecked()==1){//发送新行
                    send_b.append(0x0D);
                    send_b.append(0x0A);}
        Serialport->write(send_b.toLocal8Bit().data());
        BasicInfo::AddSendNum(send_b.size());
        }
    });

    connect(ui->NumClear,&QPushButton::clicked,[=](){
        BasicInfo::ClearRecSendNum();
    });
    qRegisterMetaType<QList<QString> > ("QList<QString>");

    connect(ui->navButtonGroup,SIGNAL(buttonClicked(int)),ui->stackedWidget,SLOT(setCurrentIndex(int)));
    connect(ui->nav_sendifOne,SIGNAL(buttonClicked(int)),ui->SendIfOne,SLOT(setCurrentIndex(int)));

    connect(ui->ConnectBtn,SIGNAL(buttonClicked(int)),ui->ConnectWidget,SLOT(setCurrentIndex(int)));

    connect(ui->Scope,&QPushButton::clicked,[=](){
        if(scope::OpenSta==0)
        {
            scope::OpenSta=1;
            ScopePtr=new scope();
            //GuiThreadRun::inst();
            ScopePtr->show();
        }else //已经打开
        {
            if (ScopePtr->isMinimized())
            {
                ScopePtr->showNormal();
            }
//            //设置窗口置顶
//            ::SetWindowPos(HWND(ScopePtr->winId()), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
//            ::SetWindowPos(HWND(ScopePtr->winId()), HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
            ScopePtr->activateWindow();
            ScopePtr->setWindowState((ScopePtr->windowState() & ~Qt::WindowMinimized) | Qt::WindowActive);
            ScopePtr->show();
            //ScopePtr->activateWindow();
        }
    });
//    connect(ScopePtr,&QWidget::quit,[=](){
//        ScopePtr=NULL;
//    });
//QTabBar::tab{background-color:rgb(220,200,180);color:rgb(0,0,0);font:10pt '新宋体'}
//QTabWidget#tabWidget{background-color:rgb(255,0,0);}

//    ui->tabWidget->setStyleSheet("\
//    QTabBar::tab::selected{background-color:rgb(0,100,200);color:rgb(255,0,0);font:10pt '汉仪黑荔枝体简'}");
////    ui->TabMain->setStyleSheet("\
////    QTabBar::tab::selected{background-color:rgb(230,204,255);color:rgb(255,255,255);font:12pt '汉仪黑荔枝体简'}");

     ui->BtnSend->setStyleSheet("QPushButton{color: rgb(118, 61, 0);background-color: rgb(137, 194, 255);border:2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                                                "QPushButton:hover{background-color:rgb(229, 241, 251); color: black;}"
                                                "QPushButton:pressed{background-color:rgb(204, 228, 247);border-style: inset;}"
                                "QPushButton{font: 20pt '汉仪黑荔枝体简'}");





//     connect(Serialport,&QSerialPort::readyRead,[=](){
//         emit sendsign();
//     });
     //connect(this,SIGNAL(sendsign),);

     ui->ShowAscii->setChecked(1);

     qDebug() << "main ID:" << QThread::currentThreadId();
//     slotObj = new MySlotObject();//用于子线程，下次用时开启
//     QThread *slotthread = new QThread(this);
//     slotObj->moveToThread(slotthread);
//     connect(this, SIGNAL(sendsign()), slotObj, SLOT(slotOperat()));
//     slotthread->start();

     QIntValidator* aIntValidator = new QIntValidator;
     aIntValidator->setRange(0,99999);
     ui->SendTime->setValidator(aIntValidator);//设置输入时间框
     aIntValidator->setRange(0,9999999);
     ui->SerialBaud->setValidator(aIntValidator);//设置波特率
     serialTim=new QTimer;
     connect(ui->SendAuto,&QRadioButton::clicked,[=](){
         if(ui->SendAuto->isChecked()==1)
         {
            serialTim->setInterval(ui->SendTime->text().toInt());
            serialTim->start();
            //qDebug("start");
            //qDebug()<<ui->SendTime->text().toInt();
         }else
         {serialTim->stop();}
     });
     connect(ui->SendTime,&QLineEdit::textChanged,[=](){serialTim->setInterval(ui->SendTime->text().toInt());});
     connect(serialTim,&QTimer::timeout,[=](){
         if(Serialport->isOpen()==0){return;qDebug("return!");}
         if(ui->SendHex->isChecked()==1)
         {
         QByteArray arr;
         QString data=ui->send_buf->toPlainText();
         //分析字符串格式中是否带空格
         for(int i = 0;i<data.size();i++)
         {
             if(data[i]==' ')
                 continue;   //跳过
             int num  = data.mid(i,2).toUInt(nullptr,16);
             i++;
             qDebug()<<num<<" ";
             arr.append(num);
         }
         if(ui->SendNewL->isChecked()==1){//发送新行
             arr.append(0x0D);
             arr.append(0x0A);
         }
         //send_buf_len += arr.length();
         //发送HEX格式原始数据
         Serialport->write(arr);
         BasicInfo::AddSendNum(arr.size());
         }
         else
         {QString send_b=ui->send_buf->toPlainText();
             if(ui->SendNewL->isChecked()==1){//发送新行
                     send_b.append(0x0D);
                     send_b.append(0x0A);}
         Serialport->write(send_b.toLocal8Bit().data());
         BasicInfo::AddSendNum(send_b.size());
         }
     });

    for(int chi=1;chi<=20;chi++)
    {
        chtype[chi]=Config().Get("ScopeInt",QString("ch%1").arg(chi)).value<int>();
        //qDebug("chi=%d",chtype[chi]);
    }
    //System_Init();

    for(int chi=1;chi<=20;chi++)
    {
        Slider *slider=findChild<Slider *>(QString("slider_%1").arg(chi));
        if(slider!=NULL)
        {
            slider->ui->lineEdit_val->setText( QString("%1").arg(  Config().Get(QString("slider_%1").arg(chi),"val" ).value<float>()));
            slider->ui->lineEdit_min->setText( QString("%1").arg(  Config().Get(QString("slider_%1").arg(chi),"min" ).value<float>()));
            slider->ui->lineEdit_max->setText( QString("%1").arg(  Config().Get(QString("slider_%1").arg(chi),"max" ).value<float>()));
            int per=1000.0*(slider->ui->lineEdit_val->text().toFloat()-slider->ui->lineEdit_min->text().toFloat())/
                    (slider->ui->lineEdit_max->text().toFloat()-slider->ui->lineEdit_min->text().toFloat());
            if(per<=1000&&per>=0) slider->ui->xslider->setValue(per);
            slider->ui->xslider->show();
        }
        else qDebug("NULL");
    }

    //用于dockwidget
//    connect(ui->dockInfoShow,&QPushButton::clicked,[=](){

//        if(ui->dockInfo->isFloating()==0) ui->dockInfo->setFloating(1);
//        ui->dockInfo->setGeometry(this->geometry().x()+100,this->geometry().y()+100,this->geometry().width()/2,this->geometry().height()/2);
//        ui->dockInfo->show();
////        qDebug()<<"test1"<<ui->dockInfo->isHidden();
////        qDebug()<<"test2"<<ui->dockInfo->isFloating();
//        qDebug()<<this->geometry().x()<<this->geometry().y();
//        qDebug() << this->geometry().width() << this->geometry().height();
//    });
//    connect(ui->dockInfo,&QDockWidget::visibilityChanged,[=](){
//        if(ui->dockInfo->isHidden()==0 && ui->dockInfo->isFloating()==0) ui->dockInfo->hide();
//        //双击会有一些莫名的bug，解决此bug
//    });
//    ui->dockInfo->setHidden(1);


    DetailPtr = new DetailInfo;
    connect(ui->ShowDetailInfo,&QPushButton::clicked,[=](){
        if(DetailInfo::OpenSta==0)
        {
            DetailInfo::OpenSta=1;
            //GuiThreadRun::inst();
            DetailPtr->show();
        }else //已经打开
        {
            if (DetailPtr->isMinimized())
            {
                DetailPtr->showNormal();
            }
           DetailPtr->activateWindow();
            DetailPtr->setWindowState((DetailPtr->windowState() & ~Qt::WindowMinimized) | Qt::WindowActive);
            DetailPtr->show();
        }
    });

    //Slider发送完整一组按键
    connect(my_ui->btnSliderSend_1,&QPushButton::clicked,[=](){
        gxtSendSliderPid(1,ui->slider_1->GetVal(),ui->slider_2->GetVal(),\
                         ui->slider_3->GetVal(),ui->slider_4->GetVal(),ui->slider_5->GetVal());
    });
    connect(my_ui->btnSliderSend_2,&QPushButton::clicked,[=](){
        gxtSendSliderPid(2,ui->slider_6->GetVal(),ui->slider_7->GetVal(),\
                         ui->slider_8->GetVal(),ui->slider_9->GetVal(),ui->slider_10->GetVal());
    });
    connect(my_ui->btnSliderSend_3,&QPushButton::clicked,[=](){
        gxtSendSliderPid(3,ui->slider_11->GetVal(),ui->slider_12->GetVal(),\
                         ui->slider_13->GetVal(),ui->slider_14->GetVal(),ui->slider_15->GetVal());
    });
    connect(my_ui->btnSliderSend_4,&QPushButton::clicked,[=](){
        gxtSendSliderPid(4,ui->slider_16->GetVal(),ui->slider_17->GetVal(),\
                         ui->slider_18->GetVal(),ui->slider_19->GetVal(),ui->slider_20->GetVal());
    });


    my_ui->SystemMagnify->setCurrentText(magnifyStr);
    //magnifyStr=my_ui->SystemMagnify->currentText();
    connect(my_ui->SystemMagnify,&QComboBox::currentTextChanged,[=](){
        Config().Set("System","magnify",ui->SystemMagnify->currentText());
        qDebug()<<ui->SystemMagnify->currentText();
    });
}

Widget::~Widget()
{
    delete ui;
}

void Widget::SerialPort_Init(int * sta)
{
    bool ok;
    Serialport->setBaudRate(ui->SerialBaud->currentText().toInt(&ok,10));//设置波特率
    Serialport->setDataBits((QSerialPort::DataBits)ui->SerialData->currentText().toInt(&ok,10));//设置数据位
    Serialport->setStopBits((QSerialPort::StopBits)1);//设置停止位
    Serialport->setFlowControl((QSerialPort::FlowControl)0);//失能流控
    Serialport->setParity((QSerialPort::Parity)0);//设置校验位

    //获取端口号
    QString spTxt = ui->SerialNum->currentText();
    spTxt = spTxt.section(':', 0, 0);//过滤掉:后面的信息，只留下COMx
    Serialport->setPortName(spTxt);

    if(Serialport->open(QIODevice::ReadWrite)==true)
    {
        //QMessageBox::information(this,"提示","成功"); //成功不提示
        *sta=1;
    }else
    {
        QMessageBox::critical(this,"提示","打开失败");
        *sta=0;
    }
}


void Widget::SerialPort_Close(void)
{
    Serialport->close();
    //QMessageBox::information(this,"提示","成功");
}

void Widget::SlotTest()
{
    static int SerialSta=0;//第一次点击打开
    qDebug()<<"SerialSta="<<SerialSta;
    if(SerialSta==0)//关闭状态
    {
        SerialPort_Init(&SerialSta);
        if(SerialSta==1)//打开成功
        {
            //ui->BtnOpen->setText("关闭");
        }
        else {qDebug("打开失败！");
            disconnect(ui->Btn_open,0,0,0);
            ui->Btn_open->setChecked(0);
            connect(ui->Btn_open, &SwitchButton::checkedChanged, this,&Widget::SlotTest);
        }
    }else
    {
        SerialPort_Close();
        SerialSta=0;
    }
}

void Widget::handleSerialError(QSerialPort::SerialPortError error)
{
    if (error == QSerialPort::ResourceError) {//串口错误//（断开连接）
        qDebug("断开连接");
        ui->Btn_open->setChecked(0);
        waitMs(50);
        m_usb_listener->EmitMySignal();
        qDebug("重新检测");
    }
}

void Widget::waitMs(int msec)//延时ms
{
    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < dieTime )
    QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}


//刷新dpi
void Widget::refreshDPI()
{
    //计算dpi
    QList<QScreen*> screens = QApplication::screens();
    QScreen* screen = screens[0];
    qreal dpi = screen->logicalDotsPerInch();
    //计算dpi对应的缩放比例
    double objectRate = dpi/120.0;
    changeObjectSize(*this, objectRate);
    qDebug()<<"width "<<width() << "height "<< height();
    resize(width()*objectRate,height()*objectRate);
}
//修改所有控件尺寸
void Widget::changeObjectSize(const QObject &o, double objectRate)
{
    for (int i=0; i<o.children().size(); ++i) {
        QWidget *pWidget = qobject_cast<QWidget *>(o.children().at(i));
        if (pWidget != nullptr) {
            qDebug() << pWidget->width() << pWidget->height();
            //pWidget->resize(pWidget->width()*objectRate, pWidget->height()*objectRate);
            pWidget->setGeometry(pWidget->x()*objectRate,pWidget->y()*objectRate,
                                 pWidget->width()*objectRate, pWidget->height()*objectRate);
            changeObjectSize(*(o.children().at(i)),objectRate);
        }
    }
}

//子线程
MySlotObject::MySlotObject(QObject* parent)
:QObject(parent)
{
    qDebug() << __FUNCTION__ << QThread::currentThreadId();

#if 0
    //串口数据获取
    connect(Serialport,&QSerialPort::readyRead,[=](){//串口缓冲区有数据
        qDebug() << __FUNCTION__ << QThread::currentThreadId();

        QByteArray buf = Serialport->readAll();
        //BasicInfo::AddRecNum(buf.size());
        if(!buf.isEmpty())
        {
            for(int buf_i=0;buf_i<buf.size();buf_i++)
            {
                SerialGetOneByte((uchar)buf[buf_i]);//数据协议解析
            }
        }
        if(my_ui->ShowOpen->isChecked()==1)
        {
            QString res=QString(buf);
                if(!buf.isEmpty())
                {
                    // 将QByteArray数据类型转换，要能正确显示中文，需要使用QString::fromLocal8Bit
                    QString str = QString::fromLocal8Bit( buf );
                    qDebug()<< str.length() <<endl;
                    if(my_ui->ShowTime->isChecked()==1)//显示时间戳
                   {
                    QTime current_time = QTime::currentTime();
                    int hour = current_time.hour();        //当前的小时
                    int minute = current_time.minute();    //当前的分
                    int second = current_time.second();    //当前的秒
                    int msec = current_time.msec();        //当前的毫秒
                    QString time_str;
                    time_str.sprintf("\nT%d:%02d:%02d/%03d->>",hour,minute,second,msec);
                    my_ui->rec_buf->insertPlainText(time_str);
                    my_ui->rec_buf->moveCursor(QTextCursor::End);}
                    if (my_ui->ShowHex->isChecked())// 如果以16进制显示数据：
                    {
                        QString hex_data = buf.toHex().data(); // 将buf里的数据转换为16进制
                        hex_data = hex_data.toUpper(); // 转换为大写
                        QString hex_str;
                        // 将16进制转换为大写
                        for (int i=0; i< hex_data.length(); i+=2)
                        {
                            QString st = hex_data.mid(i,2);
                            hex_str+=st;
                            hex_str+=' ';
                        }
                        my_ui->rec_buf->insertPlainText(hex_str);
                        my_ui->rec_buf->moveCursor(QTextCursor::End);
                    }
                    else
                    {
                        my_ui->rec_buf->insertPlainText(str);
                        my_ui->rec_buf->moveCursor(QTextCursor::End);
                    }
                }
                buf.clear();
        }
        //else {Serialport->clear();}
    });
#endif
}
MySlotObject::~MySlotObject()
{

}
void MySlotObject::slotOperat()
{
    qDebug() << __FUNCTION__ << QThread::currentThreadId();

}


#if 0
//用于拖动窗口
void Widget::mousePressEvent(QMouseEvent *event)
{
    m_lastPos = event->globalPos();
    isPressedWidget = true; // 当前鼠标按下的即是QWidget而非界面上布局的其它控件
}
void Widget::mouseMoveEvent(QMouseEvent *event)
{
    if (isPressedWidget) {
        this->move(this->x() + (event->globalX() - m_lastPos.x()),
                   this->y() + (event->globalY() - m_lastPos.y()));
        m_lastPos = event->globalPos();
    }
}
void Widget::mouseReleaseEvent(QMouseEvent *event)
{
    qDebug()<<"鼠标松开";
    m_lastPos = event->globalPos();
    isPressedWidget = false; // 鼠标松开时，置为false
}
#endif

