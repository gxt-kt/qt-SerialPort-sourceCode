/********************************************************************************
** Form generated from reading UI file 'sendcmd.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SENDCMD_H
#define UI_SENDCMD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SendCmd
{
public:
    QPushButton *cmdSend;
    QPlainTextEdit *cmdTextEdit;
    QComboBox *cmdComboBox;

    void setupUi(QWidget *SendCmd)
    {
        if (SendCmd->objectName().isEmpty())
            SendCmd->setObjectName(QStringLiteral("SendCmd"));
        SendCmd->resize(630, 34);
        SendCmd->setMinimumSize(QSize(630, 34));
        SendCmd->setMaximumSize(QSize(630, 34));
        cmdSend = new QPushButton(SendCmd);
        cmdSend->setObjectName(QStringLiteral("cmdSend"));
        cmdSend->setEnabled(true);
        cmdSend->setGeometry(QRect(558, 4, 67, 27));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(cmdSend->sizePolicy().hasHeightForWidth());
        cmdSend->setSizePolicy(sizePolicy);
        cmdSend->setMinimumSize(QSize(10, 10));
        cmdSend->setMaximumSize(QSize(105, 100));
        cmdSend->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";\n"
"color: rgb(118, 61, 0);\n"
"background-color: rgb(137, 194, 255);"));
        cmdSend->setCheckable(false);
        cmdSend->setChecked(false);
        cmdSend->setAutoExclusive(false);
        cmdSend->setAutoDefault(false);
        cmdSend->setFlat(false);
        cmdTextEdit = new QPlainTextEdit(SendCmd);
        cmdTextEdit->setObjectName(QStringLiteral("cmdTextEdit"));
        cmdTextEdit->setGeometry(QRect(2, 2, 477, 31));
        cmdTextEdit->setStyleSheet(QStringLiteral("font: 75 11pt \"Consolas\";"));
        cmdComboBox = new QComboBox(SendCmd);
        cmdComboBox->setObjectName(QStringLiteral("cmdComboBox"));
        cmdComboBox->setGeometry(QRect(482, 6, 71, 22));
        cmdComboBox->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));

        retranslateUi(SendCmd);

        cmdSend->setDefault(false);


        QMetaObject::connectSlotsByName(SendCmd);
    } // setupUi

    void retranslateUi(QWidget *SendCmd)
    {
        SendCmd->setWindowTitle(QApplication::translate("SendCmd", "Form", Q_NULLPTR));
        cmdSend->setText(QApplication::translate("SendCmd", "\345\217\221\351\200\201", Q_NULLPTR));
        cmdTextEdit->setPlainText(QString());
        cmdComboBox->clear();
        cmdComboBox->insertItems(0, QStringList()
         << QApplication::translate("SendCmd", "None", Q_NULLPTR)
         << QApplication::translate("SendCmd", "/r/n", Q_NULLPTR)
         << QApplication::translate("SendCmd", "/r", Q_NULLPTR)
         << QApplication::translate("SendCmd", "/n", Q_NULLPTR)
        );
    } // retranslateUi

};

namespace Ui {
    class SendCmd: public Ui_SendCmd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SENDCMD_H
