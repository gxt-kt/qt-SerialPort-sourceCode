﻿#ifndef SCOPE_H
#define SCOPE_H

#include <QThread>
#include <QWidget>
#include "QSerialPort"
//#include "widget.h"
#include "ui_widget.h"
#include "QSerialPortInfo"
#include "QtSerialPort"
#include "QMessageBox"
#include "QByteArray"
#include "basicinfo.h"
#include "QDebug"
#include "qcustomplot.h"
#include "mythread.h"
#include "xcustomplot.h"



namespace Ui {
class scope;
}

void AddDataFromSerial(int ch,float i);
void AddDataFromSerial(int ch,int i);

//extern void aFunction();
//QFuture<void> future = QtConcurrent::run(aFunction);

extern  Ui::scope *ScopeUi;
void Show_Plot(QCustomPlot *customPlot);

class MyThread;
class scope;
//extern Ui::scope *ScopeUi;

class MyThread : public QThread
{
    Q_OBJECT
friend scope;
public:
    explicit MyThread(QObject *parent=nullptr);
    void run();

public slots:

};

class scope : public QWidget
{
    Q_OBJECT
friend MyThread;
friend void Show_Plot(QCustomPlot *customPlot);
friend void MyThread::run();
public:
    explicit scope(QWidget *parent = nullptr);
    ~scope();
    static bool OpenSta;
    Ui::scope *ui;
    void QPlot_init(QCustomPlot *customPlot);
    //void Show_Plot(QCustomPlot *customPlot);
    // 状态栏指针
    QStatusBar *sBar;
    // 绘图控件中曲线的指针

    XxwCustomPlot *pPlot1;

private:

protected:
    void closeEvent(QCloseEvent *event);
public:
    QTimer *Tim30Hz;
    QTimer *Tim1000Hz;
    static long long int ScopeTimCnt;


public slots:
    void TimeData_Update(void);

private slots:


public slots:
    void Tim30HzTimOut();
    void Tim1000HzTimOut();


private:
    // 绘图控件的指针
    MyThread *thread;
#if 0
protected:
    //截取鼠标事件绘制窗口位置. 因为标题栏隐藏后.窗口是无法拖动的。
    void mouseReleaseEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
private:
    //.........
    bool isPressedWidget;
    QPoint m_lastPos;
#endif
};


#endif // SCOPE_H
