/********************************************************************************
** Form generated from reading UI file 'scopeset.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCOPESET_H
#define UI_SCOPESET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ScopeSet
{
public:
    QLabel *label_2;
    QComboBox *comboBox;

    void setupUi(QWidget *ScopeSet)
    {
        if (ScopeSet->objectName().isEmpty())
            ScopeSet->setObjectName(QStringLiteral("ScopeSet"));
        ScopeSet->resize(315, 138);
        label_2 = new QLabel(ScopeSet);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(156, 6, 69, 22));
        label_2->setStyleSheet(QString::fromUtf8("font: 10pt \"\346\261\211\344\273\252\351\273\221\350\215\224\346\236\235\344\275\223\347\256\200\";"));
        comboBox = new QComboBox(ScopeSet);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(226, 2, 80, 30));
        comboBox->setMaximumSize(QSize(80, 16777215));
        comboBox->setStyleSheet(QStringLiteral("font: 12pt \"Consolas\";"));
        comboBox->setEditable(true);

        retranslateUi(ScopeSet);

        QMetaObject::connectSlotsByName(ScopeSet);
    } // setupUi

    void retranslateUi(QWidget *ScopeSet)
    {
        ScopeSet->setWindowTitle(QApplication::translate("ScopeSet", "Form", Q_NULLPTR));
        label_2->setText(QApplication::translate("ScopeSet", "X\350\275\264\347\202\271\346\225\260\357\274\232", Q_NULLPTR));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("ScopeSet", "10", Q_NULLPTR)
         << QApplication::translate("ScopeSet", "50", Q_NULLPTR)
         << QApplication::translate("ScopeSet", "100", Q_NULLPTR)
         << QApplication::translate("ScopeSet", "500", Q_NULLPTR)
         << QApplication::translate("ScopeSet", "1000", Q_NULLPTR)
         << QApplication::translate("ScopeSet", "3000", Q_NULLPTR)
         << QApplication::translate("ScopeSet", "5000", Q_NULLPTR)
         << QApplication::translate("ScopeSet", "10000", Q_NULLPTR)
         << QApplication::translate("ScopeSet", "30000", Q_NULLPTR)
         << QApplication::translate("ScopeSet", "50000", Q_NULLPTR)
        );
    } // retranslateUi

};

namespace Ui {
    class ScopeSet: public Ui_ScopeSet {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCOPESET_H
