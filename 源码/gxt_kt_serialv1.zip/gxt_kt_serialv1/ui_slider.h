/********************************************************************************
** Form generated from reading UI file 'slider.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SLIDER_H
#define UI_SLIDER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QWidget>
#include "xslider.h"

QT_BEGIN_NAMESPACE

class Ui_Slider
{
public:
    QLineEdit *lineEdit_val;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QCheckBox *checkBox_RT;
    XSlider *xslider;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *lineEdit_min;
    QLineEdit *lineEdit_max;

    void setupUi(QWidget *Slider)
    {
        if (Slider->objectName().isEmpty())
            Slider->setObjectName(QStringLiteral("Slider"));
        Slider->resize(210, 76);
        Slider->setMinimumSize(QSize(210, 76));
        Slider->setMaximumSize(QSize(210, 76));
        QFont font;
        font.setPointSize(7);
        Slider->setFont(font);
        lineEdit_val = new QLineEdit(Slider);
        lineEdit_val->setObjectName(QStringLiteral("lineEdit_val"));
        lineEdit_val->setGeometry(QRect(104, 2, 101, 25));
        lineEdit_val->setLayoutDirection(Qt::LeftToRight);
        lineEdit_val->setAutoFillBackground(false);
        lineEdit_val->setStyleSheet(QLatin1String("color: rgb(85, 0, 255);\n"
"font: 75 12pt \"Consolas\";\n"
"\n"
""));
        lineEdit_val->setFrame(true);
        lineEdit_val->setEchoMode(QLineEdit::Normal);
        lineEdit_val->setAlignment(Qt::AlignCenter);
        lineEdit_val->setCursorMoveStyle(Qt::LogicalMoveStyle);
        lineEdit_val->setClearButtonEnabled(false);
        layoutWidget = new QWidget(Slider);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(8, 0, 98, 28));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        checkBox_RT = new QCheckBox(layoutWidget);
        checkBox_RT->setObjectName(QStringLiteral("checkBox_RT"));
        checkBox_RT->setStyleSheet(QStringLiteral("font: 75 11pt \"Consolas\";"));

        horizontalLayout->addWidget(checkBox_RT);

        xslider = new XSlider(Slider);
        xslider->setObjectName(QStringLiteral("xslider"));
        xslider->setGeometry(QRect(2, 20, 207, 36));
        QFont font1;
        font1.setPointSize(9);
        xslider->setFont(font1);
        xslider->setStyleSheet(QStringLiteral("QSlider::horizontal{min-height:20px;color:#000000;}QSlider::groove:horizontal{background:#a0d7da;height:10px;border-radius:5px;}QSlider::add-page:horizontal{background:#a0d7da;height:10px;border-radius:5px;}QSlider::sub-page:horizontal{background:#22a3a9;height:10px;border-radius:5px;}QSlider::handle:horizontal{width:18px;margin-top:-4px;margin-bottom:-4px;border-radius:8px;background:qradialgradient(spread:pad,cx:0.5,cy:0.5,radius:0.5,fx:0.5,fy:0.5,stop:0.6 #ffffff,stop:0.8 #0e99a0);}QSlider::vertical{min-width:20px;color:#000000;}QSlider::groove:vertical{background:#a0d7da;width:10px;border-radius:5px;}QSlider::add-page:vertical{background:#22a3a9;width:10px;border-radius:5px;}QSlider::sub-page:vertical{background:#a0d7da;width:10px;border-radius:5px;}QSlider::handle:vertical{height:19px;margin-left:-4px;margin-right:-4px;border-radius:8px;background:qradialgradient(spread:pad,cx:0.5,cy:0.5,radius:0.5,fx:0.5,fy:0.5,stop:0.6 #ffffff,stop:0.8 #0e99a0);}"));
        xslider->setMinimum(0);
        xslider->setMaximum(1000);
        xslider->setSingleStep(10000);
        xslider->setPageStep(10);
        xslider->setValue(100);
        xslider->setSliderPosition(100);
        xslider->setInvertedAppearance(false);
        xslider->setInvertedControls(false);
        xslider->setTickPosition(QSlider::NoTicks);
        xslider->setShowText(false);
        xslider->setSliderHeight(10);
        layoutWidget1 = new QWidget(Slider);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(2, 46, 205, 30));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        lineEdit_min = new QLineEdit(layoutWidget1);
        lineEdit_min->setObjectName(QStringLiteral("lineEdit_min"));
        lineEdit_min->setStyleSheet(QLatin1String("font: 75 11pt \"Consolas\";\n"
"border-width:0;\n"
""));

        horizontalLayout_2->addWidget(lineEdit_min);

        lineEdit_max = new QLineEdit(layoutWidget1);
        lineEdit_max->setObjectName(QStringLiteral("lineEdit_max"));
        lineEdit_max->setLayoutDirection(Qt::LeftToRight);
        lineEdit_max->setAutoFillBackground(false);
        lineEdit_max->setStyleSheet(QLatin1String("font: 75 11pt \"Consolas\";\n"
"border-width:0;\n"
""));
        lineEdit_max->setEchoMode(QLineEdit::Normal);
        lineEdit_max->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_max->setCursorMoveStyle(Qt::LogicalMoveStyle);
        lineEdit_max->setClearButtonEnabled(false);

        horizontalLayout_2->addWidget(lineEdit_max);

        layoutWidget->raise();
        layoutWidget->raise();
        xslider->raise();
        lineEdit_val->raise();

        retranslateUi(Slider);

        QMetaObject::connectSlotsByName(Slider);
    } // setupUi

    void retranslateUi(QWidget *Slider)
    {
        Slider->setWindowTitle(QApplication::translate("Slider", "Form", Q_NULLPTR));
        lineEdit_val->setText(QApplication::translate("Slider", "500", Q_NULLPTR));
        checkBox_RT->setText(QApplication::translate("Slider", "RT", Q_NULLPTR));
        lineEdit_min->setText(QApplication::translate("Slider", "0.00", Q_NULLPTR));
        lineEdit_max->setText(QApplication::translate("Slider", "1000", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Slider: public Ui_Slider {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SLIDER_H
