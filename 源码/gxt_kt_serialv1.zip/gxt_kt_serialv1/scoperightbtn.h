#ifndef SCOPERIGHTBTN_H
#define SCOPERIGHTBTN_H

#include <QWidget>
#include <qmenu.h>

namespace Ui {
class scopeRightBtn;
}

class scopeRightBtn : public QMenu
{
    Q_OBJECT

public:
    explicit scopeRightBtn(QWidget *parent = nullptr);
    ~scopeRightBtn();
    int curChN;
    Ui::scopeRightBtn *ui;
private:

signals:
    void Scopeflush(int i);
};

#endif // SCOPERIGHTBTN_H
