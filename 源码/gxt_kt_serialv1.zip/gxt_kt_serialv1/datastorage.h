#ifndef DATASTORAGE_H
#define DATASTORAGE_H

#include <QObject>
#include <QWidget>
#include <QtSerialPort>

//用于传输数据
#define BYTE0(dwTemp) (*((char *)(&dwTemp)))
#define BYTE1(dwTemp) (*((char *)(&dwTemp) + 1))
#define BYTE2(dwTemp) (*((char *)(&dwTemp) + 2))
#define BYTE3(dwTemp) (*((char *)(&dwTemp) + 3))

extern QSerialPort *SerPort;

extern int chtype[];//通道数据类型

#endif // DATASTORAGE_H
