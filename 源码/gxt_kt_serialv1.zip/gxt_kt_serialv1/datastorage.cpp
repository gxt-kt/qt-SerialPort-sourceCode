#include "datastorage.h"


QSerialPort *SerPort=nullptr;

int chtype[21]={0};

