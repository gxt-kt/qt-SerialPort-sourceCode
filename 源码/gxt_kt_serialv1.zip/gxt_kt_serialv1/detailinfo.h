#ifndef DETAILINFO_H
#define DETAILINFO_H

#include <QWidget>
#include "QTreeWidgetItem"
#include "QDebug"
#include "qtimer.h"
#include "QTime"
namespace Ui {
class DetailInfo;
}
class DetailInfo;


extern DetailInfo *DetailPtr;

class DetailInfo : public QWidget
{
    Q_OBJECT

public:
    explicit DetailInfo(QWidget *parent = nullptr);
    ~DetailInfo();
    static bool OpenSta;
    void initQTree(void);
    void ItemSetVal(uint8_t ch,int val);

public:
    QTreeWidgetItem *itemId;
    QTimer *flushTim;

public Q_SLOT:
    void flushTimOut(void);
   // QTreeWidgetItem *itemIdArr[0xff];

private:
    Ui::DetailInfo *ui;
};

#endif // DETAILINFO_H
