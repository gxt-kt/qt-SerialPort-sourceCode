#ifndef SCOPESET_H
#define SCOPESET_H

#include <QWidget>

namespace Ui {
class ScopeSet;
}

class ScopeSet : public QWidget
{
    Q_OBJECT

public:
    explicit ScopeSet(QWidget *parent = nullptr);
    ~ScopeSet();

private:
    Ui::ScopeSet *ui;
};

#endif // SCOPESET_H
