﻿#include "systemfun.h"
#include "QObject"



SystemFun::SystemFun()
{

}

void System_Init(void)
{

    //my_ui->progressTip->setValue(10.123);
            //my_ui->stackedWidget
//    my_ui->xslider->setMaximum(200);
//            my_ui->xslider->setMinimum(100);
//            my_ui->xslider->setValue(130);
//    my_ui->ProgressBar_1->setMaximum(2000);
//    my_ui->ProgressBar_1->setMinimum(1000);
//    my_ui->ProgressBar_1->setValue(1500);
//    my_ui->gaugePlane->setDegValue(0);
//    my_ui->gaugePlane->setRollValue(10);

//    my_ui->Btn_open->setAnimation(1);//开启动画
//    my_ui->Btn_open->setTextOn("关闭");//设置打开时显示关闭
//    my_ui->Btn_open->setTextOff("打开");
}

